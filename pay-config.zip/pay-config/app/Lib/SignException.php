<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/2 0002
 * Time: 15:10
 */

namespace App\Lib;


class SignException extends BaseException
{
    public $code = 200;
    public $msg = '签名错误';
    public $errorCode = 2001;
}