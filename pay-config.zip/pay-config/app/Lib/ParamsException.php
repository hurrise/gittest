<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/2 0002
 * Time: 14:50
 */

namespace App\Lib;


class ParamsException extends BaseException
{
    public $code = 200;
    public $msg = '参数异常';
    public $errorCode = 3001;
}