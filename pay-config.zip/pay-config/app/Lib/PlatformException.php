<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/2 0002
 * Time: 14:58
 */

namespace App\Lib;


class PlatformException extends BaseException
{
    public $code = 200;
    public $msg = '平台异常';
    public $errorCode = 1001;
}