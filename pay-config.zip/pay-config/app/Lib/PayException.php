<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/2 0002
 * Time: 20:52
 */

namespace App\Lib;


class PayException extends BaseException
{
    public $code = 200;
    public $msg = '支付方式异常';
    public $errorCode = 4001;
}