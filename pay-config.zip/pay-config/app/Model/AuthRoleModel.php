<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AuthRoleModel extends BaseModel
{
    protected $table = 'auth_role';
}
