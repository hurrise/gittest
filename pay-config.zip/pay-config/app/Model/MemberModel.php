<?php

namespace App\Model;

use Illuminate\Support\Facades\DB;

class MemberModel extends BaseModel
{
    protected $table="member";
    public function add($request=""){
        $data = $request->all();
        if(empty($data['roles'])){
            return ajaxReturn(400,'请分配角色');
        }
        $this->name = $data['name'];
        $salt = str_random(4);
        $this->password = md5($data['password'].$salt);
        $this->salt = $salt;
        $this->auth = $data['auth'];
        $this->status = $this->const->normalStatus;
        DB::beginTransaction();
        if($this->save()){
            $id = $this->max('id');
            foreach ($data['roles'] as $k=>$v){
                $tmpData[] = ['member_id'=>$id,'role_id'=>$v];
            }
            $res = $this->getOtherModel('RoleMember')->insert($tmpData);
            if($res) {
                DB::commit();
                return ajaxReturn(200, '添加成功');
            }
            DB::rollback();
            return ajaxReturn(400,'添加失败');
        }
        DB::rollback();
        return ajaxReturn(400,'添加失败');
    }
    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'search' ])) {
            $where[] = [ 'name','like','%'.$search['search'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        return $data;
    }

    public function edit($request = "",$id = ""){
        $data = $request->all();
        if(empty($data['roles'])){
            return ajaxReturn(400,'请分配角色');
        }
        $model = $this->getDataById($id);
        $model->name = $data['name'];
        if(isset($data['password'])){
            $salt = str_random(4);
            $model->salt = $salt;
            $model->password = md5($data['password'].$salt);
        }
        $model->auth = $data['auth'];
        DB::beginTransaction();
        if($model->save()){
            $roleMember = $this->getOtherModel('RoleMember');
            $roleMember->where('member_id',$id)->delete();
            foreach ($data['roles'] as $k=>$v){
                $tmpData[] = ['member_id'=>$id,'role_id'=>$v];
            }
            $res = $roleMember->insert($tmpData);
            if($res) {
                DB::commit();
                return ajaxReturn(200, '修改成功');
            }
            DB::rollback();
            return ajaxReturn(400,'修改失败');
        }
        DB::rollback();
        return ajaxReturn(400,'修改失败');
    }
    public function roles(){
        return $this->belongsToMany('App\Model\RoleModel','role_member','member_id','role_id');
    }
}
