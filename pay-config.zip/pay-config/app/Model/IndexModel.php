<?php

namespace App\Model;

class IndexModel extends BaseModel
{
    //
}
