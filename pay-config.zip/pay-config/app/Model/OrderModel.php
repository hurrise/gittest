<?php

namespace App\Model;

use Illuminate\Support\Facades\DB;

class OrderModel extends BaseModel
{
    protected $table="order";
    public function generate($request="",$id=""){
        $data = $request->all();
        $payment = $this->getOtherModel('payment')->getDataById($id);
        $orderNo = 'T'.date('YmdHis').rand(1000,9999);
        $this->order_no = $orderNo;
        $this->payment_id = $payment->id;
        $this->payment_uname = $payment->uname;
        $this->payment_name = $payment->name;
        $this->money = $data['money'];
        $this->bank = isset($data['bank'])?$data['bank']:'';
        $this->person = isset($data['person'])?$data['person']:'';
        $this->card = isset($data['card'])?$data['card']:'';
        $this->status = $this->const->orderPaying;
        if($this->save()){
            return ajaxReturn(200,'订单生成成功',$orderNo);
        }
        return ajaxReturn(400,'订单生成失败');
    }

    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'thirduname' ])) {
            $sql = "SELECT `pay_payment`.id,`pay_payment`.category_id,`pay_third`.uname FROM `pay_payment` INNER JOIN `pay_third` ON `pay_payment`.`third_id` = `pay_third`.`id` WHERE `pay_third`.`uname` LIKE '%".$search[ 'thirduname' ]."%'";
            $thirdunamedata = DB::select($sql);
            $thirduname =[];
            foreach ($thirdunamedata  as $k=>$v){
                $thirduname[$k] = $v->id;
            }
        }
        if (!empty($search[ 'search' ])) {
            $where[] = [ 'payment_name','like','%'.$search['search'].'%' ];
        }
        if (!empty($search[ 'searchun' ])) {
            $where[] = [ 'payment_uname','like','%'.$search['searchun'].'%' ];
        }
        if(isset($thirduname)){
            $data = $this->where($where)->whereIn('payment_id', $thirduname)->orderByDesc('status')->orderByDesc('payment_name')->orderByDesc('created_at')->paginate($this->const->pageNum);
        }else{
            $data = $this->where($where)->orderByDesc('status')->orderByDesc('payment_name')->orderByDesc('created_at')->paginate($this->const->pageNum);
        }
        return $data;
    }
}
