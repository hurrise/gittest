<?php

namespace App\Model;


class OperationModel extends BaseModel
{
    protected $table = 'operation';

    public function index($request='')
    {
        $where = [];
        @$request->member and ($where[] = ['member',$request->member]);
        @$request->operation and ($where[] = ['operation',$request->operation]);
        @$request->table_name and ($where[] = ['table_name',$request->table_name]);
        @$request->start and ($where[] = ['created_at', '>=', $request->start]);
        @$request->end and ($where[] = ['created_at', '<=', $request->end]);
        $data = $this->where($where)->orderByDesc('created_at')->paginate($this->const->pageNum);
        $arr = $this->distinct()->get(['member','table_name'])->toArray();
        $data->members = array_unique(array_column($arr,'member'));
        $data->tables = array_unique(array_column($arr,'table_name'));
        return $data;
    }
}
