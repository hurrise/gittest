<?php

namespace App\Model;

use Illuminate\Support\Facades\DB;

class PaymentModel extends BaseModel
{
    protected $table="payment";
    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if(!empty($search['thirduname'])){
            $sql = "SELECT id FROM `pay_third` WHERE `uname` LIKE '%".$search['thirduname']."%'";
            $thirdunamedata = DB::select($sql);
            $thirduname =[];
            foreach ($thirdunamedata  as $k=>$v){
                $thirduname[$k] = $v->id;
            }
        }
        if (!empty($search[ 'search' ])) {
            $where[] = [ 'name','like','%'.$search['search'].'%' ];
        }
        isset($search[ 'searchun' ]) && ( $where[] = [ 'uname','like','%'.$search['searchun'].'%' ] );
        isset($search[ 'admin' ]) && ( $where[] = [ 'member_name','like','%'.$search['admin'].'%' ] );
        isset($search[ 'status' ]) && ( $where[] = [ 'status',$search['status'] ] );
        if (isset($search[ 'start' ]) && isset($search[ 'end' ])){
            $where[] = [ 'created_at','>=',$search['start'] ];
            $where[] = [ 'created_at','<=',$search['end'] ];
        }
        if(isset($thirduname)){
            $data = $this->where($where)->whereIn('third_id', $thirduname)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        }else{
            $data = $this->where($where)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        }
        return $data;
    }
    public function add($request = ""){
        $data = $request->all();
        if (@$data['id']) {
            $keys = DB::table('payment')->where('id',$data['id'])->get(['merchant_secret','public_key','private_key'])[0];
            str_contains($data['merchant_secret'],$this->const->star) and $data['merchant_secret'] = $keys->merchant_secret;
            str_contains($data['public_key'],$this->const->star) and $data['public_key'] = $keys->public_key;
            str_contains($data['private_key'],$this->const->star) and $data['private_key'] = $keys->private_key;
        }
        $this->name = $data['name'];
        $this->category_id = $data['category_id'];
        $category = $this->getOtherModel('category')->getDataById($data['category_id']);
        $this->category_name = $category->name;
        $this->uname = $data['uname'];
        $this->is_bank = $data['is_bank'];
        $this->third_id = $data['third_id'];
        $third = $this->getOtherModel('third')->getDataById($data['third_id']);
        $this->third_name = $third->name;
        $this->merchant_code = $data['merchant_code'];
        $this->merchant_secret = $data['merchant_secret'];
        $this->app_id = myTrim($data['app_id']);
        $this->public_key = $data['public_key'];
        $this->private_key = $data['private_key'];
        $this->bank_info = $data['bank_info'];
        $this->gateway = $data['gateway'];
        $this->status = $this->const->seting;
        $this->member_id = getMe('id');
        $this->member_name = getMe('name');
        $this->third_domain = $data['third_domain'];
        $this->callback_domain = $data['callback_domain'];
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function edit($request = "",$id = ""){
        $model = $this->getDataById($id);
        if(getMe('auth') != $this->const->superAuth){
            if(getMe('id') != $model->member_id){
                return ajaxReturn(400,'您无权编辑');
            }
        }
        $data = $request->all();
        $model->name = $data['name'];
        $model->category_id = $data['category_id'];
        $category = $this->getOtherModel('category')->getDataById($data['category_id']);
        $model->category_name = $category->name;
        $model->uname = $data['uname'];
        $model->is_bank = $data['is_bank'];
        $model->third_id = $data['third_id'];
        $third = $this->getOtherModel('third')->getDataById($data['third_id']);
        $model->third_name = $third->name;
        $model->merchant_code = myTrim($data['merchant_code']);
        str_contains($data['merchant_secret'],$this->const->star) or $model->merchant_secret = myTrim($data['merchant_secret']);
        $model->app_id = myTrim($data['app_id']);
        str_contains($data['public_key'],$this->const->star) or $model->public_key = myTrim($data['public_key']);
        str_contains($data['private_key'],$this->const->star) or $model->private_key = myTrim($data['private_key']);
        $model->bank_info = myTrim($data['bank_info']);
        $model->gateway = $data['gateway'];
        $model->third_domain = $data['third_domain'];
        $model->callback_domain = $data['callback_domain'];
        if($model->save()){
            return ajaxReturn(200,'编辑成功');
        }
        return ajaxReturn(400,'编辑失败');
    }
    public function del($id = "")
    {
        $model = $this->getDataById($id);
        if(getMe('auth') != $this->const->superAuth){
            if(getMe('id') != $model->member_id){
                return ajaxReturn(400,'您无权删除');
            }
        }
        return parent::del($id); // TODO: Change the autogenerated stub
    }
    public function category(){
        return $this->belongsTo('App\Model\CategoryModel','category_id','id');
    }

    public function third(){
        return $this->belongsTo('App\Model\ThirdModel','third_id','id');
    }

    public function getMerchantSecretAttribute($value)
    {
        return $value ? substr($value,0,2).$this->const->star.substr($value,-2) : '';
    }
    public function getPublicKeyAttribute($value){
        return $value ? substr($value,0,2).$this->const->star.substr($value,-2) : '';
    }
    public function getPrivateKeyAttribute($value){
        return $value ? substr($value,0,2).$this->const->star.substr($value,-2) : '';
    }
}
