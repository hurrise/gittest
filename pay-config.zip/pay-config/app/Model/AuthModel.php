<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AuthModel extends BaseModel
{
    protected $table = 'auth';
    public function add($request=""){
        $data = $request->all();
        $data['path'] = $data['pid'];
        if($data['pid'] != 0){
            $parent = $this->where('id','=',$data['pid'])->first();
            $data['path'] = $parent->path.','.$data['pid'];
        }
        $this->pid = $data['pid'];
        $this->path = $data['path'];
        $this->name = $data['name'];
        $this->route = $data['pid'] == 0 ? '-.-.-' :$data['route'];
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function index($request=""){
        $where = [];
        $search = $request->all();
        if(isset($search['search'])){
            $where[] = ['name','like','%'.$search['search'].'%'];
        }
        $data = $this->selectRaw("`id`,`pid`,`path`,`route`,`name`,concat(`path`,',',`id`) as `paid`,`status`,`created_at`,`updated_at`")->where($where)->orderBy('paid')->paginate($this->const->pageNum);
        return $this->getTree($data);
    }

    public function getTree($data=""){
        foreach ($data as $k => $v){
            $n = substr_count($v['path'],',')+1;
            $data[$k]['name'] = str_repeat('&nbsp;&nbsp;',$n).'|-'.$v['name'];
        }
        return $data;
    }
    public function edit($request = "",$id=""){
        $data = $request->all();
        $data['path'] = $data['pid'];
        if($data['pid'] != 0){
            $parent = $this->where('id','=',$data['pid'])->first();
            $data['path'] = $parent->path.','.$data['pid'];
        }
        $model = $this->getDataById($id);
        $model->pid = $data['pid'];
        $model->path = $data['path'];
        $model->name = $data['name'];
        $model->route = $data['pid'] == 0 ? '-.-.-' :$data['route'];
        if($model->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
    public function roles(){
        return $this->belongsToMany('App\Model\RoleModel','auth_role','auth_id','role_id');
    }
}
