<?php

namespace App\Model;

use App\Service\FactoryService;
use Illuminate\Database\Eloquent\Model;

class  BaseModel extends Model
{
    public $const;
    public function __construct($params = "")
    {
        $this->const = FactoryService::getInstance()->generateService('const');
    }
    public function getDataById($id = ""){
        return $this->find($id);
    }
    public function status($id = "",$status = ""){
        if($status == $this->const->normalStatus){
            $status = $this->const->forbiddenStatus;
        }elseif($status == $this->const->forbiddenStatus){
            $status = $this->const->normalStatus;
        }
        $model = $this->getDataById($id);
        $model->status = $status;
        if($model->save()){
            return back();
        }
    }
    public function del($id=""){
        if($this->where('id','=',$id)->delete()){
            return ajaxReturn(200,'删除成功');
        }
        return ajaxReturn(400,'删除失败');
    }
    public function checkFieldRepeat($field="",$value=""){if($this->where($field,'=',$value)->first()){return true;}return false;}
    public function getOtherModel($model=""){
        return FactoryService::getInstance()->generateModel($model);
    }
}
