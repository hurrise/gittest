<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RoleMemberModel extends BaseModel
{
    protected $table='role_member';
}
