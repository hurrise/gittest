<?php

namespace App\Model;

class PlatformModel extends BaseModel
{
    protected $table="platform";
    public function add($request = ""){
        $data = $request->all();
        $this->name = $data['name'];
        $this->platform_key = $data['platform_key'];
        $this->platform_secret = $data['platform_secret'];
        $this->status = $this->const->normalStatus;
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'search' ])) {
            $where[] = [ 'name','like','%'.$search['search'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        return $data;
    }
    public function edit($request = "",$id = ""){
        $model = $this->getDataById($id);
        $data = $request->all();
        $model->name = $data['name'];
        $model->platform_key = $data['platform_key'];
        $model->platform_secret = $data['platform_secret'];
        if($model->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
}
