<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class IpwallModel extends BaseModel
{
    protected $table = 'ipwall';

    public function batchSave($data){
        DB::beginTransaction();
        try{
            $tmpData = [];
            foreach ($data['ip'] as $k=>$v){
                $tmp = explode('|',$v);
                $tmpData[$k]['ip'] = isset($tmp[0])?$tmp[0]:'';
                if(isset($tmp[1])) {
                    $tmpData[$k]['platform'] = $tmp[1];
                }
            }
            DB::table('ipwall')->truncate();
            $res = $this->insert($tmpData);
            if($res){
                DB::commit();
                return ['flag'=>true,'msg'=>'保存成功'];
            }
            DB::rollBack();
            return ['flag'=>false,'msg'=>'系统错误,保存失败'];
        }catch (\Exception $e){
            DB::rollBack();
            return ['flag'=>false,'msg'=>$e->getMessage()];
        }

    }
}
