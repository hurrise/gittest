<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class RoleModel extends BaseModel
{
    protected $table = "role";
    public function add($request = ""){

        $data = $request->all();
        if(empty($data['auth'])){
            return ajaxReturn(400,'请选择权限');
        }
        $this->name = $data['name'];
        $this->remark = $data['remark']??'';
        DB::beginTransaction();
        $this->save();
        $id = $this->max('id');
        if($id > 0){

            foreach ($data['auth'] as $k=>$v){
                $tmpData[] = ['role_id'=>$id,'auth_id'=>$v];
            }
            $res = $this->getOtherModel('AuthRole')->insert($tmpData);
            if($res){
                DB::commit();
                return ajaxReturn(200,'添加成功');
            }
            DB::rollback();
            return ajaxReturn(400,'添加失败');
        }
        DB::rollback();
        return ajaxReturn(400,'添加失败');
    }
    public function index($request = ""){
        $where = [];
        $search = $request->all();
        if(isset($search['search'])){
            $where[] = ['name','like','%'.$search['search'].'%'];
        }
        $data = $this->where($where)->paginate($this->const->pageNum);
        return $data;
    }
    public function auths(){
        return $this->belongsToMany('App\Model\AuthModel','auth_role','role_id','auth_id');
    }
    public function members(){
        return $this->belongsToMany('App\Model\MemberModel','role_member','role_id','member_id');
    }
    public function edit($request = "",$id = ""){
        $data = $request->all();
        if(empty($data['auth'])){
            return ajaxReturn(400,'请选择权限');
        }
        $model = $this->getDataById($id);
        $model->name = $data['name'];
        $model->remark = $data['remark']??'';
        DB::beginTransaction();
        if($model->save()) {
            $authRole = $this->getOtherModel('AuthRole');
            $authRole->where('role_id','=',$id)->delete();
            foreach ($data['auth'] as $k=>$v){
                $tmpData[] = ['role_id'=>$id,'auth_id'=>$v];
            }
            $res = $authRole->insert($tmpData);
            if($res){
                DB::commit();
                return ajaxReturn(200,'编辑成功');
            }
            DB::rollback();
            return ajaxReturn(400,'编辑失败');
        }
        DB::rollback();
        return ajaxReturn(400,'编辑失败');
    }
}
