<?php

namespace App\Model;

class ThirdModel extends BaseModel
{
    protected $table="third";

    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if(!empty($search[ 'search' ])) {
            $where[] = [ 'name','like','%'.$search['search'].'%' ];
        }
        if(!empty($search[ 'searchun' ])){
            $where[] = [ 'uname','like','%'.$search['searchun'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        return $data;
    }
    public function add($request = ""){
        $data = $request->all();
        $this->name = $data['name'];
        $this->uname = $data['uname'];
        $this->status = $this->const->normalStatus;
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }

    public function edit($request="" ,$id=""){
        $data = $request->all();
        $model = $this->getDataById($id);
        $model->name = $data['name'];
        $model->uname = $data['uname'];
        if($model->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
    public function payment(){
        return $this->hasMany('App\Model\PaymentModel','third_id','id');
    }
}
