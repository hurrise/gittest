<?php

namespace App\Http\Requests\Ipwall;

use Illuminate\Foundation\Http\FormRequest;

class GenerateValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')){
            return [
                'option' => 'required',
                'third' => 'required',
                'ip1' => 'required|ip',
                'ip2' => $this->option == 'update' ? 'required|ip':'',
            ];
        }
        return [
            //
        ];
    }
    public function messages()
    {
       return [
           'option.required' => '请选择操作',
           'third.required' => '请选择第三方平台',
           'ip1.required' => '第一个ip值必填',
           'ip1.ip' => '第一个ip值不符合规则',
           'ip2.required' => '第二个ip值必填',
           'ip2.ip' => '第二个ip值不符合规则',
       ];
    }
}
