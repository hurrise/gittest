<?php

namespace App\Http\Requests\Payment;

use Illuminate\Foundation\Http\FormRequest;

class AddValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')) {
            return [
                'name' => 'required',
                'uname' => 'required|alpha_num',
                'merchant_code' => 'required',
                'gateway' => 'required|url',
            ];
        }
        return [];
    }
    public function messages()
    {
        return [
            'name.required' => '名称必填',
            'uname.required' => '别名必填',
            'uname.alpha_num' => '别名只能是数字或字母',
            'merchant_code.required' => '商户号必填',
            'gateway.required' => '请求地址必填',
            'gateway.url' => '请求地址格式不正确',
        ];
    }
}
