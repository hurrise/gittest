<?php

namespace App\Http\Middleware;

use Closure;

class LoginMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(!session()->has('user')){
            return redirect(url('admin/index/login'));
        }
//        $updateRoutes = [
//            'admin.member.status',
//            'admin.member.del',
//            'admin.category.status',
//            'admin.category.del',
//        ];
//        $route = $request->route()->getName();
//        if($request->isMethod('post') || in_array($route,$updateRoutes)){
//            $user = session('user');
//            $operation = new \App\Model\OperationModel();
//            $operation->member_id = $user->id;
//            $operation->member = $user->name;
//            $operation->method = $request->method();
//            $operation->route_name = $route;
//            $operation->operation_ip = get_real_ip();
//            $operation->req_params = json_encode($request->all(),JSON_UNESCAPED_UNICODE);
//            $operation->save();
//        }
        return $next($request);
    }
}
