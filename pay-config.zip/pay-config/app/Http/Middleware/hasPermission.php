<?php

namespace App\Http\Middleware;

use Closure;

class hasPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        try{
            $member_id = (new \App\Model\PaymentModel())->find($request->route('id'))->member_id;
            if(getMe('auth') != (new \App\Service\ConstService)->superAuth && getMe('id') != $member_id)
                die('非法请求!');
        }catch (\Exception $e){
            die($e->getMessage());
        }
        return $next($request);
    }
}
