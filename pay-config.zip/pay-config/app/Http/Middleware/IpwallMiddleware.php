<?php

namespace App\Http\Middleware;

use App\Service\CurlService;
use Closure;

class IpwallMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $data['ip'] = $request->getClientIp();
        $data['sys'] = 'zfdt';
        $url = "http://45.77.242.9:9000/wall";
        $res = CurlService::getInstance()->post($url,$data);
        $res = json_decode($res,true);
        if($res['code'] == 200){
            return $next($request);
        }else if($res['code'] == 404){
            return  redirect($res['data']);
        }
    }
}
