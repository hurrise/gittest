<?php

namespace App\Http\Middleware;

use App\Service\FactoryService;
use Closure;
use Illuminate\Support\Facades\DB;

class AuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $route = $request->route()->getName();
        $auth = DB::table('auth')->where('route', $route)->first();
        if(!session()->has('myAuths'.getMe('id'))) {
            $member = FactoryService::getInstance()->generateModel('member')->where('id', getMe('id'))->first();
            $tmpAuths = [];
            foreach ($member->roles as $k => $v) {
                $tmpAuths[] = $v->auths->toArray();
            }
            $tmpAuths = array_collapse($tmpAuths);
            $myAuths = [];
            foreach ($tmpAuths as $k => $v) {
                $myAuths[] = $v['id'];
            }
            $myAuths = array_flip(array_flip($myAuths));
            session(['myAuths'.getMe('id') => $myAuths]);
        }
        if(in_array($auth->id,session('myAuths'.getMe('id')))){
            return $next($request);
        }else {
            return redirect('403');
        }
    }
}
