<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OperationController extends BaseController
{
    public function index(Request $request)
    {
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('data','const','request'));
    }
}
