<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Ipwall\GenerateValidate;
use App\Model\IpwallModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class IpwallController extends BaseController
{
    public function set(Request $request){
        if($request->isMethod('post')){
            return $this->repo->set($request);
        }
        $data = (new IpwallModel())->get();
        $ips = [];
        foreach ($data as $k=>$v){
            $ips[$k] = !empty($v->platform)?$v->ip.'|'.$v->platform:$v->ip;
        }
        $white = implode(PHP_EOL,$ips);
        $file = storage_path() . '/ip/unknown_ip_list.log';
        $unknown_ip = @file_get_contents($file);
        return view('admin.ipwall.set',compact('white','unknown_ip'));
    }

    public function query(Request $request){
        return $this->repo->query($request);
    }

    public function clear(){
        $file = storage_path() . '/ip/unknown_ip_list.log';
        @unlink($file);
    }

    public function generate(GenerateValidate $request){
        if($request->isMethod('post')){
            return $this->repo->generate($request);
        }
        $thirds = $this->getOtherRepo('Third')->getNormalThird();
        return view($this->view,compact('thirds'));
    }

}
