<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Service\FactoryService;
use \Illuminate\Http\Request;
class BaseController extends Controller
{
    public $repo;
    public $const;
    public $view;
    public function __construct(Request $request)
    {
        /**
         * m 代表模块
         * c 代表控制器
         * a 代表方法
         */
        $mcaStr = $request->route()->getName();
        if(is_null($mcaStr)){
            dd('Error_01:请为路由['.$request->getUri().']设置别名');
        }
        $mcaArr = explode('.',$mcaStr);
        $this->view = $mcaStr;
        $this->repo = FactoryService::getInstance()->generateRepository($mcaArr[1],$mcaArr[1]);
        $this->const = FactoryService::getInstance()->generateService('const');
    }
    public function status($id = "",$status = ""){
        return $this->repo->status($id,$status);
    }
    public function del($id = ""){
        return $this->repo->del($id);
    }
    public function getOtherRepo($repoName=""){
        return FactoryService::getInstance()->generateRepository($repoName,$repoName);
    }
}
