<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Auth\AddValidate;
use App\Http\Requests\Auth\EditValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AuthController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('request','data','const'));
    }
    public function add(AddValidate $request){
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        $const = $this->const;
        $auth = $this->repo->getNormalAuth();
        return view($this->view,compact('const','auth'));
    }
    public function edit(EditValidate $request,$id=""){
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $const = $this->const;
        $auth = $this->repo->getNormalAuth();
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('const','auth','data'));
    }
}
