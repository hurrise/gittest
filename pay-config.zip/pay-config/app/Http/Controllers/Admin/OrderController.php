<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class OrderController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('data','const','request'));
    }
    public function topay($orderNo = ""){
        return $this->repo->topay($orderNo);
    }
    public function onlineTopay($orderNo = ""){
        echo $this->repo->onlineTopay($orderNo);
    }
    public function callback(Request $request,$orderNo = ""){
        return $this->repo->callback($request,$orderNo);
    }
    public function onlineCallback(Request $request){
        return $this->repo->onlineCallback($request);
    }
    public function redirect(Request $request,$orderNo = ""){

    }

    public function show($id=""){
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('data'));
    }
    public function log($id=""){
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('data'));
    }

    public function apiShowQrCode(Request $request){
        $data = $request->all();
        $orderInfo = $this->repo->getDataByOrderNo($data['orderNo']);
        $qrUrl = $data['qrUrl'];
        return view($this->view,compact('qrUrl','orderInfo'));
    }

    public function apiQueryUrl(Request $request){
        $data = $request->except('_token');
        $orderInfo = $this->repo->getDataByOrderNo($data['orderNo']);
        $code = 404;
        $url = '';
        if($orderInfo->status == $this->const->orderFinish){
            $code = 200;
            $url = url('message/success');
        }
        return ajaxReturn($code,'',$url);
    }

    //代付
    public function dfCallback(Request $request,$orderNo){
        return $this->repo->dfCallback($request,$orderNo);
    }
}
