<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Payment\AddValidate;
use App\Http\Requests\Payment\EditValidate;
use Illuminate\Http\Request;

class PaymentController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('const','request','data'));
    }

    public function add(AddValidate $request){
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        $const = $this->const;
        $thirds = $this->getOtherRepo('third')->getNormalData();
        $categories = $this->getOtherRepo('category')->getNormalData();
        return view($this->view,compact('const','thirds','categories'));
    }
    public function edit(EditValidate $request,$id=""){
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $const = $this->const;
        $data = $this->repo->getDataById($id);
        $thirds = $this->getOtherRepo('third')->getNormalData();
        $categories = $this->getOtherRepo('category')->getNormalData();
        return view($this->view,compact('const','data','thirds','categories'));
    }
    public function copy($id=""){
        $const = $this->const;
        $data = $this->repo->getDataById($id);
        $thirds = $this->getOtherRepo('third')->getNormalData();
        $categories = $this->getOtherRepo('category')->getNormalData();
        return view($this->view,compact('const','data','thirds','categories','id'));
    }

    public function test(Request $request,$id = ""){
        if($request->isMethod('post')){
            return $this->repo->test($request,$id);
        }
        $data = $this->repo->getDataById($id);
        $const = $this->const;
        return view($this->view,compact('id','data','const'));
    }
    public function onlineTest(Request $request,$id = ""){
        if($request->isMethod('post')){
            return $this->repo->test($request,$id);
        }
        $data = $this->repo->getDataById($id);
        $const = $this->const;
        return view($this->view,compact('id','data','const'));
    }
    public function publish(Request $request,$id = ""){
        if(getMe('auth') != $this->const->superAuth){
            if(getMe('id') != $this->repo->getDataById($id)->member_id){
                return back();
            }
        }
        if($request->isMethod('post')){
            return $this->repo->publish($request,$id);
        }
        $const = $this->const;
        return view($this->view,compact('id','const'));
    }

    public function fpublish(Request $request,$id = ""){
        if(getMe('auth') != $this->const->superAuth){
            return ajaxReturn(400,'您没有权限');
        }
        return $this->repo->fpublish($id);
    }
    public function down($id = ""){
        if(getMe('auth') != $this->const->superAuth){
            if(getMe('id') != $this->repo->getDataById($id)->member_id){
                return back();
            }
        }
        return $this->repo->down($id);
    }

    public function mobile(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('request','data'));
    }
}
