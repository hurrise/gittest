<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Role\AddValidate;
use App\Http\Requests\Role\EditValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RoleController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('request','data','const'));
    }
    public function add(AddValidate $request){
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        $const = $this->const;
        $auth = $this->getOtherRepo('auth')->getAuthTree();
        return view($this->view,compact('const','auth'));
    }

    public function edit(EditValidate $request,$id = ""){
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        $myAuths = [];
        foreach ($data->auths as $k=>$v){
            $myAuths[] = $v->id;
        }
        $const = $this->const;
        $auth = $this->getOtherRepo('auth')->getAuthTree();
        return view($this->view,compact('data','const','auth','myAuths'));
    }
}
