<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class IndexController extends BaseController
{
    public function index(){
        $const = $this->const;
        return view($this->view,compact('const'));
    }
    public function login(Request $request){
        if($request->isMethod('post')){
            return $this->repo->login($request);
        }
        return view($this->view);
    }
    public function logout(){
        session()->forget('user');
        return redirect(url('admin/index/login'));
    }
}
