<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;

class PaymentController extends BaseController
{
    public function payways(Request $request){
        $da = $request->all();
        $origin = $this->getOriginData($da);
        customWriteLog('payData',json_encode($origin));
        $this->goCheck($origin,$this->allowField['payways']);
        $data = $this->getOtherRepo('payment')->getPublishedData();
        $tmp = [];
        foreach ($data as $k=>$v){
            $tmp[$k]['pay_name'] = $v->name;
            $tmp[$k]['pay_uname'] = $v->uname;
            $tmp[$k]['mechine'] = 1;
            $tmp[$k]['paytype'] = $v->category->uname;
            $tmp[$k]['gateway_address'] = $v->gateway;
            if($v->is_bank == $this->const->is_bank_yes){
                if(!empty($v->bank_info)) {
                    $bank_info = explode('|', $v->bank_info);
                    $tmp1 = [];
                    foreach ($bank_info as $key => $val) {
                        $bank = explode('=', $val);
                        if(!empty($bank[0]) && !empty($bank[1])){
                            $tmp1[$bank[0]] = $bank[1];
                        }
                    }
                    $tmp[$k]['bank_info'] = $tmp1;
                }
            }
        }
        return $this->ajaxReturn(200,'获取成功',$tmp);
    }
}
