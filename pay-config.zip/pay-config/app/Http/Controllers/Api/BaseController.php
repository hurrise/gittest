<?php

namespace App\Http\Controllers\Api;

use App\Lib\ParamsException;
use App\Lib\PlatformException;
use App\Lib\SignException;
use App\Service\FactoryService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    protected $allowField = [
        'payways' => [
            'platform_id',
            'timestamp',
            'sign',
        ],
    ];
    protected $const;
    function __construct()
    {
        $this->const = FactoryService::getInstance()->generateService('const');
    }

    public function ajaxReturn($code=200,$msg="success",$data=[]){
        $arr = [
            'errorCode' => $code,
            'msg' => $msg,
            'data' => $data,
        ];
        return response()->json($arr);
    }
    public function getOtherRepo($repoName = ""){
        $otherRepo = FactoryService::getInstance()->generateRepository($repoName,$repoName);
        return $otherRepo;
    }
    public function getOriginData($data){
        if(empty($data['ciphertext'])){
            throw new ParamsException(['code'=>200,'msg'=>'ciphertext未传','errorCode'=>3001]);
        }
        $originData = json_decode(base64_decode($data['ciphertext']),true);
        return $originData;
    }
    public function goCheck($origin,$allowField=""){
        $this->checkFeild($origin,$allowField);
        $this->checkSign($origin);
    }
    public function checkSign($origin){
        $oldSign = $origin['sign'];
        unset($origin['sign']);
        $platform = $this->getOtherRepo('platform')->getDataByKey($origin['platform_id']);
        if(empty($platform)){
            throw new PlatformException(['msg'=>'平台id不存在','errorCode'=>1002]);
        }
        if($oldSign != getSign($origin,$platform->platform_secret)){
            throw new SignException();
        }
    }
    public function checkFeild($feild,$allowField){
        foreach ($feild as $k=>$v){
            if(!in_array($k,$allowField)){
                throw new ParamsException(['code'=>200,'msg'=>'不需要的键名:'.$k,'errorCode'=>3004]);
            }
        }
        foreach ($allowField as $k=>$v){
            if (!array_key_exists($v, $feild)) {
                throw new ParamsException(['code' => 200, 'msg' => '必传参数:' . $v, 'errorCode' => 3005]);
            }
        }
    }
}
