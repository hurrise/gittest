<?php

namespace App\Console\Commands;

use App\Service\ConstService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class clear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'clear:order';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'clear orders of yesterday in paying';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $endTime = strtotime(date('Ymd').'-1day'); //今天凌晨0:00的unix时间戳
        $const = new ConstService();
        $timeRange = [$endTime - $const->daySeconds,$endTime-1];
        DB::table('order')->where('status',$const->orderPaying)->whereBetween('created_at',$timeRange)->delete();
        Log::info('任务调度'.date('Y-m-d H:i:s').PHP_EOL);
    }
}
