<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/15 0015
 * Time: 14:17
 */

function get_real_ip() {
    $ip = false;
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
        if ($ip) {
            array_unshift($ips, $ip);
            $ip = FALSE;
        }
        for ($i = 0; $i < count($ips); $i++) {
            if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                $ip = $ips[$i];
                break;
            }
        }
    }
    return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}

function getMe($key=""){
    if(!empty(session('user'))){
        if(empty($key)){
            return session('user');
        }
        return session('user')->$key;
    }
    return <<<STR
    layer.alert('登录失效',{icon: 2},function(){
        location.href = "/admin/login/index";
    });
STR;
}

function ajaxReturn($code=200,$msg="ok",$data=[]){
    return response()->json([
        'code' => $code,
        'msg' => $msg,
        'data' => $data,
    ]);
}

function formatBankInfo($bankInfo=""){
    $bankTmp = explode('|',$bankInfo);
    $banks = [];
    $bank_info = config('bankinfo');
    foreach ($bankTmp as $k=>$v){
        $tmp = explode('=',$v);
        $banks[$k]['key'] = $tmp[1];
        $banks[$k]['name'] = $bank_info[$tmp[0]]['name'];
    }
    return $banks;
}

function myTrim($str=""){
    return preg_replace("/\s/","",$str);
}

function getSign($data,$customKey){
    ksort($data);
    $signStr = '';
    foreach ($data as $k=>$v){
        $signStr .= $k.'='.$v.'&';
    }
    $signStr .= $customKey;
    $sign = md5($signStr);
    return $sign;
}

function customWriteLog($directory,$msg){
    $path = storage_path('logs/'.$directory.'/.log');
    $handlers[] = ($monolog = Log::getMonolog())->popHandler();
    Log::useDailyFiles($path);
    Log::info($msg);
    $monolog->setHandlers($handlers);
}

function curl_post($url,$data){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        return curl_error($ch);
    }
    curl_close($ch);
    return $result;
}

function myLog($data,$attach = '',$dir = 'postData'){
    $attach or $attach = '调用于'.debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT,1)[0]['line'].'行';
    $path = storage_path('logs/'.trim($dir,'/').'.log');
    $handlers[] = ($monolog = Log::getMonolog())->popHandler();
    Log::useFiles($path);
    Log::info($attach);
    Log::info($data);
    $monolog->setHandlers($handlers);
}