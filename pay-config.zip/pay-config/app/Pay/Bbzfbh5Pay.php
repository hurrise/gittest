<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/9 0009
 * Time: 12:10
 */

namespace App\Pay;


class Bbzfbh5Pay extends BasePay
{
    private $dataStruct = [
        'merchant_code' => null, //
        'service_type' => null, //
        'notify_url' => null, //
        'interface_version' => null, //
        'client_ip' => null, //
        'input_charset' => null, //
        'sign_type' => null, //
        'order_no' => null, //
        'order_time' => null, //
        'order_amount' => null, //
        'product_name' => null, //
        'product_code' => null, //
        'product_num' => null, //
        'product_desc' => null, //
        'extra_return_param' => null, //
        'extend_param' => null, //
        'sign' => null,
    ];
    public function dorechange($data=""){
        $postData = $this->getPostData();
        $res = $this->query($postData);
        $res  = json_decode(json_encode(simplexml_load_string($res)),true);
        if($res['response']['result_code'] == 0){
            return redirect(urldecode($res['response']['payURL']));
        }
        echo '第三方通道异常';
    }

    protected function getPostData($data=""){
        $this->dataStruct['merchant_code'] = $this->payInfo['merchant_code']; //
        $this->dataStruct['service_type'] = 'alipay_h5api'; //
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];//
        $this->dataStruct['interface_version'] = "V3.1"; //
        $this->dataStruct['client_ip'] = $_SERVER['REMOTE_ADDR']; //
        $this->dataStruct['sign_type'] = "RSA-S"; //
        $this->dataStruct['order_no'] = $this->payInfo['orderNo']; //
        $this->dataStruct['order_time'] = date('Y-m-d H:i:s',time()); //
        $this->dataStruct['order_amount'] = sprintf('%0.2f',$this->payInfo['money']); //
        $this->dataStruct['product_name'] = '积分充值'; //
        $this->dataStruct['product_code'] = null; //
        $this->dataStruct['product_num'] = null; //
        $this->dataStruct['product_desc'] = null; //
        $this->dataStruct['extra_return_param'] = 'bbh5'; //
        $this->dataStruct['extend_param'] = null; //
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    protected function getSign($data=""){
        $merchant_code = $data["merchant_code"];//商户号，123001002003是测试商户号，调试时要更换商家自己的商户号
        $service_type = $data["service_type"];//支付宝：alipay_scan
        $notify_url = $data["notify_url"];
        $interface_version =$data["interface_version"];
        $client_ip = $data["client_ip"];
        $sign_type = $data["sign_type"];
        $order_no = $data["order_no"];
        $order_time = $data["order_time"];
        $order_amount =$data["order_amount"];
        $product_name =$data["product_name"];
        $product_code = $data["product_code"];
        $product_num = $data["product_num"];
        $product_desc = $data["product_desc"];
        $extra_return_param =$data["extra_return_param"];
        $extend_param = $data["extend_param"];

/////////////////////////////   参数组装  /////////////////////////////////
        /**
        除了sign_type dinpaySign参数，其他非空参数都要参与组装，组装顺序是按照a~z的顺序，下划线"_"优先于字母
         */

        $signStr = "";
        $signStr = $signStr."client_ip=".$client_ip."&";
        if($extend_param != ""){
            $signStr = $signStr."extend_param=".$extend_param."&";
        }
        if($extra_return_param != ""){
            $signStr = $signStr."extra_return_param=".$extra_return_param."&";
        }
        $signStr = $signStr."interface_version=".$interface_version."&";
        $signStr = $signStr."merchant_code=".$merchant_code."&";
        $signStr = $signStr."notify_url=".$notify_url."&";
        $signStr = $signStr."order_amount=".$order_amount."&";
        $signStr = $signStr."order_no=".$order_no."&";
        $signStr = $signStr."order_time=".$order_time."&";
        if($product_code != ""){
            $signStr = $signStr."product_code=".$product_code."&";
        }
        if($product_desc != ""){
            $signStr = $signStr."product_desc=".$product_desc."&";
        }
        $signStr = $signStr."product_name=".$product_name."&";
        if($product_num != ""){
            $signStr = $signStr."product_num=".$product_num."&";
        }
        $signStr = $signStr."service_type=".$service_type;

/////////////////////////////   RSA-S签名  /////////////////////////////////



/////////////////////////////////初始化商户私钥//////////////////////////////////////
        $merchant_private_key= openssl_get_privatekey($this->getPrivateKey($this->payInfo['private_key'],64));
        openssl_sign($signStr,$sign_info,$merchant_private_key,OPENSSL_ALGO_MD5);
        $sign = base64_encode($sign_info);
        return $sign;
    }

    public  function verify($data=""){
        $merchant_code	= $data["merchant_code"];
        $interface_version = $data["interface_version"];
        $sign_type = $data["sign_type"];
        $dinpaySign = base64_decode($data["sign"]);
        $notify_type = $data["notify_type"];
        $notify_id = $data["notify_id"];
        $order_no = $data["order_no"];
        $order_time = $data["order_time"];
        $order_amount = $data["order_amount"];
        $trade_status = $data["trade_status"];
        $trade_time = $data["trade_time"];
        $trade_no = $data["trade_no"];
        $bank_seq_no = $data["bank_seq_no"];
        $extra_return_param = $data["extra_return_param"];

/////////////////////////////   参数组装  /////////////////////////////////
        /**
        除了sign_type dinpaySign参数，其他非空参数都要参与组装，组装顺序是按照a~z的顺序，下划线"_"优先于字母
         */

        $signStr = "";
        if($bank_seq_no != ""){
            $signStr = $signStr."bank_seq_no=".$bank_seq_no."&";
        }
        if($extra_return_param != ""){
            $signStr = $signStr."extra_return_param=".$extra_return_param."&";
        }
        $signStr = $signStr."interface_version=".$interface_version."&";
        $signStr = $signStr."merchant_code=".$merchant_code."&";
        $signStr = $signStr."notify_id=".$notify_id."&";
        $signStr = $signStr."notify_type=".$notify_type."&";
        $signStr = $signStr."order_amount=".$order_amount."&";
        $signStr = $signStr."order_no=".$order_no."&";
        $signStr = $signStr."order_time=".$order_time."&";
        $signStr = $signStr."trade_no=".$trade_no."&";
        $signStr = $signStr."trade_status=".$trade_status."&";
        $signStr = $signStr."trade_time=".$trade_time;

/////////////////////////////   RSA-S验证  /////////////////////////////////
        $dinpay_public_key = openssl_get_publickey($this->getPublicKey($this->payInfo['public_key'],64));
        $flag = openssl_verify($signStr,$dinpaySign,$dinpay_public_key,OPENSSL_ALGO_MD5);
///////////////////////////   响应“SUCCESS” /////////////////////////////
        if($flag){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    public function query($postdata){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$this->payInfo['gateway_address']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postdata));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response=curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}