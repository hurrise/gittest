<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/13 0013
 * Time: 17:04
 */

namespace App\Pay;


class HerylscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'appID' => $this->payInfo['merchant_code'],
            'tradeCode' => 60005,
            'randomNo' => rand(1,9999),
            'outTradeNo' => $this->payInfo['orderNo'],
            'totalAmount' => $this->payInfo['money']*100,
            'productTitle' => 'jfcz',
            'notifyUrl' => $this->payInfo['callback_url'],
            'tradeIP' => $this->get_real_ip(),
        ];
        $data['sign'] = $this->getSign($data);
        $postData = 'ApplyParams='.json_encode($data);
        $res = $this->curl_post($this->payInfo['gateway_address'],$postData);
        $res = json_decode($res,true);
        if($res['stateCode'] == '0000'){
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            $this->curlPayData['qrUrl'] = $res['payURL'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $res['stateInfo']??'第三方异常';
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
//        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
    public function getSign($data = ""){
        $data = $this->unsetNull($data);
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $v.'|';
        }
        $signStr .= $this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data = "")
    {
        $params = json_decode($data['NoticeParams'],true);
        $sign = $params['sign'];
        unset($params['sign']);
        if($sign == $this->getSign($params) && $params['payCode'] == '0000'){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}