<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class Szhqqh5Pay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData());
    }
    protected function getPostData(){
        $data = [
            'mchId' => $this->payInfo['merchant_code'],
            'pay_type' => 'qqweb',
            'amount' => $this->payInfo['money']*100,
            'time' => time(),
            'tradeNo' => $this->payInfo['orderNo'],
            'return_url' => $this->payInfo['redirect_url'],
            'notify_url' => $this->payInfo['callback_url'],
            'card_type' => 1,
            'yl_pay_type' => '',
            'bank_name' => '',
            'sign' => '',
            'extra' => 'shizihui',
            'client_ip' => get_real_ip()
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        $signStr = $data['tradeNo'].$data['amount'].$data['pay_type'].$data['time'].$data['mchId'].md5($this->payInfo['merchant_secret']);
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $signStr =  $data['tradeNo'].$data['orderNo'].$data['amount'].$data['mchId'].$data['pay_type'].$data['time'].md5($this->payInfo['merchant_secret']);
        if(strtolower(md5($signStr)) == $data['sign']){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}