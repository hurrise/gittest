<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/30 0030
 * Time: 13:46
 */

namespace App\Pay;


class Hfyzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mer_no' => $this->payInfo['merchant_code'],
            'orderno' => $this->payInfo['orderNo'],
            'cip' => $this->get_real_ip(),
            'amount' => $this->payInfo['money']*100,
            'subject' => 'jfcz',
            'type' => 1,
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
        ];
        $data['sign'] = md5("amount={$data['amount']}&cip={$data['cip']}&mer_no={$data['mer_no']}&notify_url={$data['notify_url']}&orderno={$data['orderno']}&return_url={$data['return_url']}&subject={$data['subject']}&type={$data['type']}&key=".$this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['status'] == 10000){
            $str ="<html><script> window.location.href ='".$res['data']."'; window.event.returnValue=false; </script><body></body></html>";
            return $str;
        }
        return $this->except($res['msg']);
    }
    public function verify($data = "")
    {
        customWriteLog('hfy',$data);
    }
}