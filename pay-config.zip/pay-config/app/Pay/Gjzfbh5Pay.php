<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/7 0007
 * Time: 16:08
 */

namespace App\Pay;


class Gjzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'appid' => $this->payInfo['merchant_code'],
            'orderid' => $this->payInfo['orderNo'],
            'money' => sprintf('%0.2f',$this->payInfo['money']),
            'paycode' => 'aliwap',
            'notifyurl' => $this->payInfo['callback_url'],
            'returnurl' => $this->payInfo['redirect_url'],
            'goodsname' => 'jfcz',
            'remark' => $this->payInfo['attach'],
            'istype' => null,
        ];
        $data['sign'] = $this->getSign($data);
        return $this->redirect($data,'post');
    }
    public function getSign($data=""){
        ksort($data);
        foreach ($data as $k=>$v){
            if(is_null($data[$k])){
                unset($data[$k]);
            }
        }
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k .'='. $v.'&';
        }
        $signStr .= 'appkey='.$this->payInfo['merchant_secret'];
        return md5($signStr);
    }
    public function verify($data = "")
    {
        $data = base64_decode($data['data']);
        $data = json_decode($data,true);
        if($data['status'] == 1){
            $sign = $data['sign'];
            unset($data['sign']);
            $newSign = $this->getSign($data);
            if($sign == $newSign){
                $this->res['flag'] = true;
            }
        }
        return $this->res;
    }
}