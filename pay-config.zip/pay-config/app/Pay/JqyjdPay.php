<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class JqyjdPay extends BasePay
{
    public function dorechange($data=""){
        $postData = $this->getPostData();
        $this->redirect($postData,'post');
    }
    protected function getPostData($data=""){
        $data = [];
        $data['pay_memberid'] = $this->payInfo['merchant_code'];
        $data['pay_orderid'] = $this->payInfo['orderNo'];
        $data['pay_applydate'] = date('Y-m-d H:i:s');
        $data['pay_bankcode'] = '910';
        $data['pay_notifyurl'] = $this->payInfo['callback_url'];
        $data['pay_callbackurl'] = $this->payInfo['redirect_url'];
        $data['pay_amount'] = $this->payInfo['money'];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = '积分充值';
        $data['pay_productname'] = 'jinqiangyu';
        $data['pay_productnum'] = 0;
        $data['pay_productdesc'] = '';
        $data['pay_producturl'] = '';
        $data['pay_orderuid'] = 0;
        return $data;
    }
    protected function getSign($data=[]){
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $sign = $data['sign'];
        unset($data['attach']);
        unset($data['sign']);
        $signA = $this->getSign($data);
        $this->res['flag'] = $sign == $signA;
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}