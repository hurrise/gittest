<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/25 0025
 * Time: 13:09
 */

namespace App\Pay;


class Qz58payzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'transType' => '1005',
            'instCode' => 'jfcz',
            'certType' => 0,
            'certId' => $this->payInfo['merchant_code'],
            'transAmt' => $this->payInfo['money']*100,
            'isType' => 1,
            'goodsDesc' => 'jfcz',
            'orderNo' => $this->payInfo['orderNo'],
            'orderUid' => uniqid(),
            'backUrl' => $this->payInfo['callback_url'],
            'returnUrl' => $this->payInfo['redirect_url'],
            'attach' => '58pay',
            'reType' => 2,
            'userIp' => get_real_ip(),
        ];
        $data['sign'] = $this->getSign($data);
        return $this->redirect($data,'post');
    }
    public function getSign($data=""){
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        return $sign;
    }
    public function verify($data = "")
    {
        $sign = $data['sign'];
        unset($data['sign']);
        $newSign = $this->getSign($data);
        if($sign == $newSign){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = '{"msg":"交易成功","code":0}';
        return $this->res;
    }
}