<?php

namespace App\Pay;

use App\Service\CurlService;

class AfylscanPay extends BasePay {

    public $post = [
        'payKey' => '',
        'orderPrice' => '',
        'outTradeNo' => '',
        'productType' => '',
        'orderTime' => '',
        'productName' => '',
        'orderIp' => '',
        'returnUrl' => '',
        'notifyUrl' => '',
        'remark' => '',
    ];

    public function getPostData($data = '') {
        $this->post['payKey'] = $this->payInfo['merchant_code'];
        $this->post['orderPrice'] = $this->payInfo['money'];
        $this->post['outTradeNo'] = $this->payInfo['orderNo'];
        $this->post['productType'] = '60000103';
        $this->post['orderTime'] = date('YmdHis');
        $this->post['productName'] = '积分充值';
        $this->post['orderIp'] = $this->get_real_ip();
        $this->post['returnUrl'] = $this->payInfo['redirect_url'];
        $this->post['notifyUrl'] = $this->payInfo['callback_url'];
        $this->post['remark'] = 'afzfbscan';
        $this->post['sign'] = $this->getSign($this->post);
        return $this->post;
    }

    public function getSign($param) {
        if (isset($param['sign'])) {
            unset($param['sign']);
        }
        ksort($param);
        $param = urldecode(http_build_query($param));
        $param = $param . '&paySecret=' . $this->payInfo['merchant_secret'];
        return strtoupper(md5($param));
    }

    public function dorechange($data = '') {
        $post = $this->getPostData($data);
        $json_data = CurlService::getInstance()->post_https($this->payInfo['gateway_address'], http_build_query($post));
        $res = json_decode($json_data, TRUE);
        if ($res['resultCode'] == '0000') {
            $this->curlPayData['qrUrl'] = $res['payMessage'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        } else {
            return $this->except($res['errMsg']); //todo 报错信息页面;
        }
    }

    public function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }

    public function verify($data = '') {
        $data = $this->unsetNull($data);
        $old_sign = $data['sign'];
        if (isset($data['sign'])) {
            unset($data['sign']);
        }
        ksort($data);
        $param = urldecode(http_build_query($data));
        $param .= '&paySecret=' . $this->payInfo['merchant_secret'];
        $mysign = strtoupper(md5($param));
        $this->res['flag']= $mysign == $old_sign;
        $this->res['callback_param']="success";
        return $this->res;
    }

}
