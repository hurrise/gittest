<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/2
 * Time: 16:27
 */
namespace App\Pay;

class SbqzfbscanPay extends SbqPay
{
    protected function getPostData(){
        $data = [
            "service" => 'pay.alipay.codepay',
            "version" => '1.0',
            "charset" => 'UTF-8',
            "sign_type" => 'MD5',
            "merchant_id" => $this->payInfo['merchant_code'],
            "out_trade_no" => $this->payInfo['orderNo'],
            "goods_desc" => 'jfcz',
            "total_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "notify_url" => $this->payInfo['callback_url'],
            "return_url" => $this->payInfo['redirect_url'],
            "nonce_str" => str_random(8),
            'sign' => '',
        ];
        $data["sign"] = $this->getSign($data);
        return $data;
    }
}