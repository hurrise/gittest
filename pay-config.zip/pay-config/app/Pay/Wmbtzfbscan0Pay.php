<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/2/7
 * Time: 16:23
 */

namespace App\Pay;

class Wmbtzfbscan0Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'trade_no' => $this->payInfo['orderNo'],
            'channel' => 0,
            'money' => $this->payInfo['money']*100,
            'shop_id' => $this->payInfo['merchant_code'],
            'tzurl' => $this->payInfo['callback_url'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data,$this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'],http_build_query($data));
        $res = json_decode($res,true);
        if(@$res['status'] == 1){
            return redirect($res['data']['url']);
        }
        echo @$res['status'] . ($data['message'] ?? '第三方通道异常');
    }

    protected function getSign($data = [],$key)
    {
        unset($data['sign']);
        ksort($data);
        @$data['tzurl'] and $tzurl = urlencode($data['tzurl']) and $data['tzurl'] = '%s';
        $signStr = urldecode(http_build_query($data));
        @$data['tzurl'] and $signStr = sprintf($signStr,$tzurl);
        $signStr .= '&token='.$key;
        return md5(strtolower($signStr));
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['status'] == '1' && $data['money'] == $data['pay_money'] && $this->getSign($data,$this->payInfo['merchant_secret']) == $data['sign'];
        $this->res['callback_param'] = '{"code":1,"msg":"ok"}';
        return $this->res;
    }
}