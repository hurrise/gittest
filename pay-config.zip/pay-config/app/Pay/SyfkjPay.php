<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/26
 * Time: 11:01
 */

namespace App\Pay;

class SyfkjPay extends SyfPay
{
    public function dorechange($data = "")
    {
        $data = [
            'parter' => $this->payInfo['merchant_code'],
            'orderid' => $this->payInfo['orderNo'],
            'value' => sprintf('%0.2f', $this->payInfo['money']),
            'type' => 1962,
            'callbackurl' => $this->payInfo['callback_url'],
            'hrefbackurl' => $this->payInfo['redirect_url'],
            'attach' => 'jfcz',
            'sign' => 'jfcz',
        ];
        $data['sign'] = md5('parter='.$data['parter'].'&type='.$data['type'].'&value='.$data['value'].'&orderid='.$data['orderid'].'&callbackurl='.$data['callbackurl'].$this->payInfo['merchant_secret']);
        return $this->redirect($data, 'post');
    }
}