<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/23
 * Time: 17:30
 */

namespace App\Pay;

class HyfwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'trxMerchantNo' => $this->payInfo['merchant_code'],
            'memberGoods' => $this->payInfo['orderNo'],
            'requestAmount' => sprintf('%0.2f', $this->payInfo['money']),
            'productNo' => 'WX-JS',
            'trxMerchantOrderno' => $this->payInfo['orderNo'],
            'noticeSysaddress' => $this->payInfo['callback_url'],
            'noticeWebaddress' => $this->payInfo['redirect_url'],
            'hmac' => 'jfcz',
        ];
        $data['hmac'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'], http_build_query($data));
        $data = json_decode($res, true);
        if ($data['code'] == '00000' && $this->getSign($data) == $data['hmac']) {
            $this->curlPayData['qrUrl'] = $data['payUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo @$data['code'] . ($data['message'] ?? '第三方通道异常');
    }

    protected function getSign($data = [])
    {
        unset($data['hmac']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . '&key=' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $str = 'reCode='.$data['reCode'].'&trxMerchantNo='.$data['trxMerchantNo'].'&trxMerchantOrderno='.$data['trxMerchantOrderno'].'&result='.$data['result'].'&productNo='.$data['productNo'].'&memberGoods='.$data['memberGoods'].'&amount='.$data['amount'].'&key='.$this->payInfo['merchant_secret'];
        $this->res['flag'] = $data['result'] == 'SUCCESS' && md5($str) == $data['hmac'];
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}