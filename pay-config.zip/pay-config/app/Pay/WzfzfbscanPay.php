<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-08
 * Time: 09:09
 */

namespace App\Pay;

class WzfzfbscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url=$this->payInfo['gateway_address'].'?data='.json_encode($this->getPostData($data));
            $callback = $this->wzf_curl_get($url);
            if($callback->statue=="1"){
                $this->curlPayData['qrUrl'] = $callback->alipayUrl;
                $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
                return $this->qrRedirect($this->curlPayData);
            }
            $message = $callback->message;
            return $this->except($message);
        }catch (\Exception $exception){
            return $this->except();
        }
        
    }
    
    protected function getPostData(){
        $data = [
            "appid" => $this->payInfo['merchant_code'],
            "orderno" => $this->payInfo['orderNo'],
            "amount" => sprintf('%0.2f',$this->payInfo['money']),
            "returnurl" => $this->payInfo['callback_url'],
            "remark" => 'WZFzfbscan',   //订单描述
            "paytype" => '2',   //支付模式
        ];
        $data['sign'] = $this->getSign($data,true);
        return $data;
    }

    protected function getSign($data = "",$flag=false){
        if($flag){
            $Str=$data['appid'].$data['orderno'].$data['amount'].$data['paytype'].$data['returnurl'];
            $stringSignTemp= $Str.$this->payInfo['merchant_secret'];
            $Str =strtoupper(md5($stringSignTemp));
        }else{
            $Str=$data['notifyid'].$data['orderno'].$data['amount'].$data['body'];
            $stringSignTemp= $Str.$this->payInfo['merchant_secret'];
            $Str =md5($stringSignTemp);
        }
        return $Str;
    }
    
    public function verify($data=""){
        if($data['result_code']=="200" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function wzf_curl_get($url){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                // Set Here Your Requesred Headers
                'Content-Type: application/json',
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return json_decode($response);
        }
    }
}