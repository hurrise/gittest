<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/29
 * Time: 20:40
 */

namespace App\Pay;

use App\Service\CurlService;

class TtfwxscanPay extends BasePay {
    private $dataStruct = [
        'api_user' => null,
        'price' => null,
        'type' => null,
        'redirect' => null,
        'order_id' => null,
        'order_info' => null,
        'signature' => null
    ];

    public function dorechange($data = '') {
        $res = CurlService::getInstance()->post($this->payInfo['gateway_address'], $this->getPostData());
        $res = json_decode($res, true);
        if ($res['code'] == 200) {
            $this->curlPayData['qrUrl'] = $res['info']['pay_url'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $this->errorRedirect('请求支付订单失败:['.$res['code'].']'.$res['message']);
    }

    protected function getPostData($data = "") {
        $this->dataStruct['api_user'] = $this->payInfo['merchant_code'];
        $this->dataStruct['price'] = $this->payInfo['money'];
        $this->dataStruct['type'] = $this->payInfo['extend1'];
        $this->dataStruct['redirect'] = $this->payInfo['redirect_url'];
        $this->dataStruct['order_id'] = $this->payInfo['orderNo'];
        $this->dataStruct['order_info'] = 'test';
        $this->dataStruct['signature'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data){
        unset($data['signature']);
        $data['api_key'] = $this->payInfo['merchant_secret'];
        ksort($data);
        $str = '';
        foreach ($data as $v) {
            $str .= $v;
        }
        return strtolower(md5($str));
    }

    public function verify($data=""){
        customWriteLog('verify',json_encode($data));
        $sign =strtolower(
            md5(
                $this->payInfo['merchant_secret'].  //商户密钥
                $data['order_id'].                     //商户订单号
                $data['order_info'].                //商户订单信息
                $data['price'].                      //订单金额
                $data['real_price'].                  //实际支付的金额
                $data['ttf_order_id']             //支付订单号
            )
        );
        if ($data['signature'] == $sign){
            return true;
        }
        return false;
    }
}
