<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/14 0014
 * Time: 15:14
 */

namespace App\Pay;


use App\Service\RsaService;

class XinfzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'version' => 'V3.3.0.0',
            'merchNo' => $this->payInfo['merchant_code'],
            'payType' => 'ZFB',
            'randomNum' => rand(1,9999)."",
            'orderNo' => $this->payInfo['orderNo'],
            'amount' => ($this->payInfo['money']*100)."",
            'goodsName' => 'jfcz',
            'notifyUrl' => $this->payInfo['callback_url'],
            'notifyViewUrl' => $this->payInfo['redirect_url'],
            'charsetCode' => 'UTF-8',
        ];
        $data['sign'] = $this->getSign($data);
        $rsa = new RsaService();
        $res = $rsa->setPublicKey($this->payInfo['public_key'])->publicKeyToEncrypt($data)->getEncryptData();
        $postData = [
            'data' => $res,
            'merchNo' => $this->payInfo['merchant_code'],
        ];
        $res = $this->curl_post($this->payInfo['gateway_address'],$postData);
        $res = json_decode($res,true);
        if($res["stateCode"] == '00'){
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            $this->curlPayData['qrUrl'] = $res["qrcodeUrl"];
            return $this->qrRedirect($this->curlPayData);
        }
        return $res["msg"]??"通道异常";
    }
    protected function getSign($data = ""){
        ksort($data);
        $data = json_encode($data);
        $signStr = $data.$this->payInfo['merchant_secret'];

        $sign = strtoupper(md5(str_replace("\\","",$signStr)));
        customWriteLog('xinf',['signStr'=>$signStr,'sign'=>$sign]);
        return $sign;
    }
    public function verify($data = "")
    {
        $rsa = new RsaService();
        $res = $rsa->setPrivateKey($this->payInfo['private_key'])->privateKeyToDecrypt($data['data'])->getDecryptData();
        $sign = $res['sign'];
        unset($res['sign']);
        if($this->getSign($res) == $sign && $res['stateCode'] == '00'){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}