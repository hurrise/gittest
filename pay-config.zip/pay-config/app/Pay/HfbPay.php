<?php
namespace App\Pay;


class HfbPay extends BasePay
{
    protected $dataStruct = [];

    public function dorechange($data="")
    {
        $postData = $this->getPostData();
        return $this->redirect($postData,'post');
    }

    protected function getPostData(){
        $this->dataStruct['version'] = 1;
        $this->dataStruct['is_phone'] = $this->payInfo['extend2'];
        $this->dataStruct['agent_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['agent_bill_id'] = $this->payInfo['orderNo'];
        $this->dataStruct['agent_bill_time'] = date('YmdHis');
        $this->dataStruct['pay_type'] = $this->payInfo['extend1'];
        $this->dataStruct['pay_amt'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        $this->dataStruct['user_ip'] = $this->getUserIp();
        $this->dataStruct['goods_name'] = 'jfcz';
        $this->dataStruct['goods_num'] = '';
        $this->dataStruct['remark'] = '';
        $this->dataStruct['goods_note'] = '';
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data){
        unset($data['goods_name']);
        unset($data['goods_num']);
        unset($data['remark']);
        unset($data['goods_note']);
        unset($data['is_phone']);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        return strtolower(md5($signStr));
    }

    public function verify($data = ''){
        //支付成功
        if(isset($data['result']) && $data['result'] == 1){
            $sign = $data['sign'];
            unset($data['pay_message']);
            unset($data['sign']);
            $sign_str = '';
            foreach ($data as $k=>$v){
                $sign_str .= $k.'='.$v.'&';
            }
            $sign_str .= 'key='.$this->payInfo['merchant_secret'];
             $sign_tmp = strtolower(md5($sign_str));
            if($sign == $sign_tmp){
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }

    protected function getUserIp(){
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        $user_ip =  $ip ? $ip : $_SERVER['REMOTE_ADDR'];
        $user_ip = str_replace('.','_',$user_ip);
        return $user_ip;
    }
}