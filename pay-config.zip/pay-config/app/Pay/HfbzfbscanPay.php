<?php
namespace App\Pay;


class HfbzfbscanPay extends HfbPay
{
    protected function getPostData(){
        $this->dataStruct['version'] = 1;
        $this->dataStruct['is_phone'] = null;
        $this->dataStruct['agent_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['agent_bill_id'] = $this->payInfo['orderNo'];
        $this->dataStruct['agent_bill_time'] = date('YmdHis');
        $this->dataStruct['pay_type'] = 22;
        $this->dataStruct['pay_amt'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        $this->dataStruct['user_ip'] = $this->getUserIp();
        $this->dataStruct['goods_name'] = 'jfcz';
        $this->dataStruct['goods_num'] = '';
        $this->dataStruct['remark'] = '';
        $this->dataStruct['goods_note'] = '';
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
}