<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/20
 * Time: 18:48
 */

namespace App\Pay;

use App\Pay\Unit\RsaUnit;

class PjzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchant_id' => $this->payInfo['merchant_code'],
            'total_amount' => $this->payInfo['money']*100,
            'subject' => 'jfcz',
            'body' => 'jfcz',
            'out_trade_no' => $this->payInfo['orderNo'],
            'notify_url' => base64_encode($this->payInfo['callback_url']),
            'sign' => 'jfcz',
        ];
        $data['sign'] = (new RsaUnit())->setPrivateKey($this->payInfo['private_key'])->grantSignByPrivateKey($this->getSignStr($data))->getSign();
        $res = curl_post($this->payInfo['gateway_address'], $data);
        $data = json_decode($res, true);
        if ($data['errcode'] === '0') {
            return redirect(base64_decode($data['data']['pay_url']));
        }
        $error = @$data['errcode'];
        $error .= $data['errmsg'] ?? '第三方通道异常';
        echo $error;
    }

    protected function getSignStr($data = [])
    {
        unset($data['sign']);
        foreach ($data as $k => $v) {
            if($v === '' || $v === null)
                unset($data[$k]);
        }
        ksort($data);
        $str = urldecode(http_build_query($data));
        return $str;
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['status'] == 1 && (new RsaUnit())->setPublicKey($this->payInfo['public_key'])->verifySignByPublicKey($this->getSignStr($data),base64_decode($data['sign']));
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}