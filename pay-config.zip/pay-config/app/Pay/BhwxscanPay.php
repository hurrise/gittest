<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/18 0018
 * Time: 16:57
 */

namespace App\Pay;


class BhwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'account' => $this->payInfo['merchant_code'],
            'resqn' => $this->payInfo['orderNo'],
            'pay_amount' => sprintf('%0.2f',$this->payInfo['money']),
            'notify_url' => $this->payInfo['callback_url'],
            'pay_way' => '2',
            'pay_ip' => get_real_ip(),
            'body' => null,
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->getCode($data,$this->payInfo['gateway_address']);
        $res = json_decode($res,true);
        if(isset($res['status']) && $res['status'] == "0001"){
            $this->curlPayData['qrUrl'] = $res['url'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }else{
            return $this->except($res['msg']);
        }
    }
    protected function getSign($data=""){
        $data['key'] = $this->payInfo['merchant_secret'];
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            if($k == 'pay_ip' || $k == 'body'){}else {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = trim($signStr,'&');
        return md5($signStr);
    }
    protected function getCode($post_data, $url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $ret = curl_exec($ch);
        curl_close($ch);
        return $ret;
    }
    public function verify($data = "")
    {
        $this->res['callback_param'] = 'success';
        $sign = $data['mer_sign'];
        unset($data['mer_sign']);
        $newSign = $this->getSign($data);
        if($sign == $newSign){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}