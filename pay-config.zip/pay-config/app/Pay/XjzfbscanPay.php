<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/8
 * Time: 18:33
 */

namespace App\Pay;

class XjzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantno' => $this->payInfo['merchant_code'],
            'customno' => $this->payInfo['orderNo'],
            'stype' => 'AP',
            'notifyurl' => $this->payInfo['callback_url'],
            'money' => sprintf('%0.2f', $this->payInfo['money']),
            'timestamp' => (string)round(microtime(true)*1000),
            'buyerip' => $this->get_real_ip(),
            'productname' => 'jfcz',
            'sign' => 'jfcz',
        ];
        $signArr = [$data['merchantno'],$data['customno'],$data['stype'],$data['notifyurl'],$data['money'],$data['timestamp'],$data['buyerip']];
        $data['sign'] = $this->getSign($signArr);
        $res = $this->curl_post($this->payInfo['gateway_address'], $data);
        $res = json_decode($res, true);
        $data = $res['data'];
        try {
            $signArr = [$data['merchantno'],$data['type'],$data['orderno'],$data['customno'],$data['scanurl'],$data['tjmoney'],$data['status']];
        } catch (\Exception $e){
            die(env('APP_DEBUG') ? $e->getMessage() : '第三方通道异常');
        }
        if ($res['success'] == true && $this->getSign($signArr,'') == $data['sign']) {
            return redirect($data['scanurl']);
        }
        echo @$res['resultCode'] . ($res['resultMsg'] ?? '第三方通道异常');
    }

    protected function getSign($data = [],$glue = '|')
    {
        $data[] = $this->payInfo['merchant_secret'];
        return md5(join($glue,$data));
    }

    public function verify($data = '')
    {
        $signArr = [$data['merchantno'],$data['orderno'],$data['customno'],$data['type'],$data['tjmoney'],$data['money'],$data['status']];
        $this->res['flag'] = $data['status'] == 1 && $this->getSign($signArr) == $data['sign'];
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}