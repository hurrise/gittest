<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-12
 * Time: 03:05
 */

namespace App\Pay;

class ShunywxscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url =$this->shuny_curl_post($this->payInfo['gateway_address'],$this->getPostData($data));
            $dataarray = json_decode($url,true);
            if($dataarray['auth']=='SUCCESS'){
                $this->curlPayData['qrUrl'] = $dataarray['payInfo'];
                $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
                return $this->qrRedirect($this->curlPayData);
            }
            return $this->except($dataarray['errorMsg']);
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
           "version" => '1.0',   //版本号,
            "mer_no" => $this->payInfo['merchant_code'],
            "back_url" => $this->payInfo['callback_url'],
            "mer_order_no" => $this->payInfo['orderNo'],
            "gateway_type" => '002',   //支付类型(001微信wap,002微信扫码,003支付宝扫码,004QQ扫码,006支付宝wap,007微信公众号,018银联wap,012银联扫码,013京东扫码),
            "currency" => '156',   //交易币种,
            "trade_amount" => $this->payInfo['money'],
            "order_date" => date('Y-m-d H:i:s'),   //订单时间,
            "client_ip" => $this->get_real_ip(),   //客户端ip,
            "goods_name" => 'Shunywxscan',   //商品名称,
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['mer_return_msg'] = null;  //回传参数
        $data['trade_msg'] = null;  //交易请求信息
        $data['sign_type'] = 'MD5';  //签名方式
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="signType"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        //amount 实际支付金额
        if($data['tradeResult']=="1" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }

    protected function shuny_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded",
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}