<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/4
 * Time: 13:49
 */
namespace App\Pay;

class XmqqtmPay extends XmPay
{
    protected function getPostData(){
        $data = [
            'messageid' => 200001,
            "out_trade_no" => $this->payInfo['orderNo'],
            "back_notify_url" => $this->payInfo['callback_url'],
            "front_notify_url" => $this->payInfo['redirect_url'],
            "branch_id" => $this->payInfo['merchant_code'],
            'prod_name' => 'jfcz',
            'prod_desc' => 'jfcz',
            'client_ip' => get_real_ip(),
            "pay_type" => 51,
            "total_fee" => $this->payInfo['money']*100,
            "nonce_str" => str_random(16),
            'sign' => '',
        ];
        $data["sign"] = $this->getSign($data);
        return $data;
    }
}