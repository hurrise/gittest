<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/24 0024
 * Time: 16:21
 */

namespace App\Pay;


class LlzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'p1_MerchantNo' => $this->payInfo['merchant_code'],
            'p2_OrderNo' => $this->payInfo['orderNo'],
            'p3_Amount' => $this->payInfo['money'],
            'p4_Cur' => 1,
            'p5_ProductName' => '积分充值',
            'p6_NotifyUrl' => $this->payInfo['callback_url'],
        ];
        $data['sign'] = md5($data['p1_MerchantNo'].$data['p2_OrderNo'].$data['p3_Amount'].$data['p4_Cur'].$data['p5_ProductName'].$data['p6_NotifyUrl'].$this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        dd($res);
    }
    public function verify($data = "")
    {
//        $nowSign = md5($data['r1_MerchantNo'].$data['r2_OrderNo'].$data['r3_Amount'].$data['r4_Cur'].$data['r5_Status'].$data['ra_PayTime'].$data['rb_DealTime'].$this->payInfo['merchant_secret']);
//        if($nowSign == $data['sign'] && $data['r5_Status'] == 100){
//            $this->res['flag'] = true;
//        }

    }
}