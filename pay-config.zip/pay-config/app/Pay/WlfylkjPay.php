<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/18
 * Time: 16:38
 */

namespace App\Pay;

class WlfylkjPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'txnType' => '01',
            'txnSubType' => 22,
            'secpVer' => 'icp3-1.1',
            'secpMode' => 'perm',
            'macKeyId' => $this->payInfo['merchant_code'],
            'orderDate' => date('Ymd'),
            'orderTime' => date('His'),
            'merId' => $this->payInfo['merchant_code'],
            'orderId' => $this->payInfo['orderNo'],
            'txnAmt' => (int)($this->payInfo['money']*100),
            'currencyCode' => 156,
            'timeStamp' => date('YmdHis'),
            'notifyUrl' => $this->payInfo['callback_url'],
            'pageReturnUrl' => $this->payInfo['redirect_url'],
            'mac' => 'jfcz',
        ];
        $data['mac'] = $this->getSign($data);
        return $this->redirect($data, 'post');
    }

    protected function getSign($data = [])
    {
        unset($data['mac']);
        ksort($data);
        $signStr = '';
        foreach ($data as $k => $v) {
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'k=' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['txnStatus'] == '10' && $this->getSign($data) == $data['mac'];
        return $this->res;
    }
}