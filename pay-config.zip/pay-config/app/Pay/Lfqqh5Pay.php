<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/23
 * Time: 12:42
 */

namespace App\Pay;

class Lfqqh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'orderNo' => $this->payInfo['orderNo'],
            'randomNo' => (string)mt_rand(10000000,99999999),
            'merchNo' => $this->payInfo['merchant_code'],
            'netwayType' => 'QQ_WAP',
            'amount' => (string)($this->payInfo['money']*100),
            'goodsName' => '积分充值',
            'notifyUrl' => $this->payInfo['callback_url'],
            'notifyViewUrl' => $this->payInfo['redirect_url'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        ksort($data);
        $post = [
            'data' => urlencode($this->pubKeyEncrypt(json_encode($data),$this->getPublicKey($this->payInfo['public_key']))),
            'merchNo' => $this->payInfo['merchant_code'],
            'version' => 'V3.6.0.0'
        ];
        $data = urldecode(http_build_query($post));
        $res = $this->curl_post($this->payInfo['gateway_address'], $data);
        $data = json_decode($res, true);
        if ($data['stateCode'] == '00' && $this->getSign($data) == $data['sign']) {
            return redirect($data['qrcodeUrl']);
        }
        echo @$data['stateCode'].( $data['msg'] ?? '第三方通道异常' );
    }

    protected function priKeyDecrypt($data='',$priKey='')
    {
        $res = openssl_get_privatekey($priKey);
        $result  = '';
        foreach (str_split(base64_decode($data),128) as $item) {
            openssl_private_decrypt($item, $decrypt_data, $res);
            $result .= $decrypt_data;
        }
        openssl_free_key($res);
        return $result;
    }

    protected function pubKeyEncrypt($data='',$pubKey='')
    {
        $res = openssl_get_publickey($pubKey);
        $result  = '';
        foreach (str_split($data,openssl_pkey_get_details($res)['bits']/8-11) as $item) {
            openssl_public_encrypt($item, $encrypt_data, $res);
            $result .= $encrypt_data;
        }
        openssl_free_key($res);
        return base64_encode($result);
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        ksort($data);
        $signStr = stripslashes(json_encode($data,320)) . $this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        $data = $this->priKeyDecrypt($data['data'],$this->getPrivateKey($this->payInfo['private_key']));
        $data = json_decode($data,true);
        $this->res['flag'] = $data['returncode'] == '2' && $this->getSign($data,true) == $data['sign'];
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}