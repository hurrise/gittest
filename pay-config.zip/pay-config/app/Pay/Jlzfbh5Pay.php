<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class Jlzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        $res = $this->curl_post($this->payInfo['gateway_address'],http_build_query($this->getPostData()));
        $data = json_decode($res,true);
        if($data['code'] == '200'){
            return redirect($data['codeUrl']);
        }
        return $this->except($data['errorMsg']);
    }
    protected function getPostData(){
        $data = [
            'payKey' => $this->payInfo['merchant_code'],
            'orderPrice' => $this->payInfo['money'],
            'payType' => 'ALIPAY',
            'bankCode' => null,
            'orderNo' => $this->payInfo['orderNo'],
            'orderTime' => date('YmdHis'),
            'productName' => 'jfcz',
            'orderExp' => 5,
            'ipAddress' => get_real_ip(),
            'returnType' => 'json',
            'returnUrl' => $this->payInfo['redirect_url'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'remark' => '',
            'sign' => ''
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['bankCode'])){
            unset($data['bankCode']);
        }
        unset($data['sign']);
        unset($data['remark']);
        if(!isset($data['payKey'])){
            $data['payKey'] = $this->payInfo['merchant_code'];
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&paySecret='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=""){
        if($this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}