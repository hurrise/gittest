<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/21 0021
 * Time: 19:48
 */

namespace App\Pay;


class JiuybankPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_applydate' => date('Y-m-d H:i:s'),
            'pay_bankcode' => '907',
            'pay_bankid' => $this->payInfo['bank'],
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
            'pay_amount' => $this->payInfo['money'],
            'pay_attach' => 'jiuyu',
            'pay_productname' => 'jfcz',
            'pay_productnum' => null,
            'pay_productdesc' => null,
            'pay_producturl' => null,
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        return $this->redirect($data,'post');
    }
    public function getSign($data=""){
        $signStr = 'pay_amount='.$data['pay_amount'].'&pay_applydate='.$data['pay_applydate'].'&pay_bankcode='.$data['pay_bankcode'].'&pay_callbackurl='.$data['pay_callbackurl'].'&pay_memberid='.$data['pay_memberid'].'&pay_notifyurl='.$data['pay_notifyurl'].'&pay_orderid='.$data['pay_orderid'].'&key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data = "")
    {
        $signStr = 'amount=' . $data['amount'] . '&datetime=' . $data['datetime'] . '&memberid=' . $data['memberid'] . '&orderid=' . $data['orderid'] . '&returncode=' . $data['returncode'] . '&transaction_id=' . $data['transaction_id'] . '&key=' . $this->payInfo['merchant_secret'];
        $this->res['flag'] = $data['returncode'] == '00' && $data['sign'] == strtoupper(md5($signStr));
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}