<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-12-31
 * Time: 02:52
 */

namespace App\Pay;

class Tmzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try {
            $url = $this->wx_Post($this->payInfo['gateway_address'], $this->getPostData($data));
            customWriteLog('Tmzfbh5Pay','dorechange  '.$url);
            $urlarray = json_decode($url, true);
            if ($urlarray['resultCode'] == "9999") {
                $payMessage = json_decode($urlarray['payMessage'], true);
                return redirect($payMessage['qrcode']);
                /*header("location:".$payMessage['qrcode']);
                exit;*/
            }
            return $this->except($urlarray['errMsg']);
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
            "app_id" => $this->payInfo['merchant_code'],
            "method" => 'alipayhb',   //接口名称(alipayhb 支付宝红包,alipaypqr  支付宝扫码)
            "version" => '1.0',   //调用的接口版本
            "content" => '{"total_amount":"'.sprintf('%0.2f',$this->payInfo['money']).'","out_trade_no":"'.$this->payInfo['orderNo'].'","order_name":"tmzf","spbill_create_ip":"'.$this->get_real_ip().'","notify_url":"'.$this->payInfo['callback_url'].'","return_url":"'.$this->payInfo['redirect_url'].'"}',   //请求参数的集合
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['sign_type'] = "MD5";
        customWriteLog('Tmzfbh5Pay','getPostData  '.json_encode($data));
        return $data;
    }
    
    protected function getSign($data = ""){
        unset($data['sign']);
        unset($data['sign_type']);
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            $Str.=$k."=".$v."&";
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['status']=="1" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function wx_Post($url,$data,$way="POST"){ #'POST访问
        $ch = curl_init();
        curl_setoPt($ch, CURLOPT_URL, $url);
        curl_setoPt($ch, CURLOPT_CUSTOMREQUEST, $way);
        curl_setoPt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setoPt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setoPt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (comPatible; MSIE 5.01; Windows NT 5.0)');
        curl_setoPt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setoPt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setoPt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setoPt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmPInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmPInfo;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
}