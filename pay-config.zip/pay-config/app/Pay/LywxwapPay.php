<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-21
 * Time: 03:47
 */

namespace App\Pay;

class LywxwapPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return $this->except();
        }
        
    }
    
    protected function getPostData(){
        $data = [
           "mch_id" => $this->payInfo['merchant_code'],
            "trade_type" => '08',   //订单类型(交易类型,银行卡支付 10,银联扫码 11,银联快捷 12,微信扫码支付 01,微信WAP支付 08,支付宝支付 13,支付宝WAP支付 02,QQ扫码支付 05,QQWAP支付 06),
            "out_trade_no" => $this->payInfo['orderNo'],
            "total_fee" => $this->payInfo['money']*100,
            "bank_id" => "",   //支付银行,
            "notify_url" => $this->payInfo['callback_url'],
            "return_url" => $this->payInfo['redirect_url'],
            "time_start" => date('YmdHis'),   //订单生成时间,
            "nonce_str" => $this->payInfo['orderNo'],   //随机字符串,
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['body'] = null;  //商品描述
        $data['attach'] = null;  //附加信息
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }else{
                if($k=="notify_url" || $k=="return_url"){
                    $Str.=$k."=".urlencode($v)."&";
                }else{
                    $Str.=$k."=".$v."&";
                }
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        if($data['trade_state']=="SUCCESS" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}