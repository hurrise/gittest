<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-15
 * Time: 09:32
 */

namespace App\Pay;

class WfylkjPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return $this->except();
        }
        
    }
    
    protected function getPostData(){
        $data = [
            "trxType" => 'OnlineKuaiGatewayPay',   //交易类型,
            "r1_merchantNo" => $this->payInfo['merchant_code'],
            "r2_orderNumber" => $this->payInfo['orderNo'],
            "r3_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "r4_bankId" => null,   //银行编码,
            "r5_business" => null,   //业务类型,
            "r6_timestamp" => null,   //订单交易时间,
            "r7_goodsName" => null,   //商品名称,
            "r10_callbackUrl" => $this->payInfo['redirect_url'],
            "r11_serverCallbackUrl" => $this->payInfo['callback_url'],
            "r12_orderIp" => $this->get_real_ip(),   //发起IP,
            "r13_cardNo" => null,   //卡号,
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('WfylkjPay','postdata  '.json_encode($data));
        return $data;
    }
    
    protected function getSign($data = "",$falg =false){
        $Str='#';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$v."#";
            }
        }
        if($falg){
            $stringSignTemp= $Str.$this->payInfo['public_key'];
        }else{
            $stringSignTemp= $Str.$this->payInfo['merchant_secret'];
        }
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        customWriteLog('WfkjylkjPay',json_encode($data));
        $signdata=[
            "trxType" => $data['trxType'],
            "retCode" => $data['retCode'],
            "retMsg" => isset($data['retMsg'])?$data['retMsg']:null,
            "r1_merchantNo" => $data['r1_merchantNo'],
            "r2_orderNumber" => $data['r2_orderNumber'],
            "r3_amount" => $data['r3_amount'],
            "r7_completeDate" => $data['r7_completeDate'],
            "r8_orderStatus" => $data['r8_orderStatus'],
        ];
        if($data['retCode']=="0000" && $data['r8_orderStatus']=="SUCCESS" && $this->getSign($signdata,true) == $data['sign']){
            customWriteLog('WfkjylkjPay',"验签成功");
            $this->res['flag']=true;
        }else{
            customWriteLog('WfkjylkjPay',"验签失败");
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
}