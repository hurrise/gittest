<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/20
 * Time: 11:30
 */

namespace App\Pay;

class BkzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_applydate' => date("Y-m-d H:i:s"),
            'pay_amount' => sprintf('%0.2f', $this->payInfo['money']),
            'pay_bankcode' => 903,
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'bkzfbscan';
        $data['pay_productname'] = 'jfcz';
        return $this->redirect($data, 'post');
    }

    protected function getSign($data = [])
    {
        if(isset($data['sign']))
            unset($data['sign']);
        if(isset($data['attach']))
            unset($data['attach']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . '&key=' . $this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['returncode'] == '00' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}