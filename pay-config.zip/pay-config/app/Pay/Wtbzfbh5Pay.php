<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/13
 * Time: 21:02
 */

namespace App\Pay;

class Wtbzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'total_fee' => sprintf('%0.2f', $this->payInfo['money']),
            'subject' => 'jfcz',
            'order_no' => $this->payInfo['orderNo'],
            'payment_type' => 16,
            'description' => 'jfcz',
            'return_url' => $this->payInfo['redirect_url'],
            'callback_url' => $this->payInfo['callback_url']
        ];
        $encrypt_data = base64_encode($this->rsaEncrypt(urldecode(http_build_query($data)),$this->getPublicKey($this->payInfo['public_key'])));
        $res = $this->curl_post($this->payInfo['gateway_address'].$this->payInfo['merchant_code'],compact('encrypt_data'));
        $data = json_decode($res, true);
        if ($data['code'] == '0000') {
            return redirect($data['data']);
        }
        $error = isset($data['code']) ? $data['code'] : '';
        $error .= isset($data['msg']) ? $data['msg'] : '第三方通道异常';
        echo $error;
    }

    protected function rsaEncrypt($data='',$pubKey='')
    {
        $res = openssl_get_publickey($pubKey);
        $result  = '';
        foreach (str_split($data,117) as $item) {
            openssl_public_encrypt($item, $encrypt_data, $res);
            $result .= $encrypt_data;
        }
        openssl_free_key($res);
        return $result;
    }

    protected function rsaDecrypt($data='',$pubKey='')
    {
        $res = openssl_get_publickey($pubKey);
        $result  = '';
        foreach (str_split($data,128) as $item) {
            openssl_public_decrypt($item, $decrypt_data, $res);
            $result .= $decrypt_data;
        }
        openssl_free_key($res);
        return $result;
    }

    protected function getSign($data = [],$key='')
    {
        unset($data['sign']);
        foreach ($data as $k=>$v) {
            if($v === null || $v === '')
                unset($data[$k]);
            $data[$k] = str_replace('_','.',$v);
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$key;
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        $data = json_decode(array_keys($data)[0],true);
        if(isset($data['status']) && $data['status'] == 1 && $data['sign'] == $this->getSign($data,$this->payInfo['merchant_secret'])){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}