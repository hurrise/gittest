<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/17
 * Time: 14:33
 */

namespace App\Pay;


class GtbankPay extends BasePay
{
    public function getPostData()
    {
        $post = [
          'partner'=>$this->payInfo['merchant_code'],
          'banktype'=>$this->payInfo['bank'],
          'paymoney'=>$this->payInfo['money'],
          'ordernumber'=>$this->payInfo['orderNo'],
          'callbackurl'=>$this->payInfo['callback_url'],
          'hrefbackurl'=>$this->payInfo['redirect_url'],
          'attach'=>'gt',
        ];
        $post['sign'] = $this->getSign($post);
        return $post;
    }

    public function dorechange($data = '')
    {
        $params = $this->getPostData($data);
        $url  =  $this->payInfo['gateway_address']. '?' . http_build_query($params);
        header('location:' . $url);
    }

    public function getSign($data = [])
    {
        if(isset($data['hrefbackurl'])){
            unset($data['hrefbackurl']);
        }
        if(isset($data['attach'])){
            unset($data['attach']);
        }
       return  md5(urldecode(http_build_query($data))  . $this->payInfo['merchant_secret']);
    }
    public function verify($data = [])
    {
        $old_sign = $data['sign'];
        //不参与签名
        if(isset($data['sysnumber'])){
            unset($data['sysnumber']);
        }
        if(isset($data['attach'])){
            unset($data['attach']);
        }
        if(isset($data['sign'])){
            unset($data['sign']);
        }
        $mysign = md5(urldecode(http_build_query($data)). $this->payInfo['merchant_secret']);
        if($old_sign == $mysign){
            $this->res['flag']=true;
        }
        return $this->res;
    }
}