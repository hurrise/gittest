<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/15
 * Time: 10:51
 */

namespace App\Pay;

class XybPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mchntCode' => $this->payInfo['merchant_code'],
            'mchntOrderNo' => $this->payInfo['orderNo'],
            'orderAmount' => $this->payInfo['money']*100,
            'channelCode' => 'unionpay_qr',
            'notifyUrl' => $this->payInfo['callback_url'],
            'pageUrl' => $this->payInfo['redirect_url'],
            'body' => 'jfcz',
            'sign' => '',
            'subject' => 'jfcz',
            'description' => 'jfcz',
            'ts' => date('Y-m-d H:i:s').round(explode(' ',microtime())[0]*1000),
            'clientIp' => get_real_ip(),
            'orderTime' => date('YmdHis'),
            'orderExpireTime' => date('YmdHis',time()+300),
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'], json_encode($data));
        $data = json_decode($res, true);
        if (isset($data['retCode']) && $data['retCode'] == '0000' && $this->getSign($data) == $data['sign']) {
            $this->curlPayData['qrUrl'] = $data['codeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        $error = @$data['retCode'];
        $error .= $data['retMsg'] ?? '第三方通道异常';
        echo $error;
    }

    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        foreach ($data as $k=>$v) {
            if($v === null || $v === '')
                unset($data[$k]);
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data = '')
    {
        is_array($data) || ( $data = json_decode(file_get_contents('php://input','r'),true) );
        if($data['payResult'] == '1' && $this->getSign($data) == strtoupper($data['sign'])){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}