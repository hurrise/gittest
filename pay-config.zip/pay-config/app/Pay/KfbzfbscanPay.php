<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/8 0008
 * Time: 20:40
 */

namespace App\Pay;


class KfbzfbscanPay extends BasePay
{
    private $dataStruct = [
        'pay_memberid' => null,
        'pay_orderid' => null,
        'pay_applydate' => null,
        'pay_bankcode' => null,
        'pay_notifyurl' => null,
        'pay_callbackurl' => null,
        'pay_amount' => null,
        'pay_attach' => null,
        'pay_productname' => null,
        'pay_productnum' => null,
        'pay_producturl' => null,
        'pay_md5sign' => null,
    ];
    public function dorechange($data=""){
        $postData = $this->getPostData($data);
        return $this->redirect($postData,'post');
    }

    public function getPostData($data){
        $this->dataStruct['pay_memberid'] = $this->payInfo['merchant_code'];
        $this->dataStruct['pay_orderid'] = $this->payInfo['orderNo'];
        $this->dataStruct['pay_applydate'] = date('Y-m-d H:i:s');
        $this->dataStruct['pay_bankcode'] = 2;
        $this->dataStruct['pay_notifyurl'] = $this->payInfo['callback_url'];
        $this->dataStruct['pay_callbackurl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['pay_amount'] = $this->payInfo['money'];
        $this->dataStruct['pay_attach'] = 'krb';
        $this->dataStruct['pay_productname'] = 'jfcz';
        $this->dataStruct['pay_productnum'] = null;
        $this->dataStruct['pay_producturl'] = null;
        $this->dataStruct['pay_md5sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    private function getSign($data){
        $noSignField = [
            'pay_md5sign',
            'pay_attach',
            'pay_productname',
            'pay_productnum',
            'pay_productdesc',
            'pay_producturl',
        ];
        foreach ($data as $k=>$v){
            if(in_array($k,$noSignField)){
                unset($data[$k]);
            }
        }
        ksort($data);
        $strSign = '';
        foreach ($data as $k=>$v){
            $strSign .= $k . '=' . $v . '&';
        }
        $strSign .= 'key='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($strSign));;
        return $sign;
    }
    public function verify($data=""){
        $returnArray = array( // 返回字段
            "memberid" => $data["memberid"], // 商户ID
            "orderid" =>  $data["orderid"], // 订单号
            "amount" =>  $data["amount"], // 交易金额
            "datetime" =>  $data["datetime"], // 交易时间
            "transaction_id" =>  $data["transaction_id"], // 支付流水号
            "returncode" => $data["returncode"],
        );
        $md5key = $this->payInfo['merchant_secret'];
        ksort($returnArray);
        reset($returnArray);
        $md5str = "";
        foreach ($returnArray as $key => $val) {
            $md5str = $md5str . $key . "=" . $val . "&";
        }
        $sign = strtoupper(md5($md5str . "key=" . $md5key));
        if ($sign == $data["sign"]) {
            if ($data["returncode"] == "00") {
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}