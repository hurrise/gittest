<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-28
 * Time: 03:38
 */

namespace App\Pay;

class RcfylkjPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
    }
    
    protected function getPostData(){
        $data = [
           "merNo" => $this->payInfo['merchant_code'],
            "orderNo" => $this->payInfo['orderNo'],
            "transAmt" => sprintf('%s', $this->payInfo['money']*100), //单位为分
            "notifyUrl" => $this->payInfo['callback_url'],
            "returnUrl" => $this->payInfo['redirect_url'],
            "productId" => '0120',
            "requestNo" => $this->payInfo['orderNo'],   //请求流水号
            "transId" => '01',   //交易类型
            "orderDate" => date("Ymd"),   //订单日期
            "commodityName" => '银联快捷',   //商品名称
            "memo" => 'rcfzfbylkj',   //备注
        ];
        $data['signature'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['version'] = 'V4.0';  //版本号
        $data['cashier'] =  '1';  //是否展示收银台
        $data['bankCode'] = null;  //银行编号
        $data['payType'] = null;  //支付方式
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        unset($data['signature']);
        foreach ($data as $k=>$v){
            if(empty($v)){
                unset($data[$k]);
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= substr($Str,0,-1).$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        if($data['respCode'] == '0000' && $this->getSign($data) == $data['signature']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}