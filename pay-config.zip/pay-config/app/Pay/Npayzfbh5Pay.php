<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/23
 * Time: 17:58
 */

namespace App\Pay;

class Npayzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_amount' => sprintf('%0.2f', $this->payInfo['money']),
            'pay_applydate' => date('YmdHis'),
            'pay_channelCode' => 'ALIPAY_WAP',
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'sign' => 'jfcz',
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        return $this->redirect($data, 'post');
    }

    protected function getSign($data = [],$flag = false)
    {
        unset($data['sign']);
        $flag && ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v) {
            if($v != null && $v != '')
            $signStr .= $k.'^'.$v.'&';
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['returncode'] == '2' && $this->getSign($data,true) == $data['sign'];
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}