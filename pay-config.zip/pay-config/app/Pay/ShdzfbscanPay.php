<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/27 0027
 * Time: 13:14
 */

namespace App\Pay;


class ShdzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mid' => $this->payInfo['merchant_code'],
            'money' => $this->payInfo['money'],
            'did' => $this->payInfo['orderNo'],
            'notifyurl' => $this->payInfo['callback_url'],
            'paytype' => 1,
            'message' => 'jfcz',
        ];
        $data['sign'] = md5(md5($data['did'].$data['money'].$data['paytype'].$data['notifyurl']).$this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if(@$res['code'] === 0){
            $url = 'http://pay.ka7k5.cn/p.php?k='.$res['codekey'];
            return redirect($url);
        }
        echo @$res['code'].($res['msg']??'第三方通道异常');
    }
    public function verify($data = "")
    {
        $this->res['flag'] = $data['token'] == md5($this->payInfo['merchant_secret'].$data['merchant'].$data['did']);
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}