<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-08
 * Time: 11:28
 */

namespace App\Pay;

class Xcqqh5Pay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData());
    }
    protected function getPostData(){
        $data = [
            'parter' => $this->payInfo['merchant_code'],
            'b_type' => 9,
            'amount' => sprintf('%0.4f',$this->payInfo['money']),
            'orderid' => $this->payInfo['orderNo'],
            'callbackurl' => $this->payInfo['callback_url'],
            'hrefbackurl' => $this->payInfo['redirect_url'],
            'goodsinfo' => 'jfcz',
            'nonce_str' => str_random(32),
            'attach' => '',
        ];
        $signStr = 'amount='.$data['amount'].'&b_type='.$data['b_type'].'&callbackurl='.$data['callbackurl'].'&goodsinfo='.$data['goodsinfo'].'&nonce_str='.$data['nonce_str'].'&orderid='.$data['orderid'].'&parter='.$data['parter'].$this->payInfo['merchant_secret'];
        $data['sign'] = strtoupper(md5($signStr));
        return $data;
    }
    public function verify($data=''){
        $sign = strtoupper(md5($data['orderid'].$data['ovalue'].$this->payInfo['merchant_secret']));
        $this->res['flag'] = $data['opstate'] === '0' && $sign == $data['sign2'];
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}