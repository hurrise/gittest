<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/17
 * Time: 22:56
 */

namespace App\Pay;

class LfbwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'orderid' => $this->payInfo['orderNo'],
            'goodsname' => sprintf('%0.2f', $this->payInfo['money']),
            'istype' => 2,
            'notify_url' => $this->payInfo['callback_url'],
        ];
        $data['key'] = md5($data['goodsname'] . $data['istype'] . $data['notify_url'] . $data['orderid'] . $this->payInfo['merchant_secret'] . $data['uid']);
        $res = $this->curl_post($this->payInfo['gateway_address'], $data);
        $data = json_decode($res, true);
        if (@$data['code'] === 1) {
            return redirect($data['data']['pay_url']);
        }
        echo @$data['code'] . ($data['msg'] ?? '第三方通道异常');
    }

    public function verify($data = '')
    {
        $this->res['flag'] = md5($data['orderid'] . $data['orderuid'] . $data['platform_trade_no'] . $data['price'] . $this->payInfo['merchant_secret']) == $data['key'];
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}