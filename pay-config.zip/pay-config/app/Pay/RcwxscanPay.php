<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class RcwxscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            'charset' => "UTF-8",
            'merchantCode' => $this->payInfo['merchant_code'],
            'orderNo' => $this->payInfo['orderNo'],
            'amount' => $this->payInfo['money']*100,
            'channel' => 'BANK',
            'bankCode' => 'WEIXIN',
            'remark' => 'jfcz',
            'notifyUrl' =>$this->payInfo['callback_url'],
            'returnUrl' => $this->payInfo['redirect_url'],
            'extraReturnParam' => 'rongcan',
            'signType' => 'RSA',
            'sign' => '',
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        $signData = "charset={$data['charset']}&merchantCode={$data['merchantCode']}&orderNo={$data['orderNo']}"
            ."&amount={$data['amount']}&channel=BANK&bankCode={$data['bankCode']}&remark={$data['remark']}"
            ."&notifyUrl={$data['notifyUrl']}&returnUrl={$data['returnUrl']}&extraReturnParam={$data['extraReturnParam']}";
        $pi_key = openssl_pkey_get_private($this->getPrivateKey($this->payInfo['private_key']));
        openssl_sign($signData, $sign, $pi_key, OPENSSL_ALGO_SHA1);
        $sign = base64_encode($sign);
        $sign = urlencode($sign);
        $sign = str_replace( '%2F', '/', $sign );
        $sign = str_replace( '%3D', '=', $sign );
        $sign = str_replace( '%2B', '+', $sign );
        return $sign;
    }
    public function verify($arr=""){
        $public_key=openssl_get_publickey($this->getPublicKey($this->payInfo['public_key']));
        $sign=base64_decode($arr['sign']);
        $original_str="merchantCode=".$arr['merchantCode']."&orderNo=".$arr['orderNo']."&amount=".$arr['amount']."&successAmt=".$arr['successAmt']."&payOrderNo=".$arr['payOrderNo']."&orderStatus=".$arr['orderStatus']."&extraReturnParam=".$arr['extraReturnParam'];//Obtained data
        if(openssl_verify($original_str,$sign,$public_key,OPENSSL_ALGO_SHA1)){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
   }
}