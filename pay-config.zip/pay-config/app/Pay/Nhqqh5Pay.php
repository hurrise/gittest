<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/21
 * Time: 19:08
 */

namespace App\Pay;

class Nhqqh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'appId' => $this->payInfo['merchant_code'],
            'merchOrdrNo' => $this->payInfo['orderNo'],
            'totOrdrAmt' => sprintf('%0.2f', $this->payInfo['money']),
            'payType' => 'qq',
            'noteUrl' => $this->payInfo['callback_url'],
            'rtnUrl' => $this->payInfo['redirect_url'],
            'timeStamp' => date('YmdHis'),
            'extParm' => 'nhzfbscan',
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        $res = curl_post($this->payInfo['gateway_address'], $data);
        $data = json_decode($res, true);
        if (isset($data['status']) && $data['status'] === 0) {
            return redirect($data['data']['url']);
        }
        $error = @$data['status'];
        $error .= $data['msg'] ?? '第三方通道异常';
        echo $error;
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['resultStatus'] == 'SUCCESS' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}