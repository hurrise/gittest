<?php

namespace App\Pay;

class JtbankPay extends BasePay
{
    private $dataStruct = [
        'amount' => null,
        'callBackUrl' => null,
        'callBackViewUrl' => null,
        'charset' => null,
        'goodsName' => null,
        'merNo' => null,
        'netway' => null,
        'orderNum' => null,
        'random' => null,
        'version' => null,
        'sign' => null,
    ];
    public function dorechange($data = ''){
        $postData = $this->getPostData($data);
        $result = $this->goQuery($postData);
        if($this->json_to_array($result,$this->payInfo['merchant_secret'])){
            $result = json_decode($result,true);
            return redirect($result['qrcodeUrl']);
        }
    }
    protected function goQuery($data){
        //生成 json字符串
        $json = $this->json_encode_ex($data);
        //加密
        $dataStr =$this->encode_pay($json,$this->getPublicKey($this->payInfo['public_key']));
        //请求字符串
        $param = 'data=' . urlencode($dataStr) . '&merchNo=' . $data['merNo'] . '&version='.$data['version'];
        //请求地址
        $url= $this->payInfo['gateway_address'];
        //发起请求
        $result = $this->wx_post($url,$param);
        return $result;
    }
    //发起请求 返回 请求结果
    protected function wx_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmpInfo;
    }
    // 加密
    protected function encode_pay($data,$pay_public_key){#加密//
        $pu_key =  openssl_pkey_get_public($pay_public_key);
        if ($pu_key == false){
            return $this->except("打开密钥出错");
        }
        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $pu_key);
            $crypto = $crypto . $encryptData;
        }
        $crypto = base64_encode($crypto);
        return $crypto;
    }

    protected function getPostData($data){
        $this->dataStruct['amount'] = sprintf('%s',$this->payInfo['money']*100);
        $this->dataStruct['callBackUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['callBackViewUrl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['charset'] = 'UTF-8';
        $this->dataStruct['goodsName'] = 'jfcz';
        $this->dataStruct['merNo'] = $this->payInfo['merchant_code'];
        $this->dataStruct['netway'] = $this->payInfo['bank'];
        $this->dataStruct['orderNum'] = $this->payInfo['orderNo'];
        $this->dataStruct['random'] = (string)rand(1000,9999);
        $this->dataStruct['version'] = 'V3.1.0.0';
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    protected function getSign($data=""){
        unset($data['sign']);
        $sign = $this->create_sign($data,$this->payInfo['merchant_secret']);
        return $sign;
    }
    //生成签名的方法
    protected function create_sign($data,$key){
        ksort($data);
        $sign = strtoupper(md5($this->json_encode_ex($data) . $key));
        return $sign;
    }
    //判断 php版本 编译成 json字符串
    protected function json_encode_ex($value){
        if (version_compare(PHP_VERSION,'5.4.0','<')){
            $str = json_encode($value);
            $str = preg_replace_callback("#\\\u([0-9a-f]{4})#i","replace_unicode_escape_sequence",$str);
            $str = stripslashes($str);
            return $str;
        }else{
            return json_encode($value,320);
        }
    }

    // 对返回结果进行签名认证
    protected function json_to_array($json,$key){
        $array=json_decode($json,true);
        if ($array['stateCode'] == '00'){
            $sign_string = $array['sign'];
            ksort($array);
            $sign_array = array();
            foreach ($array as $k => $v) {
                if ($k !== 'sign'){
                    $sign_array[$k] = $v;
                }
            }
            // 生成签名 并将字母转为大写
            $md5 =  strtoupper(md5($this->json_encode_ex($sign_array) . $key));
            if ($md5 == $sign_string){
                return true;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public function verify($data=""){
        //解密
        $data = $this->decode($data['data'],$this->getPrivateKey($this->payInfo['private_key']));
        //效验 sign 签名
        $res = $this->callback_to_array($data, $this->payInfo['merchant_secret']);
        if($res){
            $this->res['flag']=true;
        }
        return $this->res;
    }
    //解密
    function decode($data,$private_content){
        //读取秘钥
        $pr_key = openssl_pkey_get_private($private_content);

        if ($pr_key == false){
            return $this->except("打开密钥出错");
        }
        $data = base64_decode($data);
        $crypto = '';
        //分段解密
        foreach (str_split($data, 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $pr_key);
            $crypto .= $decryptData;
        }
        return $crypto;
    }
    // 对返回结果进行签名认证
    function callback_to_array($json,$key){
        $array = json_decode($json,true);
        $sign_string = $array['sign'];
        ksort($array);
        $sign_array = array();
        foreach ($array as $k => $v) {
            if ($k !== 'sign'){
                $sign_array[$k] = $v;
            }
        }
        $md5 =  strtoupper(md5($this->json_encode_ex($sign_array) . $key));
        if ($md5 == $sign_string){
            return true;
        }else{
            return false;
        }
    }
}