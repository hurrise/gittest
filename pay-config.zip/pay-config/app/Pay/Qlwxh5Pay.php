<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-02-15
 * Time: 01:35
 */

namespace App\Pay;

class Qlwxh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return $this->except('');
        }
    }
    
    protected function getPostData(){
        $data = [
            "customerid" => $this->payInfo['merchant_code'],
            "sdorderno" => $this->payInfo['orderNo'],
            "total_fee" => sprintf('%0.2f',$this->payInfo['money']),
            "notifyurl" => $this->payInfo['callback_url'],
            "returnurl" => $this->payInfo['redirect_url'],
            "version" => '1.0',   //版本号
            "paytype" => 'wxh5',   //支付类型(支付宝扫码--alipay,微信扫码--weixin,支付宝wap--alipaywap,微信wap--wxh5,在线网银--bank,快捷支付--kuaijie)
            "bankcode" => '',   //银行编号(网银直连不可为空，其他支付方式可为)
        ];
        $data['sign'] = $this->getSign($data,true);
        return $data;
    }

    protected function getSign($data = "",$flag=false){
        if($flag){
            $Str='version='.$data['version'].'&customerid='.$data['customerid'].'&total_fee='.$data['total_fee'].'&sdorderno='.$data['sdorderno'].'&notifyurl='.$data['notifyurl'].'&returnurl='.$data['returnurl'];
        }else{
            $Str='customerid='.$data['customerid'].'&status='.$data['status'].'&sdpayno='.$data['sdpayno'].'&sdorderno='.$data['sdorderno'].'&total_fee='.$data['total_fee'].'&paytype='.$data['paytype'];
        }
        $stringSignTemp= $Str.'&'.$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['status']=="1" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }
}