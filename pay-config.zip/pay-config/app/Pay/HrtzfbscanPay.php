<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-08
 * Time: 02:41
 */

namespace App\Pay;

class HrtzfbscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    
    protected function getPostData(){
        $data = [
           "inputCharset" => 'utf-8',   //参数字符集编码,
            "notifyUrl" => $this->payInfo['callback_url'],
            "pageUrl" => $this->payInfo['redirect_url'],
            "payType" => 3,
            "merchantId" => $this->payInfo['merchant_code'],
            "orderId" => $this->payInfo['orderNo'],
            "transAmt" => sprintf('%0.2f',$this->payInfo['money']),
            "orderTime" => date('Y-m-d H:i:s'),   //商户订单时间,
//            "isPhone" => '1',   //是否 wap 支付，不传为扫码支付
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/

        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }if($v=="null"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str = md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        $this->res['flag'] = $data['status']==='1' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}