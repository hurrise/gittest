<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/10/28
 * Time: 13:37
 */
namespace App\Pay;

class SnebankPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            "versionId" => '001',
            "businessType" => '1100',
            "insCode" => '',
            "merId" => $this->payInfo['merchant_code'],
            "orderId" => $this->payInfo['orderNo'],
            "transDate" => date("YmdHis"),
            "transAmount" => sprintf('%0.2f',$this->payInfo['money']),
            "transCurrency" => '156',
            "transChanlName" => $this->payInfo['bank'],
            "openBankName" => '',
            "pageNotifyUrl" => $this->payInfo['redirect_url'],
            "backNotifyUrl" => $this->payInfo['callback_url'],
            "orderDesc" => 'jfcz',
            "dev" => '',
            "signData" => '',
        ];
        $data["signData"] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        unset($data['signData']);
        $signStr = '';
        foreach ($data as $key => $value) {
            $signStr .= $key.'='.$value.'&';
        }
        $signStr = trim($signStr,'&').$this->payInfo['merchant_secret'];
        return strtoupper(md5(iconv('utf-8','gbk//TRANSLIT',$signStr)));
    }
    public function verify($data=""){
        if($data['payStatus'] == '00' && $this->getSign($data) == $data['signData']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}