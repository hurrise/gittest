<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/21
 * Time: 23:47
 */

namespace App\Pay;

class Xfbzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'version' => '2.0',
            'currency' => '156',
            'order_date' => date('Y-m-d H:i:s'),
            'client_ip' => get_real_ip(),
            'goods_name' => 'jfcz',
            'mer_no' => $this->payInfo['merchant_code'],
            'mer_order_no' => $this->payInfo['orderNo'],
            'trade_amount' => sprintf('%0.0f', $this->payInfo['money']),
            'gateway_type' => '014',
            'back_url' => $this->payInfo['callback_url'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        $data['sign_type'] = 'MD5';
        $data['page_url'] = $this->payInfo['redirect_url'];
        return $this->redirect($data,'post');
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        if(isset($data['signType']))
            unset($data['signType']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . '&key=' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['tradeResult'] === '1' && $this->getSign($data) == $data['sign'];
        return $this->res;
    }
}