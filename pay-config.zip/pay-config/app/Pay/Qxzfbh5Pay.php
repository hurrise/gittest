<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/27
 * Time: 19:41
 */

namespace App\Pay;

class Qxzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'tradeType' => 'pay.submit',
            'version' => '1.7',
            'body' => 'jfcz',
            'settleCycle' => 0,
            'mchId' => $this->payInfo['merchant_code'],
            'outTradeNo' => $this->payInfo['orderNo'],
            'amount' => sprintf('%0.2f', $this->payInfo['money']),
            'channel' => 'alipayH5',
            'notifyUrl' => $this->payInfo['callback_url'],
            'callbackUrl' => $this->payInfo['redirect_url'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('QX',$data);
        $res = $this->curl_post($this->payInfo['gateway_address'],json_encode($data));
        $data = json_decode($res, true);
        if ($data['returnCode'] == '0' && $data['resultCode'] == '0' && $this->getSign($data) == $data['sign']) {
            return redirect($data['payCode']);
        }
        $error = isset($data['errCode']) ? $data['errCode'] : '';
        $error .= isset($data['errCodeDes']) ? $data['errCodeDes'] : '第三方通道异常';
        echo $error;
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . '&key=' . $this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        if($data['returnCode'] == '0' && $data['resultCode'] == '0' && $data['sign'] == $this->getSign($data)){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch,CURLOPT_HTTPHEADER,[
            'Content-Type:application/json;charset=utf-8'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}