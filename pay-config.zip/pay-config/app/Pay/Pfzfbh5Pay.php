<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-12-24
 * Time: 04:03
 */

namespace App\Pay;

class Pfzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->curl_post($this->payInfo['gateway_address'],$this->getPostData($data));
            $url = json_decode($url,true);
            if($url['status']=='success'){
                return $url['data'];
            }
            return $this->except($url['msg']);
        }catch (\Exception $exception){
            return $this->except();
        }
        
    }
    
    protected function getPostData(){
        $data = [
            "pay_memberid" => $this->payInfo['merchant_code'],
            "pay_orderid" => $this->payInfo['orderNo'],
            "pay_amount" => $this->payInfo['money'],
            "pay_notifyurl" => $this->payInfo['callback_url'],
            "pay_service" => '904',   //支付类型
            "pay_applydate" => date('Y-m-d H:i:s'),   //订单时间
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        customWriteLog("Pfzfbh5Pay",json_encode($data));
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v == ""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        if($data['returncode']=="00" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}