<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class CfylscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            "pay_memberid" => $this->payInfo['merchant_code'],
            "pay_orderid" => $this->payInfo['orderNo'],
            "pay_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "pay_applydate" => date("Y-m-d H:i:s"),
            "pay_bankcode" => 912,
            "pay_notifyurl" => $this->payInfo['callback_url'],
            "pay_callbackurl" => $this->payInfo['redirect_url'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'caifu';
        $data['pay_productname'] = 'jfcz';
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['attach'])){
            unset($data['attach']);
        }
        if(isset($data['sign'])){
            unset($data['sign']);
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=""){
        if($data['returncode'] === '00' && $this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
   }
}