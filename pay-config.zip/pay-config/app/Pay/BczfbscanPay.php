<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/15 0015
 * Time: 19:45
 */

namespace App\Pay;


class BczfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mchid' => $this->payInfo['merchant_code'],
            'order_id' => $this->payInfo['orderNo'],
            'channel_id' => 2,
            'total_amount' => $this->payInfo['money'],
            'return_url' => $this->payInfo['callback_url'],
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['status'] == 'true'){
            return redirect($res['url']);
        }
        return $res['msg']??'第三方通道异常';
    }
    protected function getSign($data = ""){
        // 对请求参数进行重新的排序
        ksort( $data, SORT_NATURAL | SORT_FLAG_CASE );
        // 服务端连接字符串
        $serverStr = "" ;
        // 拼接连接字符串
        foreach ( $data as $k => $v ) {
            $serverStr = $serverStr . $k . $v ;
        }
        $serverStr = $serverStr . $this->payInfo['merchant_secret'] ;
        $serverSign = strtoupper( sha1( $serverStr ) );
        return $serverSign;
    }
    public function verify($data = "")
    {
        $sign = $data['sign'];
        unset($data['sign']);
        if($sign == $this->getSign($data)){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}