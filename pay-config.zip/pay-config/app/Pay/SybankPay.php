<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/20 0020
 * Time: 11:04
 */

namespace App\Pay;


class SybankPay extends BasePay
{
    private $data = [
        'p0_Cmd' => null,
        'p1_MerId' => null,
        'p2_Order' => null,
        'p3_Amt' => null,
        'p4_Cur' => null,
        'p5_Pid' => null,
        'p6_Pcat' => null,
        'p7_Pdesc' => null,
        'p8_Url' => null,
        'p9_SAF' => null,
        'pa_MP' => null,
        'pd_FrpId' => null,
        'pr_NeedResponse' => null,
        'payerIp' => null,
        'hmac' => null,
    ];
    public function dorechange($data=""){
        $postData = $this->getPostData();
        return $this->redirect($postData,'get');
    }

    private function getPostData(){
        $this->data['p0_Cmd'] = 'Buy';
        $this->data['p1_MerId'] = $this->payInfo['merchant_code'];
        $this->data['p2_Order'] = $this->payInfo['orderNo'];
        $this->data['p3_Amt'] = $this->payInfo['money'];
        $this->data['p4_Cur'] = 'CNY';
        $this->data['p5_Pid'] = 'charge';
        $this->data['p6_Pcat'] = 'charge';
        $this->data['p7_Pdesc'] = 'charge';
        $this->data['p8_Url'] = $this->payInfo['callback_url'];
        $this->data['p9_SAF'] = $this->payInfo['redirect_url'];
        $this->data['pa_MP'] = 'sy';
        $this->data['pd_FrpId'] = $this->payInfo['bank'];
        $this->data['pr_NeedResponse'] = '1';
        $this->data['hmac'] = $this->getSign($this->data);
        return $this->data;

    }
    private function getSign($data){
        unset($data['hmac']);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $v;
        }
        $sign = $this->hmac($signStr,$this->payInfo['merchant_secret']);
        return $sign;
    }
    private function hmac($data, $key){
        if (function_exists('hash_hmac')) {
            return hash_hmac('md5', $data, $key);
        }

        $key = (strlen($key) > 64) ? pack('H32', 'md5') : str_pad($key, 64, chr(0));
        $ipad = substr($key,0, 64) ^ str_repeat(chr(0x36), 64);
        $opad = substr($key,0, 64) ^ str_repeat(chr(0x5C), 64);
        return md5($opad.pack('H32', md5($ipad.$data)));
    }

    public function verify($data = ""){
        $merchantId = $this->payInfo['merchant_code'];
        //Key
        $keyValue = $this->payInfo['merchant_secret'];

        $p1_MerId  		= $data['p1_MerId']; //p1_MerId	商户编号	Max(11)		1
        $r0_Cmd  		= $data['r0_Cmd']; //r0_Cmd	业务类型	Max(20)	固定值 ”Buy”.	2
        $r1_Code  		= $data['r1_Code']; //r1_Code	支付结果		固定值 “1”, 代表支付成功.	3
        $r2_TrxId  		= $data['r2_TrxId']; //r2_TrxId	平台交易流水号	Max(50)	平台订单号唯一	4
        $r3_Amt  		= $data['r3_Amt']; //r3_Amt	支付金额	Max(20)	单位:元，精确到分. 商户收到该返回数据后,一定用自己数据库中存储的金额与该金额进行比较.	5
        $r4_Cur  		= $data['r4_Cur']; //r4_Cur	交易币种	Max(10)	返回时是"RMB"	6
        $r5_Pid  		= $data['r5_Pid']; //r5_Pid	商品名称	Max(20)	同支付提交值。	7
        $r6_Order  		= $data['r6_Order']; //r6_Order	商户订单号	Max(50)	商户订单号.	8
        $r7_Uid  		= $data['r7_Uid']; //r7_Uid		Max(50)	固定留空.	9
        $r8_MP  		= $data['r8_MP']; //r8_MP	商户扩展信息	Max(200)	此参数如用到中文，请注意转码.	10
        $r9_BType  		= $data['r9_BType']; //r9_BType	交易结果返回类型	Max(1)	固定2	11
        $hmac  			= $data['hmac']; //hmac	签名数据	Max(32)

        $stringA = $p1_MerId.$r0_Cmd.$r1_Code.$r2_TrxId.$r3_Amt.$r4_Cur.$r5_Pid.$r6_Order.$r7_Uid.$r8_MP.$r9_BType;

        $verifyHmac = $this->HmacMd5($stringA,$keyValue);

        if($hmac == $verifyHmac && $r1_Code=="1"){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    function HmacMd5($data,$key)
    {
// RFC 2104 HMAC implementation for php.
// Creates an md5 HMAC.
// Eliminates the need to install mhash to compute a HMAC
// Hacked by Lance Rushing(NOTE: Hacked means written)

//需要配置环境支持iconv，否则中文参数不能正常处理
        $key = iconv("GB2312","UTF-8",$key);
        $data = iconv("GB2312","UTF-8",$data);

        $b = 64; // byte length for md5
        if (strlen($key) > $b) {
            $key = pack("H*",md5($key));
        }
        $key = str_pad($key, $b, chr(0x00));
        $ipad = str_pad('', $b, chr(0x36));
        $opad = str_pad('', $b, chr(0x5c));
        $k_ipad = $key ^ $ipad ;
        $k_opad = $key ^ $opad;

        return md5($k_opad . pack("H*",md5($k_ipad . $data)));
    }
}