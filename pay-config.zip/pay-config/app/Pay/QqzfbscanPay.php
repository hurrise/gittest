<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/13
 * Time: 14:37
 */

namespace App\Pay;

class QqzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'price' => sprintf('%0.2f', $this->payInfo['money']),
            'paytype' => 11,
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
            'user_order_no' => $this->payInfo['orderNo'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = md5($data['uid'] . $data['price'] . $data['paytype'] . $data['notify_url'] . $data['return_url'] . $data['user_order_no'] . $this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'], json_encode($data,JSON_UNESCAPED_SLASHES));
        $data = json_decode($res, true);
        is_array($data) or die('第三方通道异常');
        if (@$data['Code'] == 1) {
            $this->curlPayData['qrUrl'] = $data['callurl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo ($data['errorCode']??$data['Code']??'') . ($data['message'] ?? $data['Msg'] ?? '第三方通道异常');
    }

    public function verify($data = '')
    {
        $sign = md5($data['user_order_no'] . $data['orderno'] . $data['tradeno'] . $data['price'] . $data['realprice'] . $this->payInfo['merchant_secret']);
        $this->res['flag'] = $sign == $data['sign'];
        return $this->res;
    }

    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}