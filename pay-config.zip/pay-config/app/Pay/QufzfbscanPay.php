<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-10
 * Time: 01:30
 */

namespace App\Pay;

class QufzfbscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    
    protected function getPostData(){
        $data = [
           "return_type" => 'html',   //返回数据类型,
            "api_code" => $this->payInfo['merchant_code'],
            "is_type" => 'alipay',
            "price" => sprintf('%0.2f',$this->payInfo['money']),
            "order_id" => $this->payInfo['orderNo'],
            "time" => strtotime("now"),   //发起时间,
            "mark" => 'qufzf',   //描述,
            "return_url" => $this->payInfo['redirect_url'],
            "notify_url" => $this->payInfo['callback_url'],
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        
        
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="messages"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(MD5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        $data['api_code'] =$this->payInfo['merchant_code'];
        $this->res['flag'] = $data['code']=='1' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}