<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/19 0019
 * Time: 13:52
 */

namespace App\Pay;


class Gtqqh5Pay extends BasePay
{

    private $dataStruct = [
        'partner'     => null ,
        'banktype'    => null ,
        'paymoney'    => null ,
        'ordernumber' => null ,
        'callbackurl' => null ,
        'attach'      => null ,
        'hrefbackurl' => null ,
    ];

    public function dorechange( $data = "" )
    {
        $postData = $this->getPostData($this->payInfo);
        $pay_url = $this->payInfo[ 'gateway_address' ] . '?' . http_build_query($postData);
        header("location:" . $pay_url);
    }

    public function getPostData( $data = "" )
    {
        $this->dataStruct[ 'partner' ] = $this->payInfo[ 'merchant_code' ];
        $this->dataStruct[ 'banktype' ] = 'QQPAYWAP';
        $this->dataStruct[ 'paymoney' ] = $this->payInfo[ 'money' ];
        $this->dataStruct[ 'ordernumber' ] = $this->payInfo[ 'orderNo' ];
        $this->dataStruct[ 'callbackurl' ] = $this->payInfo[ 'callback_url' ];
        $this->dataStruct[ 'hrefbackurl' ] = $this->payInfo[ 'redirect_url' ];
        $this->dataStruct[ 'attach' ] = $this->payInfo[ 'attach' ];
        $this->dataStruct[ 'sign' ] = $this->getSignData($this->dataStruct);
        return $this->dataStruct;
    }

    public function getSignData( $arr = '' )
    {
        if (isset($arr[ 'hrefbackurl' ])) {
            unset($arr[ 'hrefbackurl' ]);
        }
        if (isset($arr[ 'attach' ])) {
            unset($arr[ 'attach' ]);
        }
        return md5(urldecode(http_build_query($arr)) . $this->payInfo[ 'merchant_secret' ]);
    }

    public function verify( $data = '' )
    {
        $sign_str = 'partner=' . $data[ 'partner' ] . '&ordernumber=' . $data[ 'ordernumber' ] . '&orderstatus=' . $data[ 'orderstatus' ] . '&paymoney=' . $data[ 'paymoney' ] . $this->payInfo[ 'merchant_secret' ];
        $md5_sign = md5($sign_str);
        if ($md5_sign == $data[ 'sign' ]){
            $this->res['flag']=true;
        }
        return $this->res;
    }
}
