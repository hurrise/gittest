<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-21
 * Time: 04:45
 */

namespace App\Pay;

class ChwxscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->request_post($this->payInfo['gateway_address'],$this->getPostData($data));
            $urlarray = json_decode($url,true);
            if($urlarray['r1_Code']=="1"){
                $this->curlPayData['qrUrl'] = $urlarray['r3_PayInfo'];
                $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
                return $this->qrRedirect($this->curlPayData);
            }else{
                if(isset($urlarray['r7_Desc'])){
                    return $this->except($urlarray['r7_Desc']);
                }
                return $this->except($url);
            }
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
            "p0_Cmd" => 'Buy',   //业务类型,
            "p1_MerId" => $this->payInfo['merchant_code'],
            "p2_Order" =>$this->payInfo['orderNo'],
            "p3_Cur" => 'CNY',   //交易币种,
            "p4_Amt" => sprintf('%0.2f',$this->payInfo['money']),
            "p5_Pid" => 'Chwxscan',   //商品名称,
            "p6_Pcat" => "",   //商品种类,
            "p7_Pdesc" => "",   //商品描述,
            "p8_Url" => $this->payInfo['callback_url'],
            "p9_MP" => "",   //商户扩展信息,
            "pa_FrpId" => 'WEIXIN',  //支付通道编码 ( ALIPAY 支付宝扫码,WEIXIN 微信,OnlinePay	网银支付,Nocard_H5	快捷支付h5,Nocard	快捷支付,QQ	QQ 钱包,UnionPay	银联扫码,WEIXINWAP	微信WAP,QQWAP	QQWAP,WX_CASHIER	微信扫码收银台,ALIPAYWAP	支付宝WAP,JDPAY	京东)
            "pg_BankCode" => "",   //银行编码,
            "ph_Ip" => $this->get_real_ip(),   //用户请求 ip,
            "pi_Url" => $this->payInfo['redirect_url']
        ];
        $data['hmac'] = $this->getSign($data);
        return $data;
    }
    
    protected function getSign($data = ""){
        $Str='';
        foreach ($data as $k=>$v){
            if($v==""){
                continue;
            }else{
                $Str.=$v;
            }
        }
        $Sign = $this->HmacMd5($Str,$this->payInfo['merchant_secret']);
        return $Sign;
    }
    
    public function verify($data=""){
        $signdata=[
            "p1_MerId" => $data['p1_MerId'],
            "r0_Cmd" => $data['r0_Cmd'],
            "r1_Code" => $data['r1_Code'],
            "r2_TrxId" => $data['r2_TrxId'],
            "r3_Amt" => $data['r3_Amt'],
            "r4_Cur" => $data['r4_Cur'],
            "r5_Pid" => $data['r5_Pid'],
            "r6_Order" => $data['r6_Order'],
            "r8_MP" => $data['r8_MP'],
            "r9_BType" => $data['r9_BType'],
            "ro_BankOrderId" => $data['ro_BankOrderId'],
            "rp_PayDate" => $data['rp_PayDate'],
        ];
        if($data['r1_Code']=="1" && $this->getSign($signdata) == $data['hmac']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++ ){
                if (!preg_match('/^(10│172.16│192.168./', $ips[$i] )){
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }

    protected function HmacMd5($data,$key)
    {
        // RFC 2104 HMAC implementation for php.
        // Creates an md5 HMAC.
        // Eliminates the need to install mhash to compute a HMAC
        // Hacked by Lance Rushing(NOTE: Hacked means written)
        $key = iconv("GB2312","UTF-8",$key);
        $data = iconv("GB2312","UTF-8",$data);
        $b = 64; // byte length for md5
        if (strlen($key) > $b) {
            $key = pack("H*",md5($key));
        }
        $key = str_pad($key, $b, chr(0x00));
        $ipad = str_pad('', $b, chr(0x36));
        $opad = str_pad('', $b, chr(0x5c));
        $k_ipad = $key ^ $ipad ;
        $k_opad = $key ^ $opad;
        return md5($k_opad . pack("H*",md5($k_ipad . $data)));
    }

    protected function request_post($url = '', $param = '') {
        if (empty($url) || empty($param)) {
            return false;
        }
        $postUrl = $url;
        $curlPost = $param;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1);//post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        return $data;
    }
}