<?php

namespace App\Pay;

class MsfzfbscanPay extends BasePay
{
    private $data = [
        'amount' => null,
        'channelCode' => null,
        'goodsName' => null,
        'orderNum' => null,
        'organizationCode' => null,
        'payResultCallBackUrl' => null,
        'payViewUrl' => null,
        'remark' => null
    ];

    public function dorechange($data = ''){
        return $this->redirect($this->getPostData(),'post');
    }

    protected function reqPost($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,trim($url));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmpInfo;
    }

    protected function getPostData(){
        $this->data['amount'] = $this->payInfo['money']*100;    //用户充值金额,用户输入单位为元,提交时转换为积分, 1元=100积分
        $this->data['channelCode'] = 'ZFBH5';
        $this->data['goodsName'] = 'charge';
        $this->data['orderNum'] = $this->payInfo['orderNo'];
        $this->data['organizationCode'] = $this->payInfo['merchant_code'];
        $this->data['payResultCallBackUrl'] = $this->payInfo['callback_url'];
        $this->data['payViewUrl'] = $this->payInfo['redirect_url'];
        $this->data['remark'] = 'jfcz';
        $data = [
            'data' => $this->encodePay(json_encode($this->data),$this->getPublicKey($this->payInfo['public_key'])),
            'merNo' => $this->payInfo['merchant_code'],
            'sign' => $this->getSign($this->data)
        ];
        return $data;
    }

    protected function getSign($data){
        return strtoupper(md5(json_encode($data).$this->payInfo['merchant_secret']));
    }

    public function verify($data=""){
        $sign=$data['sign'];//签名
        $datas=$data["data"];
        //解密
        $resultJson=$this->decode($datas,$this->getPrivateKey($this->payInfo['private_key']));
        //验签
        $resultData=$this->jsonToQuery($resultJson,$this->payInfo['merchant_secret'],$sign);
        if($resultData['payStateCode']=="10"){
            $this->res['flag'] = true;
        }
        return $this->res;
    }

    //加密
    protected function encodePay($data,$pay_public_key){
        $pu_key =  openssl_pkey_get_public($pay_public_key);
        if ($pu_key == false){
            customWriteLog('postData',"打开密钥出错,密钥打开句柄结果:".$pu_key);
        }
        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $pu_key);
            $crypto = $crypto . $encryptData;
        }
        $crypto = base64_encode($crypto);
        return $crypto;
    }

    //解密
    protected function decode($data,$private){
        //读取秘钥
        $pr_key = openssl_pkey_get_private($private);
        if ($pr_key == false){
            Log::info('打开密钥出错');
        }
        $data = base64_decode($data);
        $crypto = '';
        //分段解密
        foreach (str_split($data, 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $pr_key);
            $crypto .= $decryptData;
        }
        return $crypto;
    }

    // 支付请求响应验签
    protected function jsonToArray($json,$key){
        $array=json_decode($json,true);
        if ($array['status'] == '200'){
            $sign_string = $array['sign'];
            // 生成签名 并将字母转为大写
            $md5 =  strtoupper(md5($array['data']. $key));
            if ($md5 == $sign_string){
                return $array;
            }else{
                $result = [
                    'status' => '99',
                    'message' => '返回签名验证失败'
                ];
                return $result;
            }
        }else{
            $result = [
                'status' => $array['status'],
                'message' => $array['message']
            ];
            return $result;
        }
    }

    // 回调请求验签
    protected function jsonToQuery($json,$key,$sign){
        $array=json_decode($json,true);
        // 生成签名 并将字母转为大写
        $md5 =  strtoupper(md5(json_encode($array) . $key));
        if ($md5 == $sign){
            return $array;
        }else{
            $result = array();
            $result['status'] = '99';
            $result['message'] = '返回签名验证失败';
            return $result;
        }
    }
}