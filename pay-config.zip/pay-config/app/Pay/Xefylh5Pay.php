<?php

namespace App\Pay;

use App\Service\CurlService;

class Xefylh5Pay extends BasePay {

    private $dataStruct = [
        'orderId' => null,
        'merchId' => null,
        'payWay' => null,
        'curType' => null,
        'tranTime' => null,
        'totalAmt' => null,
        'title' => null,
        'attach' => null,
        'notifyUrl' => null,
        'extraMsg' => null,
        'clientIp' => null,
        'extend2' => null,
        'extend3' => null,
    ];
    private $QueryStruct = [
        'partner' => null,
        'encryptType' => null,
        'msgData' => null,
        'signData' => null,
        'version' => null,
        'reqMsgId' => null,
        'accountNo' => null,
    ];

    public function dorechange($data = '') {

        $postData = $this->getPostData($data);
        $QueryData = $this->getQueryData($postData);
        $res = CurlService::getInstance()->post_https($this->payInfo['gateway_address'], $QueryData);
        $res = json_decode($res, true);
        $returnMsgData = base64_decode($res['msgData']);
        $returnMsgData = json_decode($returnMsgData, true);
        if ($returnMsgData['respCode'] == 0000) {
            return $this->redirect($returnMsgData['qrCode']);
        } else {
            echo $returnMsgData["respMsg"];
        }
    }
    protected function getQueryData($data = "") {
        $this->QueryStruct['partner'] = $this->payInfo['merchant_code'];
        $this->QueryStruct['encryptType'] = 'md5';
        $this->QueryStruct['msgData'] = base64_encode($this->getMsgData($data));
        $this->QueryStruct['signData'] = $this->getSign($data);
        $this->QueryStruct['version'] = 'V2.0';
        $this->QueryStruct['reqMsgId'] = $this->payInfo['orderNo'];
        $this->QueryStruct['accountNo'] = 1;
        return $this->QueryStruct;
    }

    protected function getSign($data = "") {
        $msgData = $this->getMsgData($data);
        $signStr = $msgData . $this->payInfo['merchant_secret'];
        $signData = md5($signStr);
        return $signData;
    }

    protected function getMsgData($data = "") {
        $data = $this->unsetNull($data);
        ksort($data);
        $msgData = json_encode($data);
        return $msgData;
    }

    protected function unsetNull($data) {
        foreach ($data as $k => $v) {
            if (is_null($data[$k])) {
                unset($data[$k]);
            }
        }
        return $data;
    }

    protected function getPostData($data = "") {
        $this->dataStruct['orderId'] = $this->payInfo['orderNo'];
        $this->dataStruct['merchId'] = $this->payInfo['merchant_code'];
        $this->dataStruct['payWay'] = $this->payInfo['extend1'];
        $this->dataStruct['curType'] = 'CNY';
        $this->dataStruct['tranTime'] = date('YmdHis', time());
        $this->dataStruct['totalAmt'] = $this->payInfo['money'] * 100;
        $this->dataStruct['title'] = "在线充值";
        $this->dataStruct['attach'] = null;
        $this->dataStruct['notifyUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['extraMsg'] = null;
        $this->dataStruct['clientIp'] = $this->getIp();
        $this->dataStruct['extend2'] = null;
        $this->dataStruct['extend3'] = null;
        return $this->dataStruct;
    }

    public function getIp() {
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return($ip);
    }

    public function verify($data = "") {
        header("Content-type: text/html; charset=utf-8");
        $msgData = base64_decode($data['msgData'], true);
        $signStr = $data['msgData'] . $this->payInfo['merchant_secret'];
        $sign = md5($signStr);
        if ($data['signData'] == $sign) {
            $this->res['flag']=true;
        }
        $this->res['callback_param']="000000";
        return $this->res;
    }

}
