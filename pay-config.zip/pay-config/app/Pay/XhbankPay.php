<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/16
 * Time: 14:28
 */

namespace App\Pay;



use App\Sevice\CurlService;


class XhbankPay extends BasePay
{

    public $config = [
        'gateway_address'=>'https://gateway.gd95516.com/api/v1/order',
        'merchant'=>'3011288',
        'key'=>'4611cb77-6326-a2d5-8d93-a0c7e79ad976',
        'callback_url'=>'http://pay-local.test/callback_url',
        'redirect_url'=>'http://pay-local.test/redirect_url',
        'bank_info'=>[
            'QQQR'=>'QQ扫码',
            'QQH5'=>'QQH5',
            'QQTM'=>'QQ条码',
            'WXQR'=>'微信扫码',
            'WXTM'=>'微信条码',
            'WXH5'=>'微信H5',
            'ALIQR'=>'支付宝扫码',
            'ALITM'=>'支付宝条码',
            'ALIH5'=>'支付宝H5',
            'JDQR'=>'京东扫码',
            'JDH5'=>'京东H5',
            'UNQR'=>'银联扫码',
            'UNH5'=>'银联H5',
            'UNKJ'=>'银联快捷',
            'WYKJ'=>'网银快捷',
            'WY'=>'网银',
            'BANKTRANS'=>'银行卡转账',
            'ALITRANS'=>'支付宝转账',
            'WXTRANS'=>'微信转账',
        ],
        'wy_code'=>[
            'ABC'=>'中国农业银行',
            'BJBANK'=>'北京银行',
            'BOC'=>'中国银行',
            'CCB'=>'中国建设银行',
            'CEB'=>'中国光大银行',
            'CIB'=>'兴业银行',
            'CITIC'=>'中信银行',
            'CMB'=>'招商银行',
            'CMBC'=>'中国民生银行',
            'COMM'=>'交通银行',
            'GDB'=>'广发银行',
            'HXBANK'=>'华夏银行',
            'ICBC'=>'中国工商银行',
            'PSBC'=>'中国邮政银行',
            'SHBANK'=>'上海银行',
            'SPABANK'=>'平安银行',
            'SPDB'=>'浦发银行',
            'UNDEFINED'=>'收银台选择银行',
        ]
    ];


    public function postData()
    {
        $post  = [
          'merchant_code'=>$this->payInfo['merchant_code'],
          'order_no'=>$this->payInfo['orderNo'],
          'order_amount'=>$this->payInfo['money'],
          'pay_type'=>'WY',
          'bank_code'=>$this->payInfo['extend1'],
          'order_time'=>time(),
          'customer_ip'=>$this->get_real_ip(),
          'return_params'=>'XH',
          'notify_url'=>$this->payInfo['callback_url'],
          'return_url'=>$this->payInfo['redirect_url'],
        ];
        $post['sign'] = $this->getsign($post);
        return $post;
    }
    public function dorechange($data = '')
    {
      $params = $this->postData($data);
      $res = CurlService::getInstance()->post_https($this->config['gateway_address'],$params);
      $json_data = json_decode($res,true);
      if($json_data['is_success'] == 'TRUE'){
          return  redirect($json_data['url']);
      }else{
          return $this->errorRedirect($json_data['msg']);
      }
    }

    public function getsign($data = [])
    {
        $data = $this->unsetNull($data);
        ksort($data);
        $signStr = urldecode(http_build_query($data));
        $signStr = $signStr . '&key=' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function unsetNull($data)
    {
        foreach ($data as $k=>$v) {
            if(is_null($data[$k])){
                unset($data[$k]);
            }
        }
        return $data;
    }

    public function get_real_ip(){
        static $realip;
        if(isset($_SERVER)){
            if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
                $realip=$_SERVER['HTTP_X_FORWARDED_FOR'];
            }else if(isset($_SERVER['HTTP_CLIENT_IP'])){
                $realip=$_SERVER['HTTP_CLIENT_IP'];
            }else{
                $realip=$_SERVER['REMOTE_ADDR'];
            }
        }else{
            if(getenv('HTTP_X_FORWARDED_FOR')){
                $realip=getenv('HTTP_X_FORWARDED_FOR');
            }else if(getenv('HTTP_CLIENT_IP')){
                $realip=getenv('HTTP_CLIENT_IP');
            }else{
                $realip=getenv('REMOTE_ADDR');
            }
        }
        return $realip;
    }

    public function verify($data = '')
    {
       $arr_data = $data;
        $old_sign = $arr_data['sign'];
        if(isset($arr_data['sign'])){
            unset($arr_data['sign']);
        }
        $mySign = $this->getsign($arr_data);
        if($old_sign == $mySign){
            return true;
        }else{
            return false;
        }
    }

}