<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class JbwxscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_applydate' => date("Y-m-d H:i:s"),
            'pay_bankcode' => 902,
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
            'pay_amount' => sprintf('%0.2f',$this->payInfo['money'])
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'jfcz';
        $data['pay_productname'] = 'jfcz';
        $data['pay_productnum'] = 'jfcz';
        $data['pay_productdesc'] = 'jfcz';
        $data['pay_producturl'] = 'jfcz';
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['sign'])){
            unset($data['sign']);
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        customWriteLog('getSign',PHP_EOL.$signStr.PHP_EOL.$sign);
        return $sign;
    }
    public function verify($data=""){
        unset($data['attach']);
        if($this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}