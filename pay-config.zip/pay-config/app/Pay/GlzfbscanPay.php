<?php

namespace App\Pay;

use App\Sevice\CurlService;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class GlzfbscanPay extends BasePay {

    private $dataStruct = [
        'appId' => null,
        'custNo' => null,
        'model' => null,
        'money' => null,
        'attach' => null,
        'callBackUrl' => null,
        'mchOrderNo' => null,
        'expireTime' => '',
        'sign' => null,
    ];

    public function dorechange($data = '') {

        $postData = $this->getPostData($data);
        $res = $this->curl_post_https($this->payInfo['gateway_address'], $postData);
        $result_array = json_decode($res, true);
        if ($result_array['code'] == 1) {
            $this->curlPayData['qrUrl'] = $result_array['pay_url'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }else{
            return '第三方通道异常';
        }
    }

    public function curl_post_https($url, $data) { // 模拟提交数据函数
        $curl = curl_init(); // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        if (curl_errno($curl)) {
            echo 'Errno' . curl_error($curl); //捕抓异常
        }
        curl_close($curl); // 关闭CURL会话
        return $tmpInfo; // 返回数据，json格式
    }

    protected function getPostData($data = "") {
        $this->dataStruct['appId'] = $this->payInfo['merchant_secret'];
        $this->dataStruct['custNo'] = $this->payInfo['merchant_code'];
        $this->dataStruct['model'] = "00";
        $this->dataStruct['money'] = $this->payInfo['money'];
        $this->dataStruct['attach'] = "gula";
        $this->dataStruct['callBackUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['mchOrderNo'] = $this->payInfo['orderNo'];
        $this->dataStruct['expireTime'] = 10;
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data = "") {
        $data = $this->unsetNull($data);
        ksort($data);
        $signStr = '';
        foreach ($data as $k => $v) {
            $signStr .= $k . '=' . $v . '&';
        }
        $signStr = trim($signStr, '&');
        $signStr .= $this->payInfo['merchant_secret'];
        $sign = strtolower(md5($signStr));
        return $sign;
    }

    public function verify($data = '') {
        $data = $this->unsetNull($data);
        $oldSign = $data['sign'];
        unset($data['sign']);
        ksort($data);
        $signStr = '';
        foreach ($data as $k => $v) {
            $signStr .= $k . '=' . $v . '&';
        }
        $signStr = trim($signStr, '&');
        $signStr .= $this->payInfo['merchant_secret'];
        $mysign = strtolower(md5($signStr));
        if ($oldSign == $mysign) {
            $this->res['flag'] = true;
        }
        return $this->res;
    }

    protected function unsetNull($data) {
        foreach ($data as $k => $v) {
            if (is_null($data[$k])) {
                unset($data[$k]);
            }
        }
        return $data;
    }

}
