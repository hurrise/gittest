<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/19 0019
 * Time: 13:52
 */

namespace App\Pay;
use App\Service\CurlService;

class BbwechatscanPay extends BasePay
{
     private $dataStruct = [
        'merchant_code' => null, //
        'service_type' => null, //
        'notify_url' => null, //
        'interface_version' => null, //
        'sign_type' => null, //
        'client_ip' => null, //
        'order_no' => null, //
        'order_time' => null, //
        'order_amount' => null, //
        'product_name' => null, //
        'product_code' => null, //
        'product_num' => null, //
        'product_desc' => null, //
        'extra_return_param' => null, //
        'extend_param' => null, //
        'sign' => null,
    ];

    public function dorechange( $data = ''){
        $postData = $this->getPostData($data);
        $res = CurlService::getInstance()->post_https_query($this->payInfo['gateway_address'],$postData);
        $xml = simplexml_load_string($res);
        $result = json_decode(json_encode($xml, JSON_UNESCAPED_UNICODE), true);
        if($result['response']['resp_code'] == "SUCCESS"){
            $this->curlPayData['qrUrl'] = $result['response']['qrcode'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo '第三方通道异常';
    }

    protected function getPostData($data=""){
        $this->dataStruct['merchant_code'] = $this->payInfo['merchant_code']; //
        $this->dataStruct['service_type'] = 'weixin_scan'; //
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url']; //
        $this->dataStruct['interface_version'] = "V3.1"; //
        $this->dataStruct['sign_type'] = "RSA-S"; //
        $this->dataStruct['client_ip'] = $_SERVER['REMOTE_ADDR']; //
        $this->dataStruct['order_no'] = $this->payInfo['orderNo']; //
        $this->dataStruct['order_time'] = date('Y-m-d H:i:s',time()); //
        $this->dataStruct['order_amount'] = $this->payInfo['money']; //
        $this->dataStruct['product_name'] = '积分充值'; //
        $this->dataStruct['product_code'] = null; //
        $this->dataStruct['product_num'] = null; //
        $this->dataStruct['product_desc'] = null; //
        $this->dataStruct['extra_return_param'] = 'bbh5'; //
        $this->dataStruct['extend_param'] = null; //
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data=""){
        $merchant_code = $data["merchant_code"];//商户号，123001002003是测试商户号，调试时要更换商家自己的商户号

        $service_type = $data["service_type"];//微信：weixin_scan 支付宝：alipay_scan qq钱包：tenpay_scan
        $notify_url = $data["notify_url"];
        $interface_version =$data["interface_version"];
        $client_ip = $data["client_ip"];
        $sign_type = $data["sign_type"];
        $order_no = $data["order_no"];
        $order_time = $data["order_time"];
        $order_amount =$data["order_amount"];
        $product_name =$data["product_name"];
        $product_code = $data["product_code"];
        $product_num = $data["product_num"];
        $product_desc = $data["product_desc"];
        $extra_return_param =$data["extra_return_param"];
        $extend_param = $data["extend_param"];
        $signStr = "";
        $signStr = $signStr."client_ip=".$client_ip."&";
        if($extend_param != ""){
            $signStr = $signStr."extend_param=".$extend_param."&";
        }
        if($extra_return_param != ""){
            $signStr = $signStr."extra_return_param=".$extra_return_param."&";
        }
        $signStr = $signStr."interface_version=".$interface_version."&";
        $signStr = $signStr."merchant_code=".$merchant_code."&";
        $signStr = $signStr."notify_url=".$notify_url."&";
        $signStr = $signStr."order_amount=".$order_amount."&";
        $signStr = $signStr."order_no=".$order_no."&";
        $signStr = $signStr."order_time=".$order_time."&";
        if($product_code != ""){
            $signStr = $signStr."product_code=".$product_code."&";
        }
        if($product_desc != ""){
            $signStr = $signStr."product_desc=".$product_desc."&";
        }
        $signStr = $signStr."product_name=".$product_name."&";
        if($product_num != ""){
            $signStr = $signStr."product_num=".$product_num."&";
        }
        $signStr = $signStr."service_type=".$service_type;
        
        $merchant_private_key= openssl_pkey_get_private($this->getPrivateKey($this->payInfo['private_key'],64));
       
     
        openssl_sign($signStr,$sign_info,$merchant_private_key,OPENSSL_ALGO_MD5);
        $sign = base64_encode($sign_info);
        return $sign;
    }

    public function verify($data = ""){

        //////////////////////////  接收返回通知数据  /////////////////////////////////
        /**
        获取订单支付成功之后，通知服务器以post方式返回来的订单通知数据，参数详情请看接口文档,
         */
        $merchant_code  = $data["merchant_code"];
        $notify_type = $data["notify_type"];
        $notify_id = $data["notify_id"];
        $interface_version = $data["interface_version"];
        $sign_type = $data["sign_type"];
        $dinpaySign = base64_decode($data["sign"]);
        $order_no = $data["order_no"];
        $order_time = $data["order_time"];
        $order_amount = $data["order_amount"];
        $extra_return_param = $data["extra_return_param"];
        $trade_no = $data["trade_no"];
        $trade_time = $data["trade_time"];
        $trade_status = $data["trade_status"];
        $bank_seq_no = $data["bank_seq_no"];
/////////////////////////////   参数组装  /////////////////////////////////
        /**
        除了sign_type dinpaySign参数，其他非空参数都要参与组装，组装顺序是按照a~z的顺序，下划线"_"优先于字母
         */
        $signStr = "";
        if($bank_seq_no != ""){
            $signStr = $signStr."bank_seq_no=".$bank_seq_no."&";
        }
        if($extra_return_param != ""){
            $signStr = $signStr."extra_return_param=".$extra_return_param."&";
        }
        $signStr = $signStr."interface_version=".$interface_version."&";
        $signStr = $signStr."merchant_code=".$merchant_code."&";
        $signStr = $signStr."notify_id=".$notify_id."&";
        $signStr = $signStr."notify_type=".$notify_type."&";
        $signStr = $signStr."order_amount=".$order_amount."&";
        $signStr = $signStr."order_no=".$order_no."&";
        $signStr = $signStr."order_time=".$order_time."&";
        $signStr = $signStr."trade_no=".$trade_no."&";
        $signStr = $signStr."trade_status=".$trade_status."&";
        $signStr = $signStr."trade_time=".$trade_time;
/////////////////////////////   RSA-S验签  /////////////////////////////////
        $dinpay_public_key = $this->getPublicKey($this->payInfo['public_key'],64);
        $dinpay_public_key = openssl_pkey_get_public($dinpay_public_key);
        $flag = openssl_verify($signStr,$dinpaySign,$dinpay_public_key,OPENSSL_ALGO_MD5);
//////////////////////   异步通知必须响应“SUCCESS” /////////////////////////
        /**
        如果验签返回ture就响应SUCCESS,并处理业务逻辑，如果返回false，则终止业务逻辑。
         */
        if($flag){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

}
