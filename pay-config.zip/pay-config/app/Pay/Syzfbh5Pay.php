<?php

namespace App\Pay;


class Syzfbh5Pay extends BasePay {

    public $data = [
        'p0_Cmd' => null,
        'p1_MerId' => null,
        'p2_Order' => null,
        'p3_Amt' => null,
        'p4_Cur' => null,
        'p5_Pid' => null,
        'p6_Pcat' => null,
        'p7_Pdesc' => null,
        'p8_Url' => null,
        'p9_SAF' => null,
        'pa_MP' => null,
        'pd_FrpId' => null,
        'pr_NeedResponse' => null,
        'payerIp' => null,
        'hmac' => null,
    ];

    public function getPostData() {
        $this->data['p0_Cmd'] = 'Buy';
        $this->data['p1_MerId'] = $this->payInfo['merchant_code'];
        $this->data['p2_Order'] = $this->payInfo['orderNo'];
        $this->data['p3_Amt'] = $this->payInfo['money'];
        $this->data['p4_Cur'] = 'CNY';
        $this->data['p5_Pid'] = 'charge';
        $this->data['p6_Pcat'] = 'charge';
        $this->data['p7_Pdesc'] = 'charge';
        $this->data['p8_Url'] = $this->payInfo['callback_url'];
        $this->data['p9_SAF'] = $this->payInfo['redirect_url'];
        $this->data['pa_MP'] = 'sy';
        $this->data['pd_FrpId'] = 'ALIPAYH5';
        $this->data['pr_NeedResponse'] = '1';
        $this->data['hmac'] = $this->getSign($this->data);
        return $this->data;
    }

    private function getSign($data){
        unset($data['hmac']);
        $signStr = '';
        foreach ($data as $v){
            $signStr .= $v;
        }
        $sign = $this->hmac($signStr,$this->payInfo['merchant_secret']);
        return $sign;
    }

    private function hmac($data, $key){
        $key = iconv("GBK","UTF-8//IGNORE",$key);
        $data = iconv("GBK","UTF-8//IGNORE",$data);

        if (function_exists('hash_hmac')) {
            return hash_hmac('md5', $data, $key);
        }
        $key = (strlen($key) > 64) ? pack('H32', 'md5') : str_pad($key, 64, chr(0));
        $ipad = substr($key,0, 64) ^ str_repeat(chr(0x36), 64);
        $opad = substr($key,0, 64) ^ str_repeat(chr(0x5C), 64);
        return md5($opad.pack('H32', md5($ipad.$data)));
    }

    public function dorechange($data = '') {
        $post = $this->getPostData($data);
        $this->redirect($post);
    }

    public function curl_post_https($url, $data) { // 模拟提交数据函数
        $curl = curl_init(); // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
        curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
        $tmpInfo = curl_exec($curl); // 执行操作
        if (curl_errno($curl)) {
            echo 'Errno' . curl_error($curl); //捕抓异常
        }
        curl_close($curl); // 关闭CURL会话
        return $tmpInfo; // 返回数据，json格式
    }

    public function verify($data = ''){

        $p1_MerId  		= $data['p1_MerId']; //p1_MerId	商户编号	Max(11)		1
        $r0_Cmd  		= $data['r0_Cmd']; //r0_Cmd	业务类型	Max(20)	固定值 ”Buy”.	2
        $r1_Code  		= $data['r1_Code']; //r1_Code	支付结果		固定值 “1”, 代表支付成功.	3
        $r2_TrxId  		= $data['r2_TrxId']; //r2_TrxId	平台交易流水号	Max(50)	平台订单号唯一	4
        $r3_Amt  		= $data['r3_Amt']; //r3_Amt	支付金额	Max(20)	单位:元，精确到分. 商户收到该返回数据后,一定用自己数据库中存储的金额与该金额进行比较.	5
        $r4_Cur  		= $data['r4_Cur']; //r4_Cur	交易币种	Max(10)	返回时是"RMB"	6
        $r5_Pid  		= $data['r5_Pid']; //r5_Pid	商品名称	Max(20)	同支付提交值。	7
        $r6_Order  		= $data['r6_Order']; //r6_Order	商户订单号	Max(50)	商户订单号.	8
        $r7_Uid  		= $data['r7_Uid']; //r7_Uid		Max(50)	固定留空.	9
        $r8_MP  		= $data['r8_MP']; //r8_MP	商户扩展信息	Max(200)	此参数如用到中文，请注意转码.	10
        $r9_BType  		= $data['r9_BType']; //r9_BType	交易结果返回类型	Max(1)	固定2	11
        $hmac  			= $data['hmac']; //hmac	签名数据	Max(32)

        $str = $p1_MerId.$r0_Cmd.$r1_Code.$r2_TrxId.$r3_Amt.$r4_Cur.$r5_Pid.$r6_Order.$r7_Uid.$r8_MP.$r9_BType;

        $verifyHmac = $this->hmac($str,$this->payInfo['merchant_secret']);

        return $hmac == $verifyHmac ? true : false;
    }
}
