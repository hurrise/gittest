<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/2/18
 * Time: 21:31
 */

namespace App\Pay;

class DxzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'amount' => sprintf('%0.2f', $this->payInfo['money']),
            'currentTime' => date('YmdHis'),
            'merchant' => $this->payInfo['merchant_code'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'orderNo' => $this->payInfo['orderNo'],
            'payType' => 'alipay',
            'returnUrl' => $this->payInfo['redirect_url'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        return $this->redirect($data, 'post');
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)) . '#' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['payFlag'] == '2' && $this->getSign($data) == $data['sign'];
        return $this->res;
    }
}