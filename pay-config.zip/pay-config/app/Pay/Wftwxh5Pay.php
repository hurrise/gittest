<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/3
 * Time: 11:23
 */

namespace App\Pay;


class Wftwxh5Pay extends WftPay
{
    public function dorechange($data=""){
        $postData = $this->getPostData();
        $resArray = $this->postJson($this->payInfo['gateway_address'],json_encode($postData));
        if($this->payResponseVerify($resArray)){
            return redirect($resArray['pay_url']);      //H5
//            return redirect($resArray['qrcode_url']);   //扫码
        }
        return $this->except($resArray['message']);
    }
    protected function getPostData(){
        $this->dataStruct['shop_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['user_id'] = 'jfcz';
        $this->dataStruct['money'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['type'] = 'wechat';
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        $this->dataStruct['shop_no'] = $this->payInfo['orderNo'];
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        return $this->dataStruct;
    }
}