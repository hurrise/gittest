<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/17
 * Time: 21:18
 */

namespace App\Pay;

class BdwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $res = $this->curl_post($this->payInfo['gateway_address'], $this->getPostData());
        $data = json_decode($res, true);
        if ($data['code'] === 1) {
            return redirect($data['url']);
        }
        echo @$data['msg'] ?? '第三方通道异常';
    }

    protected function getPostData()
    {
        $data = [
            'goodsname' => 'jfcz',
            'istype' => 2,
            'uid' => $this->payInfo['merchant_code'],
            'orderid' => $this->payInfo['orderNo'],
            'price' => sprintf('%0.2f', $this->payInfo['money']),
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
            'key' => '',
        ];
        $data['key'] = md5($data['goodsname']. $data['istype'] . $data['notify_url'] . $data['orderid'] . $data['price'] . $data['return_url'] . $this->payInfo['merchant_secret'] . $data['uid']);
        return $data;
    }

    public function verify($data = '')
    {
        $sign = md5($data['orderid'] . $data['p_id'] . $data['price'] . $data['realprice'] . $this->payInfo['merchant_secret']);
        $this->res['flag'] = $sign == $data['key'];
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}