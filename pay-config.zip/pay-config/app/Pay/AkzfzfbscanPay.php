<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-12-17
 * Time: 12:40
 */

namespace App\Pay;

class AkzfzfbscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
        
    }
    
    protected function getPostData(){
        $pdata = [
           "banktype" => 0,
            "usernumber" => $this->payInfo['orderNo'],
            "paymoney" => $this->payInfo['money'],
            "callbackurl" => $this->payInfo['callback_url'],
        ];
        $data['p'] = base64_encode($this->getSign($pdata));
        /**其他不参与签名的参数*/
        $data['a'] = $this->payInfo['merchant_code'];
        $data['s'] = md5($data['p']);
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="s"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $Str=substr($Str,0,-1);
        return $Str;
    }
    
    public function verify($data=""){
        $this->res['callback_param'] = 'OK';
        $sign = md5($this->getSign($data));
        if($data['orderstatus'] == '1' && $sign == $data['s']){
           $this->res['flag'] = true;
        }
        return $this->res;
    }
}