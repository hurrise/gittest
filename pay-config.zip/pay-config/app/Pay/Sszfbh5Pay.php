<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/19 0019
 * Time: 13:52
 */

namespace App\Pay;

use App\Service\CurlService;

class Sszfbh5Pay extends BasePay {

    private $commit = 'pay/unifiedOrder.htm';
    private $check = 'pay/orderQuery.htm';
    private $dataStruct = [
        'merId' => null,
        'appId' => null,
        'sign' => null,
        'orderNo' => null,
        'totalFee' => null,
        'channeltype' => null,
        'authCode' => null,
        'title' => null,
        'attach' => null,
        'orderRepeat' => null,
        'openid' => null,
        'notifyUrl' => null,
        'returnUrl' => null,
    ];
    
    public function dorechange($data = '') {
        $postData = $this->getPostData($data);
        $url = $this->payInfo['gateway_address'];
        $res = CurlService::getInstance()->post($url, $postData);
        $res = json_decode($res, true);
        if ($res['retCode'] == 100) {
            return redirect($res['qrcode']);
        } else {
            echo $res['retMsg'];
        }
    }

    protected function getPostData($data = "") {
        $this->dataStruct['merId'] = $this->payInfo['merchant_code'];
        $this->dataStruct['appId'] = $this->payInfo['app_id'];
        $this->dataStruct['orderNo'] = $this->payInfo['orderNo'];
        $this->dataStruct['totalFee'] = $this->payInfo['money'];
        $this->dataStruct['channeltype'] = 'TSALI_WEB';
        $this->dataStruct['authCode'] = null;
        $this->dataStruct['title'] = '积分充值';
        $this->dataStruct['attach'] = null;
        $this->dataStruct['orderRepeat'] = 0;
        $this->dataStruct['openid'] = null;
        $this->dataStruct['notifyUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['returnUrl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data = "") {
        unset($data['sign']);
        $data = $this->unsetNull($data);
        ksort($data);
        $signStr = "";
        foreach ($data as $k => $v) {
            $signStr .= $k . '=' . $v . '&';
        }
        $signStr .= 'key=' . $this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        return $sign;
    }

    public function verify($data = '') {
        $this->res['flag'] = $data['sign'] == $this->getSign($data);
        return $this->res;
    }

    protected function unsetNull($data) {
        foreach ($data as $k => $v) {
            if (is_null($data[$k])) {
                unset($data[$k]);
            }
        }
        return $data;
    }
}
