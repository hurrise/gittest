<?php

namespace App\Pay;

class Xfqqh5Pay extends BasePay
{
    protected function getPostData($post=[])
    {
        $post = [
            'apiName' => $this->payInfo['extend3'],
            'apiVersion' =>'1.0.0.0',
            'platformID' =>$this->payInfo['extend2'],
            'merchNo' => $this->payInfo['merchant_code'] ,
            'orderNo' => $this->payInfo['orderNo'] ,
            'tradeDate' => date('Y-m-d'),
            'amt' => sprintf('$0.2f',$this->payInfo['money']),//单位为分
            'merchUrl' => $this->payInfo['callback_url'] ,
            'merchParam' => 'attach',
            'tradeSummary' => 'desc',
            'bankCode' => empty($this->payInfo['extend1']) ? null : $this->payInfo['extend1'] //银行代码
        ];
        $post['signMsg'] = $this->getSign($post);
        return $post;
    }

    public function dorechange($data = '')
    {
        $post = $this->getPostData($data);
        $resData = $this->curlPost($this->payInfo['gateway_address'],$post);
        return $this->redirect($post);
    }

    protected function getSign($data = [])
    {
        if (isset($data['signMsg'])){
            unset($data['signMsg']);
        }
        if (isset($data['bankCode'])){
            unset($data['bankCode']);
        }
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr = trim($signStr,'&').$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        customWriteLog('getSign',PHP_EOL.'signStr:'.PHP_EOL.$signStr.PHP_EOL.'sign:'.PHP_EOL.$sign);
        return $sign;
    }

    public function verify($data = '')
    {
        $signStr = 'apiName=%s&merchNo=%s&orderNo=%s&tradeDate=%s&merchParam=%s&tradeAmt=%s&orderStatus=%s&settTime=%s&batchNo=%s&accDate=%s%s';
        $signStr = sprintf($signStr,$data['apiName'],$data['merchNo'],$data['orderNo'],$data['tradeDate'],$data['merchParam'],$data['tradeAmt'],$data['orderStatus'],$data['settTime'],$data['batchNo'],$data['accDate'],$this->payInfo['merchant_secret']);
        $sign = strtoupper(md5($signStr));
        if($sign == $data['signMsg']){
            return true;
        }else{
            return false;
        }
    }

    protected function curlPost($url, $param)
    {
        if (empty($url) || empty($param)) {
            return false;
        }
        $ch=curl_init();
        $timeout=5;
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_HEADER, 0);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
//        curl_setopt($ch,CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
        $data=curl_exec($ch);
        curl_close($ch);
        return $data;
    }

}
