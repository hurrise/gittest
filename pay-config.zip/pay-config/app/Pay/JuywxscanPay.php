<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/1 0001
 * Time: 20:08
 */

namespace App\Pay;


class JuywxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mid' => $this->payInfo['merchant_code'],
            'oid' => $this->payInfo['orderNo'],
            'amt' => $this->payInfo['money'],
            'way' => 1,
            'back' => $this->payInfo['redirect_url'],
            'notify' => $this->payInfo['callback_url'],
            'remark' => $this->payInfo['attach'],
        ];
        $data['sign'] = md5($data['mid'].$data['oid'].$data['amt'].$data['way'].$data['back'].$data['notify'].$this->payInfo['merchant_secret']);
        return $this->redirect($data,'post');
    }
    public function verify($data = "")
    {
        if($data['code'] == 100) {
            $sign = md5($data['mid'] . $data['oid'] . $data['amt'] . $data['way'] . $data['code'] . $this->payInfo['merchant_secret']);
            if($sign == $data['sign']){
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}