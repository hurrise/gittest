<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-14
 * Time: 06:04
 */

namespace App\Pay;

class HdallPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
        
    }
    
    protected function getPostData(){
        $data = [
            "pay_memberid" => $this->payInfo['merchant_code'],
            "pay_orderid" => $this->payInfo['orderNo'],
            "pay_applydate" => date('Y-m-d H:i:s'),   //订单时间,
            "pay_bankcode" => null,
            "pay_notifyurl" => $this->payInfo['callback_url'],
            "pay_callbackurl" => $this->payInfo['redirect_url'],
            "pay_amount" => $this->payInfo['money'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['pay_attach'] = null;  //商户自定义信息
        $data['pay_productname'] = null;  //商品名称
        $data['pay_productid'] = null;  //商品id

        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="attach"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        $this->res['flag'] = $data['returncode']=="00" && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}