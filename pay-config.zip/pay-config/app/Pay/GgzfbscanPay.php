<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/14 0014
 * Time: 16:02
 */

namespace App\Pay;


class GgzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merNo' => $this->payInfo['merchant_code'],
            'appId' => $this->payInfo['public_key'],
            'transType' => 5,
            'transAmt' => $this->payInfo['money']*100,
            'transTime' => date('YmdHis'),
            'orderNo' => $this->payInfo['orderNo'],
            'returnUrl' => $this->payInfo['redirect_url'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'clientIp' => $this->get_real_ip(),
            'showQR' => 2,
        ];
        $data['sign'] = md5($data['merNo'].'|'.$data['appId'].'|'.$data['transType'].'|'.$data['transAmt'].'|'.$data['transTime'].'|'.$data['orderNo'].'|'.$this->payInfo['merchant_secret']);
        $res = $this->curl_post($this->payInfo['gateway_address'],http_build_query($data));

        dd($res);
    }
    public function verify($data = "")
    {
        myLog('postData',$data);
        $sign = md5($data['orderId'] .'|'. $data['orderNo'] .'|'. $data['transaction_id']  .'|'. $data['merNo']  .'|'. $data['appId']  .'|'. $data['transAmt']  .'|'. $data['orderDate']  .'|'. $data['respCode']  .'|'. $data['timeEnd']  .'|'.$this->payInfo['merchant_secret']);
        $this->res['flag'] = $data['respCode'] == 1 && $data['sign'] == $sign;
        $this->res['callback_param'] = 'SUCCESS';
    }
}