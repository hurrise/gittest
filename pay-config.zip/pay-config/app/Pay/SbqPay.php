<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/2
 * Time: 16:27
 */
namespace App\Pay;

class SbqPay extends BasePay
{
    public function dorechange($data=""){
        $res = $this->curl_post($this->payInfo['gateway_address'],http_build_query($this->getPostData()));
        $data = json_decode($res,true);
        if($data['status'] === '0' && $data['result_code'] === '0' && $this->getSign($data) == $data['sign']){
            return redirect($data['pay_info']);
        }
        return $this->except($data['err_msg']);
    }
    protected function getPostData(){
        $data = [
            "service" => null,
            "version" => '1.0',
            "charset" => 'UTF-8',
            "sign_type" => 'MD5',
            "merchant_id" => $this->payInfo['merchant_code'],
            "out_trade_no" => $this->payInfo['orderNo'],
            "goods_desc" => 'jfcz',
            "total_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "notify_url" => $this->payInfo['callback_url'],
            "return_url" => $this->payInfo['redirect_url'],
            "nonce_str" => str_random(8),
            'sign' => '',
        ];
        $data["sign"] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        unset($data['sign']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=""){
        $this->res['callback_param'] = 'success';
        $this->res['flag'] = $data['status'] === '0' && $data['result_code'] === '0' && $this->getSign($data) == $data['sign'];
        return $this->res;
    }
}