<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/27 0027
 * Time: 13:27
 */

namespace App\Pay;


class JszfbscanPay extends BasePay
{
    private $data = [
        'application' => null,
        'version' => null,
        'timestamp' => null,
        'merchantId' => null,
        'merchantOrderId' => null,
        'merchantOrderAmt' => null,
        'merchantOrderDesc' => null,
        'userName' => null,
        'payerId' => null,
        'salerId' => null,
        'guaranteeAmt' => null,
        'merchantPayNotifyUrl' => null,
    ];

    public function dorechange($data=""){
        $res = $this->reqPost($this->payInfo['gateway_address'],$this->getPostData());
        $resp = json_decode(json_encode(simplexml_load_string(base64_decode(explode('|',$res)[0]))),true);
        if(isset($resp['@attributes']['respCode']) && $resp['@attributes']['respCode'] === '000'){
            $this->curlPayData['qrUrl'] = $resp['@attributes']['codeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $this->except($resp['@attributes']['respCode'].' '.$resp['@attributes']['respDesc']);
    }

    private function getPostData(){
        $this->data['application'] = 'ZFBScanOrder';
        $this->data['version'] = '1.0.1';
        $this->data['timestamp'] = date('YmdHis');
        $this->data['merchantId'] = $this->payInfo['merchant_code'];
        $this->data['merchantOrderId'] = $this->payInfo['orderNo'];
        $this->data['merchantOrderAmt'] = $this->payInfo['money']*100;
        $this->data['merchantOrderDesc'] = 'jfcz';
        $this->data['userName'] = 'jfcz';
        $this->data['payerId'] = '';
        $this->data['salerId'] = '';
        $this->data['guaranteeAmt'] = 0;
        $this->data['merchantPayNotifyUrl'] = $this->payInfo['callback_url'];
        $xmlData = $this->arrayToXml($this->data);
        return base64_encode($xmlData)."|".$this->getSign($xmlData);
    }
    private function getSign($xmlData=""){
        $sign = $this->signPem(md5($xmlData,true),$this->payInfo['private_key']);
        return $sign;
    }
    private function arrayToXml($data = []){
        $xmlStr = '<?xml version="1.0" encoding="utf-8" standalone="no"?>';
        $xmlStr .= '<message';
        foreach ($data as $k=>$v){
            $xmlStr .= ' '.$k.'="'.$v.'"';
        }
        $xmlStr .= '/>';
        return $xmlStr;
    }
    private function  signPem($data='',$key='') {
        $pkeyid = openssl_pkey_get_private($this->getPrivateKey($key)); //其中password为你的证书密码
        $signature = '';
        openssl_sign($data, $signature, $pkeyid);
        return base64_encode($signature);
    }
    public function verify($data=''){
        $tmp = explode("|", $data);
        $resp_xml = base64_decode($tmp[0]);
        $sign = base64_decode($tmp[1]);
        $res = openssl_get_publickey($this->getPublicKey($this->payInfo['public_key']));
        $result = (bool)openssl_verify(md5($resp_xml,true), $sign, $res);
        openssl_free_key($res);
        if($result){
            $this->res['flag']=true;
        }
        return $this->res;
    }
    protected function reqPost($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }

}