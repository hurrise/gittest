<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/19 0019
 * Time: 13:52
 */

namespace App\Pay;
use App\Sevice\CurlService;

class QfzfbscanPay extends BasePay
{

    private $dataStruct = [
        'app_id' => null,
        'channel' => null,
        'order_sn' => null,
        'amount' => null,
        'notify_url' => null,
        'return_url' => null,
        'nonce_str' => null,
        'sign' => null,
    ];
   
    public function dorechange($data = ''){
        $postData = $this->getPostData($data);
        $res = CurlService::getInstance()->post($this->payInfo['gateway_address'],$postData);
        $res = json_decode($res,true);
        if($res['code'] == 200){
            header("location:".$res['data']['cashier_url']);
        }else{
            echo $res['msg'];
        }
    }

    protected function getPostData($data=""){
        $this->dataStruct['app_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['channel'] = 'alipay';
        $this->dataStruct['order_sn'] = $this->payInfo['orderNo'];
        $this->dataStruct['amount'] = $this->payInfo['money'];
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        $this->dataStruct['nonce_str'] = md5(rand(1000,9999));
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    protected function getSign($data=""){
        $data = $this->unsetNull($data);
        ksort($data);
        $data['app_key'] = $this->payInfo['merchant_secret'];
//        $signStr = '';
//        foreach ($data as $k=>$v){
//            $signStr .= $k.'='.$v.'&';
//        }
        $signStr = urldecode(http_build_query($data));
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    public function callbackUrl(Request $request){
       $this->writeLog('callbackStart',['msg'=>'收到毁掉了']);
        $data = $request->all();
       $this->writeLog('callbackData',$data);
        if($this->verify($data)){
           $this->writeLog('success',['msg'=>'ok']);
        }else{
           $this->writeLog('error',['msg'=>'error']);
        }
    }
    public function verify($data = ""){
        $sign1 = $data['sign'];
        unset($data['sign']);
        $sign2 = $this->getSign($data);
        $this->res['flag'] = $sign1 == $sign2;
        return $this->res;
    }
}
