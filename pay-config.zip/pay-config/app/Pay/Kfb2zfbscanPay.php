<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-15
 * Time: 03:30
 */

namespace App\Pay;

class Kfb2zfbscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->kfb2_curl_post($this->payInfo['gateway_address'],$this->getPostData($data));
            $dataarray = json_decode($url,true);
            if($dataarray['code']=='200'){
                return redirect($dataarray['data']['tradeUrl']);
            }
            return $this->except($dataarray['msg']);
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
           "merno" => $this->payInfo['merchant_code'],
            "out_trade_no" => $this->payInfo['orderNo'],
            "payid" => '2',   //通道编码(微信支付：1,支付宝：2,网银快捷支付：3,网银网关支付：4),
            "callback_url" => $this->payInfo['callback_url'],
            "success_url" => $this->payInfo['redirect_url'],
            "amount" => sprintf('%0.2f',$this->payInfo['money']),
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['bankCardNo'] = null;  //支付卡号

        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['status']=='2' && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function kfb2_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}