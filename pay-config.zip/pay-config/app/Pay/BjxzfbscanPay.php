<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-18
 * Time: 04:16
 */

namespace App\Pay;

class BjxzfbscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
        
    }
    
    protected function getPostData(){
        $data = [
           "pid" => $this->payInfo['merchant_code'],
            "type" => 'alipay2',   //支付方式alipay2（支付宝）、wechat2（微信）、alipay2qr（支付宝提供json数据）、wechat2qr（微信提供json数据）,
            "out_trade_no" => $this->payInfo['orderNo'],
            "notify_url" => $this->payInfo['callback_url'],
            "return_url" => $this->payInfo['redirect_url'],
            "name" => 'bjxzfb',   //商品名称,
            "attach" => 'bjxzfb',   //附加数据,
            "money" => sprintf('%0.2f',$this->payInfo['money']),
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['sitename'] = null;  //网站名称
        $data['format'] = null;  //返回格式
        $data['sign_type'] = 'MD5';  //签名类型
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="sign_type"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= substr($Str,0,-1).$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['status']=="1" && $this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}