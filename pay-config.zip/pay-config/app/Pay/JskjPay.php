<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/27 0027
 * Time: 13:27
 */

namespace App\Pay;


class JskjPay extends BasePay
{
    private $data = [
        'application' => null,
        'version' => null,
        'merchantId' => null,
        'merchantName' => null,
        'merchantOrderId' => null,
        'merchantOrderAmt' => null,
        'merchantPayNotifyUrl' => null,
        'accountType' => null,
        'orderTime' => null,
    ];

    public function dorechange($data=""){
        return $this->redirect_one($this->getPostData());
        $res = $this->reqPost($this->payInfo['gateway_address'],$this->getPostData());  //curl 请求返回值
        $resp = json_decode(json_encode(simplexml_load_string(base64_decode(explode('|',$res)[0]))),true)['@attributes']; //响应解析出的数组
        if(isset($resp['respCode']) && $resp['respCode'] === '000'){
            return $this->redirect($resp['codeUrl']);
        }
        return $this->except($resp['respCode'].' '.$resp['respDesc']);
    }

    public function redirect_one($data = ""){
        $url = $this->payInfo['gateway_address'];
        $htmlStr = '<form id="submit" name="submit" method="post" action="'.$url.'">';
        $htmlStr.='<input name="msg" type="hidden" value="'.$data.'" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }
    private function getPostData(){
        $this->data['application'] = 'WebQuickPayOrder';
        $this->data['version'] = '1.0.1';
        $this->data['merchantId'] = $this->payInfo['merchant_code'];
        $this->data['merchantName'] = '1000556';
        $this->data['merchantOrderId'] = $this->payInfo['orderNo'];
        $this->data['merchantOrderAmt'] = $this->payInfo['money'] * 100;
        $this->data['merchantPayNotifyUrl'] = $this->payInfo['callback_url'];
        $this->data['accountType'] = 0;
        $this->data['orderTime'] = date('YmdHis');
        $xmlData = $this->arrayToXml($this->data);
        $strSign = $this->getSign($xmlData);
        $base64_src=base64_encode($xmlData);
        $msg = $base64_src."|".$strSign;
        return $msg;
    }
    private function getSign($xmlData=""){
        $strMD5 =  MD5($xmlData,true);
        $strsign =  $this->signPem($strMD5);
        return $strsign;
    }
    private function arrayToXml($data = ""){
        $xmlStr = '<?xml version="1.0" encoding="utf-8" standalone="no"?>';
        $xmlStr .= '<message ';
        foreach ($data as $k=>$v){
            $xmlStr .= ' '.$k.'='.'"'.$v.'"'.' ';
        }
        $xmlStr .= '/>';
        return $xmlStr;
    }
    private function  signPem($data) {
        $pkeyid = openssl_pkey_get_private($this->getPrivateKey($this->payInfo['private_key'],64)); //其中password为你的证书密码
        $signature = '';
        openssl_sign($data, $signature, $pkeyid);
        return base64_encode($signature) ;
    }

    public function verify($data = ""){
        $tmp = explode("|", $data);
        $resp_xml = base64_decode($tmp[0]);
        $resp_sign = $tmp[1];
        if($this->thirdVerity(MD5($resp_xml,true),$resp_sign)){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    private function thirdVerity($data,$signature)
    {
        $pubKey = $this->getPublicKey($this->payInfo['public_key'],64);
        $res = openssl_get_publickey($pubKey);
        $result = (bool)openssl_verify($data, base64_decode($signature), $res);
        openssl_free_key($res);
        return $result;
    }

    protected function reqPost($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }

}