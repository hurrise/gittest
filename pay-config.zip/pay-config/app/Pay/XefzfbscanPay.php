<?php

namespace App\Pay;

class XefzfbscanPay extends BasePay {

    public function dorechange($data = '') {
        $data = [
            'attach' => 'tttt',
            'clientIp' => $this->get_real_ip(),
            'curType' => 'CNY', //人民币
            'merchId' => $this->payInfo['merchant_code'], //商户ID
            'notifyUrl' => $this->payInfo['callback_url'],//需要使用服务器能访问的地址
            'orderId' => $this->payInfo['orderNo'], //订单号
            'payWay' => 'alipay', //支付方式 支付宝：alipay QQ钱包：qqpay  百度钱包：bdpay   微信：weixin
            'returnUrl' => $this->payInfo['redirect_url'],
            'title' => 'jfcz', //标题
            'totalAmt' => (int)($this->payInfo['money'] * 100), //金额 按分为单位。 100实际为1元
            'tranTime' => date('YmdHis'), //自己订单号
        ];
        $post = [//定义一个是数组用于POST
            'partner' => $this->payInfo['merchant_code'],
            'encryptType' => 'md5',
            'msgData' => base64_encode(json_encode($data)),
            'signData' => $this->getSign($data),
        ];
        return $this->redirect($post,'post');
    }

    protected function getSign($data = []) {
        foreach ($data as $k => $v) {
            if($v === '' || $v === null)
                unset($data[$k]);
        }
        ksort($data);
        $data = json_encode($data).$this->payInfo['merchant_secret']; //数组转换成JSON
        return md5($data);
    }

    public function verify($data = "") {
        $md5data = md5($data['msgData'] . $this->payInfo['merchant_secret']);
        $this->res['flag'] = $md5data == $data["signData"] && json_decode(base64_decode($data['msgData'],true),true)['respCode'] == '0000';
        $this->res['callback_param']="000000";
        return $this->res;
    }
}
