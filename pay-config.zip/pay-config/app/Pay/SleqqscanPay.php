<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-10-28
 * Time: 08:13
 */

namespace App\Pay;
use App\Service\CurlService;

class SleqqscanPay extends BasePay
{
    public function dorechange($data=""){
        $postData = $this->getPostData();
        $res = CurlService::getInstance()->post_https_query($this->payInfo['gateway_address'],$postData);
        $result = json_decode($res, true);
        if($result['status'] == "00"){
            $this->curlPayData['qrUrl'] = $result['codeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }else{
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
            "versionId" => '001',   //版本号
            "businessType" => '1100',   //交易业务类型
            "transChanlName" => '0004',
            "merId" => $this->payInfo['merchant_code'],
            "orderId" => $this->payInfo['orderNo'],
            "transDate" => date('YmdHis'),   //交易日期
            "transAmount" => $this->payInfo['money'],
            "backNotifyUrl" => $this->payInfo['callback_url'],
            "orderDesc" => 'saomazhifu',   //订单或者商品详细描述
            "dev" => 'saomazhifu', //商户自定义域
        ];
        $data['signData'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['signType'] =  'MD5';  //签名类型
        return $data;
    }
    
    protected function getSign($data = ""){
        if(isset($data['signData'])){
            unset($data['signData']);
        }
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="attach"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(MD5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        if($data['refcode'] == '00' && $this->getSign($data) == $data['signData']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}