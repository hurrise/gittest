<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-10
 * Time: 03:33
 */

namespace App\Pay;

class BxzfbscanPay extends BasePay
{
    public function dorechange($data=""){
    try{
        $datapost =json_encode($this->getPostData($data));
        $url = $this->curl_post($this->payInfo['gateway_address'],$datapost);
        $result = json_decode($url,true);
        if($result['errorcode']=="200"){
            return redirect($result['data']);
        }
        return $this->except($result['msg']);
    }catch (\Exception $exception){
        return $this->except();
    }
}

    protected function getPostData(){
        $data = [
            "mid" => $this->payInfo['merchant_code'],
            "oid" => $this->payInfo['orderNo'],
            "amt" => $this->payInfo['money'],
            "way" => '2',   //交易方式(1微信支付， 2支付宝支付，3微信WAP，4支付宝WAP),
            "back" => $this->payInfo['redirect_url'],
            "notify" => $this->payInfo['callback_url'],
        ];
        $data['sign'] = $this->getSign($data,true);
        return $data;
    }

    protected function getSign($data = "",$flag=false){
        $symbol='|';
        if($flag){
            $Str=$data['mid'].$symbol.$data['oid'].$symbol.$data['amt'].$symbol.$data['way'].$symbol.$data['back'].$symbol.$data['notify'];
        }else{
            $Str=$data['mid'].$symbol.$data['oid'].$symbol.$data['amt'].$symbol.$data['way'].$symbol.$data['code'];
        }
        $stringSignTemp= $Str.$symbol.$this->payInfo['merchant_secret'];
        $Str = md5($stringSignTemp);
        return $Str;
    }

    public function verify($data=""){
        //实际支付金额 $data['data']['tamt']
        if($data['errorcode']=="200" && $this->getSign($data['data']) == $data['data']['sign']){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = '{"errorcode":"200","msg":"成功"}';
        return $this->res;
    }
}