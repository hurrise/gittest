<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/26 0026
 * Time: 12:37
 */

namespace App\Pay;


class JjwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $para_temp = [
            'Version' => 'v1.0.0',
            'MerCode' => $this->payInfo['merchant_code'],
            'MerName' => 'test',
            'Account' => $this->payInfo['app_id'],
            'MsgId' => uniqid(),
            'ReqDate' => date('YmdHis'),
            'MerBillNo' => $this->payInfo['orderNo'],
            'GatewayType' => '10',
            'Date' => date('Ymd'),
            'CurrencyType' => '156',
            'Amount' => sprintf('%0.2f',$this->payInfo['money']),
            'Lang' => 'GB',
            'Merchanturl' => $this->payInfo['redirect_url'],
            'FailUrl' => $this->payInfo['redirect_url'],
            'Attach' => $this->payInfo['attach'],
            'OrderEncodeType' => '5',
            'RetEncodeType' => '7',
            'RetType' => '1',
            'ServerUrl' => $this->payInfo['callback_url'],
            'BillEXP' => 24,
            'GoodsName' => 'jfcz',
            'IsCredit' => '1',
            'BankCode' => '10',
            'ProductType' => '1',
        ];
        $data = ['pGateWayReq' => $this->buildRequestPara($para_temp)];
        return $this->redirect($data,'post');
    }
    protected function buildRequestPara($para_temp) {
        $sReqXml = "<Pay>";
        $sReqXml .= "<GateWayReq>";
        $sReqXml .= $this->buildHead($para_temp);
        $sReqXml .= $this->buildBody($para_temp);
        $sReqXml .= "</GateWayReq>";
        $sReqXml .= "</Pay>";
        return $sReqXml;
    }
    protected function buildHead($para_temp){
        $sReqXmlHead = "<head>";
        $sReqXmlHead .= "<Version>".$para_temp["Version"]."</Version>";
        $sReqXmlHead .= "<MerCode>".$para_temp["MerCode"]."</MerCode>";
        $sReqXmlHead .= "<MerName>".$para_temp["MerName"]."</MerName>";
        $sReqXmlHead .= "<Account>".$para_temp["Account"]."</Account>";
        $sReqXmlHead .= "<MsgId>".$para_temp["MsgId"]."</MsgId>";
        $sReqXmlHead .= "<ReqDate>".$para_temp["ReqDate"]."</ReqDate>";
        $sReqXmlHead .= "<Signature>".$this->md5Sign($this->buildBody($para_temp),$para_temp["MerCode"],$this->payInfo['merchant_secret'])."</Signature>";
        $sReqXmlHead .= "</head>";
        //print_r($para_temp);exit();
        return $sReqXmlHead;
    }
    protected function buildBody($para_temp){
        $sReqXmlBody = "<body>";
        $sReqXmlBody .= "<MerBillNo>".$para_temp["MerBillNo"]."</MerBillNo>";
        $sReqXmlBody .= "<GatewayType>".$para_temp["GatewayType"]."</GatewayType>";
        $sReqXmlBody .= "<Date>".$para_temp["Date"]."</Date>";
        $sReqXmlBody .= "<CurrencyType>".$para_temp["CurrencyType"]."</CurrencyType>";
        $sReqXmlBody .= "<Amount>".$para_temp["Amount"]."</Amount>";
        $sReqXmlBody .= "<Lang>".$para_temp["Lang"]."</Lang>";
        $sReqXmlBody .= "<Merchanturl><![CDATA[".$para_temp["Merchanturl"]."]]></Merchanturl>";
        $sReqXmlBody .= "<FailUrl><![CDATA[".$para_temp["FailUrl"]."]]></FailUrl>";
        $sReqXmlBody .= "<Attach><![CDATA[".$para_temp["Attach"]."]]></Attach>";
        $sReqXmlBody .= "<OrderEncodeType>".$para_temp["OrderEncodeType"]."</OrderEncodeType>";
        $sReqXmlBody .= "<RetEncodeType>".$para_temp["RetEncodeType"]."</RetEncodeType>";
        $sReqXmlBody .= "<RetType>".$para_temp["RetType"]."</RetType>";
        $sReqXmlBody .= "<ServerUrl><![CDATA[".$para_temp["ServerUrl"]."]]></ServerUrl>";
        $sReqXmlBody .= "<BillEXP>".$para_temp["BillEXP"]."</BillEXP>";
        $sReqXmlBody .= "<GoodsName><![CDATA[".$para_temp["GoodsName"]."]]></GoodsName>";
        $sReqXmlBody .= "<IsCredit>".$para_temp["IsCredit"]."</IsCredit>";
        $sReqXmlBody .= "<BankCode>".$para_temp["BankCode"]."</BankCode>";
        $sReqXmlBody .= "<ProductType>".$para_temp["ProductType"]."</ProductType>";
        $sReqXmlBody .= "</body>";
        return $sReqXmlBody;
    }

    protected function md5Sign($prestr, $merCode, $key)
    {
        $prestr = $prestr . $merCode . $key;
        return md5($prestr);
    }

    public function verify($data = "")
    {
        $xmlResult = new \SimpleXMLElement($data['paymentResult']);
        $strSignature = $xmlResult->GateWayRsp->head->Signature;
        $retEncodeType = $xmlResult->GateWayRsp->body->RetEncodeType;
        $strBody = $this->subStrXml("<body>", "</body>", $data['paymentResult']);
        $rspCode = $xmlResult->GateWayRsp->head->RspCode;
        if($rspCode == "000000"){
            if($this->md5Verify($strBody,$strSignature,$this->payInfo["merchant_code"],$this->payInfo["merchant_secret"])) {
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
    protected function md5Verify($prestr, $sign, $merCode, $key)
    {
        $prestr = $prestr . $merCode . $key;
        $mysgin = md5($prestr);

        if ($mysgin == $sign) {
            return true;
        } else {
            return false;
        }
    }
    protected function subStrXml($begin,$end,$str){
        $b= (strpos($str,$begin));
        $c= (strpos($str,$end));

        return substr($str,$b,$c-$b + 7);
    }
}