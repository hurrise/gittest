<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/21
 * Time: 16:22
 */

namespace App\Pay;

class JzzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'orderid' => $this->payInfo['orderNo'],
            'price' => sprintf('%0.2f', $this->payInfo['money']),
            'istype' => 1,
            'orderuid' => uniqid(),
            'notify_url' => $this->payInfo['callback_url'],
            'goodsname' => 'jfcz',
            'return_url' => $this->payInfo['redirect_url'],
            'key' => ''
        ];
        $data['key'] = $this->getSign($data);
        return $this->redirect($data, 'post');
    }

    protected function getSign($data = [])
    {
        unset($data['key']);
        $data['token'] = $this->payInfo['merchant_secret'];
        $data = $this->unsetNull($data);
        ksort($data);
        return md5(join('+',$data));
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $this->getSign($data) == $data['key'];
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}