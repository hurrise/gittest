<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-18
 * Time: 12:59
 */

namespace App\Pay;

class Shunywxh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData($data),'post');
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
           "version" => '2.0',   //版本号,
            "mer_no" => $this->payInfo['merchant_code'],
            "back_url" => $this->payInfo['callback_url'],
            "page_url" => $this->payInfo['redirect_url'],
            "mer_order_no" => $this->payInfo['orderNo'],
            "gateway_type" => '015',   //银联h5直连:008,支付宝h5直连:014,微信h5直连:015,QQh5直连:016,京东h5直连:017
            "currency" => '156',   //交易币种,
            "trade_amount" => $this->payInfo['money'],//整数，以元为单位，不允许有小数点
            "order_date" => date('Y-m-d H:i:s'),   //订单时间,
            "client_ip" => $this->get_real_ip(),   //客户端ip,
            "goods_name" => 'Shunyzfbscan',   //商品名称,
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['sign_type'] = 'MD5';  //签名方式
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($k=="signType"){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        //amount 实际支付金额
        if($data['tradeResult']=="1" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }

    protected function shuny_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded",
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}