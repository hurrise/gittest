<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/2/14
 * Time: 16:05
 */

namespace App\Pay;

class Hjzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantId' => $this->payInfo['merchant_code'],
            'merchantOrderId' => $this->payInfo['orderNo'],
            'money' => sprintf('%0.2f', $this->payInfo['money']),
            'payType' => 'alipay_h5',
            'resultFormat' => 'form',
            'timestamp' => time(),
            'merchantUid' => mt_rand(00000000,99999999),
            'goodsName' => 'jfcz',
            'notifyUrl' => $this->payInfo['callback_url'],
            'returnUrl' => $this->payInfo['redirect_url'],
            'clientIp' => get_real_ip(),
            'sign' => 'jfcz',
        ];
        $signStr = 'merchantId='.$data['merchantId']. '&merchantOrderId='.$data['merchantOrderId']. '&merchantUid='.$data['merchantUid']. '&money='.$data['money']. '&notifyUrl='.$data['notifyUrl']. '&payType='.$data['payType']. '&timestamp='.$data['timestamp'];
        $prikey = openssl_get_privatekey($this->getPrivateKey($this->payInfo['private_key']));
        openssl_sign($signStr, $data['sign'], $prikey, OPENSSL_PKCS1_PADDING);
        openssl_pkey_free($prikey);
        $data['sign'] = base64_encode($data['sign']);
        return $this->redirect($data, 'post');
    }

    public function verify($data = '')
    {
        $signStr = '';
        is_array($data) and $signStr = 'merchantId='.$data['merchantId']. '&merchantOrderId='.$data['merchantOrderId']. '&merchantUid='.$data['merchantUid']. '&money='.$data['money']. '&orderId='.$data['orderId']. '&payAmount='.$data['payAmount']. '&payTime='.$data['payTime']. '&payType='.$data['payType'];
        $pubKey = openssl_get_publickey($this->getPublicKey($this->payInfo['public_key']));
        $this->res['flag'] = openssl_verify($signStr, base64_decode($data['sign']), $pubKey);
        openssl_pkey_free($pubKey);
        return $this->res;
    }
}