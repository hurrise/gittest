<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/8
 * Time: 21:31
 */
namespace App\Pay;

class HbPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
        $res = $this->curl_post($this->payInfo['gateway_address'],$this->getPostData());
        $data = json_decode($res,true);
        if($data['resultCode'] == '00' && $this->getSign($data) == $data['sign']){
            $this->curlPayData['qrUrl'] = $data['data'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
            return redirect($data['payUrl']);
        }
        return $this->errorRedirect($data['resultCode'].' '.$data['resultDesc']);
    }
    protected function getPostData(){
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_amount' => sprintf('%0.2f',$this->payInfo['money']),
            'pay_applydate' => date("Y-m-d H:i:s"),
            'pay_bankcode' => $this->payInfo['extend1'],
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'jfcz';
        $data['pay_productname'] = 'jfcz';
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['sign'])){
            unset($data['sign']);
        }
        if(isset($data['attach'])){
            unset($data['attach']);
        }
        foreach ($data as $k=>$v){
            if($v == '' || $v == null){
                unset($data[$k]);
            }
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=''){
        if($data['returncode'] === '00' && $this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}