<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/12/15
 * Time: 10:51
 */

namespace App\Pay;

class XybbankPay extends XybPay
{
    public function dorechange($data = "")
    {
        $data = [
            'mchntCode' => $this->payInfo['merchant_code'],
            'mchntOrderNo' => $this->payInfo['orderNo'],
            'orderAmount' => $this->payInfo['money']*100,
            'bankCode' => $this->payInfo['extend1'],
            'channelCode' => $this->payInfo['extend2'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'pageUrl' => $this->payInfo['redirect_url'],
            'body' => 'jfcz',
            'sign' => '',
            'subject' => 'jfcz',
            'description' => 'jfcz',
            'ts' => date('Y-m-d H:i:s').round(explode(' ',microtime())[0]*1000),
            'clientIp' => $this->get_real_ip(),
            'orderTime' => date('YmdHis'),
            'orderExpireTime' => date('YmdHis',time()+300),
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'], json_encode($data));
        $data = json_decode($res, true);
        if (isset($data['retCode']) && $data['retCode'] == '0000' && $this->getSign($data) == $data['sign']) {
            return redirect($data['payUrl']);
        }
        $error = @$data['retCode'];
        $error .= $data['retMsg'] ?? '第三方通道异常';
        echo $error;
    }
}