<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/3
 * Time: 19:31
 */

namespace App\Pay;

class BfPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantNo' => $this->payInfo['merchant_code'],
            'orderNum' => $this->payInfo['orderNo'],
            'randomNum' => (string)mt_rand(10000000,99999999),
            'payAmount' => (string)($this->payInfo['money']*100),
            'netwayCode' => 'ZFB',
            'callBackUrl' => $this->payInfo['callback_url'],
            'frontBackUrl' => $this->payInfo['redirect_url'],
            'goodsName' => 'jfcz',
            'requestIP' => $this->get_real_ip(),
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'], 'paramData='.json_encode($data));
        $data = json_decode($res, true);
        if ($data['resultCode'] == '00' && $this->getSign($data) == $data['sign']) {
            $this->curlPayData['qrUrl'] = $data['CodeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo @$data['resultCode'] . ($data['resultMsg'] ?? '第三方通道异常');
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        foreach ($data as $k=>$v) {
            if($v === null || $v ==='')
                unset($data[$k]);
        }
        ksort($data);
        $signStr = stripslashes(json_encode($data,JSON_UNESCAPED_UNICODE)). $this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }

    public function verify($data = '')
    {
        $data = json_decode($data['paramData'],true);
        $this->res['flag'] = $data['resultCode'] == '00' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = '000000';
        return $this->res;
    }
}