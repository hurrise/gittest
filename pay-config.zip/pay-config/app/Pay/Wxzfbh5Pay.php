<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/22 0022
 * Time: 17:26
 */

namespace App\Pay;


class Wxzfbh5Pay extends BasePay
{
    private $data = [
        'tenantId' => null,
        'tenantOrderNo' => null,
        'amount' => null,
        'payWaySan' => null,
        'goodInfo' => null,
        'callBackUrl' => null,
        'callBackViewUrl' => null,
        'schlep' => null,
        'sign_' => null,
    ];
    private $isPhone = 0;
    private $notSignField = [
        'payWaySan',
        'schlep',
        'sign_',
    ];
    public function dorechange($data=""){
        $postData = $this->getPostData($this->payInfo);
        $redirectUrl = $this->getRedirectUrl($postData);
        return redirect($redirectUrl);
    }
    private function getRedirectUrl($postData){
        $mobile = [
            'KJZFSJ',
            'ZFBH5',
            'WXH5',
        ];
        $url = $this->payInfo['gateway_address'];
        if(in_array($postData['payWaySan'],$mobile)){
            $this->isPhone = 1;
        }
        if($this->isPhone == 1){
            $url .= '/xwhPhone';
        }else if($this->isPhone == 0){
            $url .= '/xwhWeb';
        }
        $url .= '?'.http_build_query($postData);
        return $url;
    }
    private function getPostData($data = ""){
        $this->data['tenantId'] = $this->payInfo['merchant_code'];
        $this->data['tenantOrderNo'] = $this->payInfo['orderNo'];
        $this->data['amount'] = (string)sprintf("%0.2f",$this->payInfo['money']);
        $this->data['payWaySan'] = 'ZFBH5';
        $this->data['goodInfo'] = 'wxcz';
        $this->data['callBackUrl'] = $this->payInfo['callback_url'];
        $this->data['callBackViewUrl'] = $this->payInfo['redirect_url'];
        $this->data['schlep'] = 'a-1';
        $this->data['sign_'] = $this->getSign($this->data);
        return $this->data;
    }
    private function getSign($data){
        foreach ($data as $k=>$v){
            if(in_array($k,$this->notSignField)){
                unset($data[$k]);
            }
        }
        ksort($data);
        $signStr = "{";
        foreach ($data as $k=>$v){
            $signStr .= '"'.$k.'"'.':'.'"'.$v.'"'.',';
        }
        $signStr = trim($signStr,',');
        $signStr .= "}".trim($this->payInfo['merchant_secret'],' ');
        $sign_ = md5($signStr);
        return $sign_;
    }
    public function verify($data=""){
        $sign = $data['sign_'];
        unset($data['sign_'],$data['schlep']); // 附加参数和签名不参与加签
        ksort($data); // 升序排列
        $str = "";
        foreach ($data as $key => $val) {
            $str .= '"'.$key. '"' . ":" . '"'. $val . '"' . ',';
        }
        $str = rtrim($str, ',');
        $str = "{".$str."}".$this->payInfo['app_id'];
        $forSign = md5($str);
        if($forSign == $sign){
            $this->res['flag']  = true;
        }
        return $this->res;
    }
}