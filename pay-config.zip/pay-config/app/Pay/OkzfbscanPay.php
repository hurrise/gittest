<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/22 0022
 * Time: 13:19
 */

namespace App\Pay;


class OkzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data0 = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_applydate' => date('Y-m-d H:i:s'),
            'pay_bankcode' => 904,
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
            'pay_amount' => $this->payInfo['money'],
        ];
        $data0['pay_md5sign'] = $this->getSign($data0);
        $data1 = [
            'pay_productname' => 'jfcz',
            'pay_attach' => $this->payInfo['attach'],
            'pay_productnum' => null,
            'pay_productdesc' => null,
            'pay_producturl' => null,
            'format' => 'json',
        ];
        $data = array_merge($data0,$data1);
        customWriteLog('ok',$data);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['returncode'] == '00'){
            return redirect($res['payurl']);
        }
        return '系统异常';
    }
    protected function getSign($data = ""){
        $data = $this->unsetNull($data);
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        customWriteLog('ok',['sign'=>$sign,'signStr'=>$signStr]);
        return $sign;
    }
    public function verify($data = "")
    {
        if($data['returncode'] == '00'){
            $sign = $data['sign'];
            unset($data['sign']);
            unset($data['attach']);
            if($sign == $this->getSign($data)){
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}