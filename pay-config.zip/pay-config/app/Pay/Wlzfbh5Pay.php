<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-12-08
 * Time: 12:10
 */

namespace App\Pay;

class Wlzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->wx_Post( $this->payInfo['gateway_address'],$this->getPostData($data));
            $result = json_decode($url,true);
            if($result['resp_code']=='0000'){
                return redirect($result['data']);
            }else{
                return $result['resp_msg'];
            }
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
        
    }
    
    protected function getPostData(){
        $data = [
            "merchant_no" => $this->payInfo['merchant_code'],
            "amount" => sprintf('%0.2f',$this->payInfo['money']),
            "currency" => '156',   //币种,
            "order_no" => $this->payInfo['orderNo'],
            "pay_code" => 20000, //产品类型 20000:支付宝扫码  30000:微信扫码
            "pay_ip" => $this->get_real_ip(),   //支付ip,
            "request_time" => date('Y-m-d H:i:s'),   //下单时间,
            "product_name" => '支付宝扫码',   //商品名称,
            "return_url" => $this->payInfo['redirect_url'],
            "notify_url" => $this->payInfo['callback_url'],
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['remark'] = null;  //备注

        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['ord_status']=='SUCCESS' && $this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    protected function wx_Post($url,$data,$way="POST"){ #'POST访问
        $ch = curl_init();
        curl_setoPt($ch, CURLOPT_URL, $url);
        curl_setoPt($ch, CURLOPT_CUSTOMREQUEST, $way);
        curl_setoPt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setoPt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setoPt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (comPatible; MSIE 5.01; Windows NT 5.0)');
        curl_setoPt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setoPt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setoPt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setoPt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmPInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        return $tmPInfo;
    }

    public function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
}