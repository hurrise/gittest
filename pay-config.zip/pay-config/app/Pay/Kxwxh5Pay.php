<?php

namespace App\Pay;
class Kxwxh5Pay extends BasePay { 
     private $config = [
        'merNo' => '850650058115360',
        'rechange_url' => 'http://api.kexing688.com/trans-api/trans/api/back.json',
        'private_key' => '-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAu00SYHflQVYVLuKQFI2TN8D22b8LJCyAkrKhyIIdiHNaZ+S9
6DobnJQyePqBu3LPJgWDUIuxkjfG2t9baZeW6rYfa7+5w5MmHR7mX4rfpiFkRqmB
9KAZ6Pbv2RHBokda+ru6lzVsJVbJ7SMMjsBFGYHL4EutrYBy4iIVm6Jm66CSAe63
05bVPnXk8ROfMV/Tm+eEGCW7FuVn01ylTuUr+FiStOApw1e7ClWQF3MdZ+DXTg86
DldlF1hm5oUFs1spawIZExvsoZASJBDKbDwPjMacCEosxxlftfv2FuT1HO/2rv67
zSzsMMJ/3nOO6PUTY7JcT8caVr4fvqDExUxlnwIDAQABAoIBAAD1GOXzVvGpjfwq
XlAslRcQ3nIoftcVfybA0QDkYWBELq8fRTU9rsxzGXry1Nzvbk2kc5Ji1GqJ7HNL
9vyoMLZMbgav+TQduXEmqkjMve3sd8XAshBdDSTatkkmxRWeRcHIWeDR/haGxgt3
RWYpZ3EE79Tari2X3X54bCHah6omqrnScR3fr+Rm9mPXuSjZZYQkWa43XUVYmfWc
w6LEVArpMVT3lJD+CEf+ZcRLciurqTphO106DXQTDOLaxLKHtLOUkb7Y4L+1ZBt7
yP4vOjd0O+o1wfrsEOB1EN/FnQF43zVbhWKKKkuoA/dIVEfVdtI/5U0AIcpek/yM
HHh1bakCgYEA60089jKLQIVyh6k516q4i1ZYZDL6FJPoeZZX56agwl7qQig4vR0i
cqPrMX8d6D2vk14MarDnByQR0SZppvU4oHSRky1kx9C/O1q4LKHNpUR0F19QnWHj
C6KOABYu0yalG3It3nzgE+tx0DNWn6W4H6PNmCYisq2v0SDz00uD7X0CgYEAy8bo
D1WKnQ95+I7VMU81I/GZ9W6wPs35o/Matl+ymY9RFx0monfmXQNRVaj7cXInaJZA
I9af/ZETakPPS2kAu/GlxD3iPx0gdE2hnQy/HJRlVzvyiYbNBn51WXhQqq9RNsOE
pLfO4ZPJtxUbvXdlt5kjAiP2VO/Xx0Kp33bNuksCgYADnKXo6ZG1pdbCOljG9Lns
eaDVuOqZ0kNpSmODDM2+7hIOfeuRC5dxxw5fLiJZZEkDrBfos1p4g5c6bKqGg5Eg
9Wkepz26y3uD/7qABOPRO6HEkhP8tnnzvcUMP0rsttUl/LSzi5ss8xpGJeOYg8S1
x5/qS/uQXpYqUaUsgyY9SQKBgQC8/SuJ1S7qPUlEwcttoOVLAa5lFpQ0mzk02alj
jNuKWYW+ZxXGxmaKyyHqzP7uFw3/jKHN2yakt6EHA/7EFI1OwW2Y1D/5gtzvoHQL
wJ+aNPLL9dgZvkB2DmBtaw19T32Fyc1CKwqe4T7KIrSIgqx+m3MBcDLsUUiRD/2W
N4vTgwKBgQCT604gAf4P05q6Z/uJLZ9GulA5NF9mBYQfIyd50KxE/huX5TmB7oak
if7jcmmDs2fjTlTSTa8sNdoO91IN3oe2N6xo7ep+tcJ4gpGg4tLbzpyW3nJ1zEEg
jbS9bXp24dWzcWjz3U0npGX2kwqRWiCJ3ZhOP6pz8ISlrnjLVbjuHw==
-----END RSA PRIVATE KEY-----',
        'public_key' => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu00SYHflQVYVLuKQFI2T
N8D22b8LJCyAkrKhyIIdiHNaZ+S96DobnJQyePqBu3LPJgWDUIuxkjfG2t9baZeW
6rYfa7+5w5MmHR7mX4rfpiFkRqmB9KAZ6Pbv2RHBokda+ru6lzVsJVbJ7SMMjsBF
GYHL4EutrYBy4iIVm6Jm66CSAe6305bVPnXk8ROfMV/Tm+eEGCW7FuVn01ylTuUr
+FiStOApw1e7ClWQF3MdZ+DXTg86DldlF1hm5oUFs1spawIZExvsoZASJBDKbDwP
jMacCEosxxlftfv2FuT1HO/2rv67zSzsMMJ/3nOO6PUTY7JcT8caVr4fvqDExUxl
nwIDAQAB
-----END PUBLIC KEY-----',
    ];
    private $dataStruct = [
        'version' => null,
        'transType' => null,
        'productId' => null,
        'merNo' => null,
        'orderDate' => null,
        'orderNo' => null,
        'notifyUrl' => null,
        'returnUrl' => null,
        'transAmt' => null,
        'bankCode' => null,
        'commodityName' => null,
        'commodityDetail' => null,
        'signature' => null,
    ];
    
    public function dorechange($data = '') {
        $postData = $this->getPostData($data);
        $res = $this->query($postData);
        echo $res;
    }
    protected function query($data = "") {
        $data = http_build_query($data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $data,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($this->config['rechange_url'], false, $context);
        return $result;
    }

    protected function getPostData($data = "") {
        $this->dataStruct['version'] = '1.0.0';
        $this->dataStruct['transType'] = 'SALES';
        $this->dataStruct['productId'] = $this->payInfo['extend1'];
        $this->dataStruct['merNo'] = $this->payInfo['merchant_code'];
        $this->dataStruct['orderDate'] = date('Ymd');
        $this->dataStruct['orderNo'] = $this->payInfo['orderNo'];
        $this->dataStruct['notifyUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['returnUrl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['transAmt'] = $this->payInfo['money'] * 100;
        $this->dataStruct['bankCode'] = 'CMB';
        $this->dataStruct['commodityName'] = 'kx';
        $this->dataStruct['commodityDetail'] = 'kx';
        $this->dataStruct['signature'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    protected function getSign($data = "") {
        $data = $this->unsetNull($data);
        ksort($data);
        $temp = '';
        foreach ($data as $key => $value) {
            $temp = $temp . $key . '=' . $value . '&';
        }

        $privateKey = openssl_get_privatekey(($this->config['private_key']));
        $temp = substr($temp, 0, strlen($temp) - 1);
        openssl_sign($temp, $sign, $privateKey, OPENSSL_ALGO_SHA1);
        $sign = base64_encode($sign);
        return $sign;
    }

    protected function unsetNull($data) {
        foreach ($data as $k => $v) {
            if (is_null($data[$k])) {
                unset($data[$k]);
            }
        }
        return $data;
    }

    protected function getOrderNo() {
        return 'KX' . uniqid();
    }

    public function verify($data = "") {
        $sign = $data['signature'];
        unset($data['signature']);
        //对返回数据按 ascii 方式排序   注意：如果值为空  不参与签名
        ksort($data);
        $temp = '';
        foreach ($data as $key => $value) {
            $temp = $temp . $key . '=' . $value . '&';
        }
        $temp = substr($temp, 0, strlen($temp) - 1);
        $publicKey = openssl_pkey_get_public($this->config['public_key']);
        if (openssl_verify($temp, base64_decode($sign), $publicKey, OPENSSL_ALGO_SHA1)) {
            return true;
        } else {
            return false;
        }
    }
}
