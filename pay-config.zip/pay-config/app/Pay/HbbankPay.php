<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class HbbankPay extends HbPay
{
    protected function getPostData(){
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_amount' => sprintf('%0.2f',$this->payInfo['money']),
            'pay_applydate' => date("Y-m-d H:i:s"),
            'pay_bankcode' => 907,
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'jfcz';
        $data['pay_productname'] = 'jfcz';
        $data['Pay_bankid'] = $this->payInfo['bank'];
        return $data;
    }
}