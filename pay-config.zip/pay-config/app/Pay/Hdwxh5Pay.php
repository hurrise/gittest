<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-22
 * Time: 10:42
 */

namespace App\Pay;

class Hdwxh5Pay extends HdallPay
{
    protected function getPostData(){
        $data = [
            "pay_memberid" => $this->payInfo['merchant_code'],
            "pay_orderid" => $this->payInfo['orderNo'],
            "pay_applydate" => date('Y-m-d H:i:s'),   //订单时间,
            "pay_bankcode" => '901',
            "pay_notifyurl" => $this->payInfo['callback_url'],
            "pay_callbackurl" => $this->payInfo['redirect_url'],
            "pay_amount" => $this->payInfo['money'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['pay_attach'] = null;  //商户自定义信息
        $data['pay_productname'] = null;  //商品名称
        $data['pay_productid'] = null;  //商品id

        return $data;
    }
}