<?php

namespace App\Pay;

class HfylscanPay extends BasePay {

    private $data = [
        'charset' => null,
        'version' => null,
        'businessType' => null,
        'merchantId' => null,
        'orderId' => null,
        'tranTime' => null,
        'tranAmt' => null,
        'backNotifyUrl' => null,
        'orderDesc' => null,
        'signType' => null,
        'signData' => null,
    ];

    public function dorechange($data = '') {
        $postData = $this->getPostData($data);
        $encrypt = $this->myencrypt($postData);
        $res = $this->query($this->payInfo['gateway_address'], $encrypt);
        $res = json_decode($res, true);
        if ($res['status'] == 00) {
            $this->curlPayData['qrUrl'] = $res['codeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        } else {
            return $this->except($res['msg']);
        }
    }

    private function getPostData($data = '') {
        $this->data['charset'] = 'UTF-8';
        $this->data['version'] = '1.0';
        $this->data['businessType'] = 'unionPayQR';
        $this->data['merchantId'] = $this->payInfo['merchant_code'];
        $this->data['orderId'] = $this->payInfo['orderNo'];
        $this->data['tranTime'] = date('YmdHis');
        $this->data['tranAmt'] = $this->payInfo['money'];
        $this->data['backNotifyUrl'] = $this->payInfo['callback_url'];
        $this->data['orderDesc'] = 'hf';
        $this->data['signType'] = 'MD5';
        $this->data['signData'] = $this->getSign($this->data);
        return $this->data;
    }

    private function getSign($data) {
        unset($data['signType'], $data['signData']);
        $signStr = 'charset=%s&version=%s&businessType=%s&merchantId=%s&orderId=%s&tranTime=%s&tranAmt=%s&backNotifyUrl=%s&orderDesc=%s&%s';
        $signStr = sprintf($signStr, $data['charset'], $data['version'], $data['businessType'], $data['merchantId'], $data['orderId'], $data['tranTime'], $data['tranAmt'], $data['backNotifyUrl'], $data['orderDesc'], $this->payInfo['merchant_secret']);
        $sign = strtoupper(md5($signStr));
        return $sign;
    }

    private function myencrypt($postData) {
        $postData = json_encode($postData);
        $encrypt = base64_encode($postData);
        return $encrypt;
    }

    private function query($url, $post_data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);

        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }

    public function verify($data='') {
        $strData = base64_decode($data,true);
        $arr = json_decode($strData, true);
        $arr['tranAmt'] = number_format($arr['tranAmt'], 2, '.', '');
        $secret = $this->payInfo['merchant_secret'];
        $serverSignData = $arr['signData'];
        unset($arr['signData']);
        unset($arr['signType']);
        foreach ($arr as $k => $v) {
            if (empty($arr[$k])) {
                unset($arr[$k]);
            }
        }
        $strData = $this->ToUrlParams($arr, $secret);
        $res = strtoupper(md5($strData));
        if ($res == $serverSignData) {
            $this->res['flag']=true;
        }
        return $this->res;
    }

    private function ToUrlParams($arr, $secret = '') {
        $buff = "";
        foreach ($arr as $key => $val) {
            $buff .= $key . "=" . "$val" . "&";
        }
        return $buff . $secret;
    }

}
