<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/5 0005
 * Time: 16:04
 */

namespace App\Pay;


class Bfbwxh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'price' => sprintf('%0.2f',$this->payInfo['money']),
            'istype' => 2,
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
            'orderid' => $this->payInfo['orderNo'],
            'orderuid' => uniqid(),
            'goodsname' => 'jfcz',
            'attach' => 'jfcz',
        ];
        $data['key'] = md5($data['goodsname'].'+'.$data['istype'].'+'.$data['notify_url'].'+'.$data['orderid'].'+'.$data['orderuid'].'+'.$data['price'].'+'.$data['return_url'].'+'.$this->payInfo['merchant_secret'].'+'.$data['uid']);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $data = json_decode($res,true);
        if($data['code'] == 1){
            return redirect($data['data']['qrcode']);
        }
        $error = isset($data['code']) ? $data['code'] : '';
        $error .= isset($data['msg']) ? $data['msg'] : '第三方通道异常';
        echo $error;
    }
    public function verify($data = "")
    {
        if($data['key'] == md5($data['orderid'] . '+' .$data['orderuid'] . '+' .$data['platform_trade_no'] . '+' .$data['price'] . '+' .$data['realprice'] . '+' .$this->payInfo['merchant_secret'])){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'OK';
        return $this->res;
    }
}