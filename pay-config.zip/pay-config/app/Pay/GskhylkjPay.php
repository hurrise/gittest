<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/31 0031
 * Time: 15:35
 */

namespace App\Pay;


class GskhylkjPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantNo' => $this->payInfo['merchant_code'],  //商户编号
            'orderPrice' => $this->payInfo['money'], //订单金额
            'outOrderNo' => $this->payInfo['orderNo'],  //商户支付订单号
            'tradeType' => 'kj_pay_t0', //交易类别--快捷T0支付支付
            'tradeTime' => date('YmdHis'),  //交易下单时间
            'goodsName' => 'Gskhylkj',  //商品名称
            'tradeIp' => $this->get_real_ip(),  //交易IP
            'bankCode' => 'ICBC',  //银行编码--工商银行（银联快捷随便填个）
            'bankTradeType' => 'PRIVATE_DEBIT_ACCOUNT', //账户交易类型--对私借记卡
            'returnUrl' => $this->payInfo['redirect_url'], //页面通知地址
            'notifyUrl' => $this->payInfo['callback_url'], //后台异步通知地址
            'remark' =>  'Gskhylkj' //备注
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('GskhylkjPay',json_encode($data));
        return $this->redirect($data,'post');
    }
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."secretKey=".$this->payInfo['merchant_secret'];
        customWriteLog('GskhylkjPay','$stringSignTemp '.$stringSignTemp);
        $Str =strtoupper(MD5($stringSignTemp));
        return $Str;
    }

    public function verify($data = "")
    {
        if($data['tradeStatus'] == 'SUCCESS' && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}