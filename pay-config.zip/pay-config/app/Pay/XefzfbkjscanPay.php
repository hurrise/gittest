<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-08
 * Time: 12:39
 */

namespace App\Pay;

class XefzfbkjscanPay extends BasePay
{
    public function dorechange($data=""){
        try{
            $postData = $this->getPostData($data);
            return $this->redirect($postData);
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = $this->getData();
        $sign = $this->getSign($data);
        $model = [//定义一个是数组用于POST
            'partner' => $this->payInfo['merchant_code'],
            'encryptType' => 'md5',
            'msgData' => base64_encode(json_encode($data)),
            'signData' => $sign,
        ];
        return $model;
    }

    protected function getData(){
        $data = [
            "orderId" => $this->payInfo['orderNo'],
            "merchId" => $this->payInfo['merchant_code'],
            "payWay" => 'aliquick',   //支付通道(微信扫码快捷:wxquick,支付宝扫码快捷:aliquick,QQ扫码快捷:qqquick),
            "curType" => 'CNY',   //币种,
            "tranTime" => date('YmdHis'),   //发起交易时间,
            "totalAmt" => $this->payInfo['money'] * 100, //金额 按分为单位。 100实际为1元
            "title" => 'XEFwxquick',   //订单标题,
            "notifyUrl" => $this->payInfo['callback_url'],
            "returnUrl" => $this->payInfo['redirect_url'],
            "clientIp" => $this->get_real_ip(),   //客户端Ip,
        ];
        return $data;
    }

    protected function getSign($param = ""){
        $mopost = json_encode($param); //数组转换成JSON
        $md5data = md5($mopost . $this->payInfo['merchant_secret']); //MD5加密和KEY加密验证
        return $md5data;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
    
    public function verify($data=""){
        $msgdata = $data['msgData'];
        $md5data = md5($msgdata . $this->payInfo['merchant_secret']);
        if ($md5data == $data["signData"]) { //校验是否是你提交的数据
            return $this->res['flag']=true;
        }
        $this->res['callback_param'] = "000000";
        return $this->res;
    }
}