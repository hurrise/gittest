<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/22 0022
 * Time: 18:44
 */

namespace App\Pay;

class ShqqscanPay extends BasePay {

    private $dataStruct = [
        'amount' => null,
        'currentTime' => null,
        'merchant' => null,
        'notifyUrl' => null,
        'orderNo' => null,
        'payType' => null,
        'remark' => null,
        'returnUrl' => null,
        'sign' => null,
    ];

    public function dorechange($data = '') {
        $postData = $this->getPostData($data);
        return $this->redirect($postData);
    }

    public function redirect($data = "",$method = 'post') {
        $url = $this->payInfo['gateway_address'];
        $htmlStr = '<form id="submit" name="submit" method="'.$method.'" action="' . $url . '">';
        foreach ($data as $key => $val) {
            $htmlStr .= "<input type='hidden' name='" . $key . "' value='" . $val . "'>";
        }
        $htmlStr .= '<input type="submit" value="提交" style="display:none;" />';
        $htmlStr .= '</form>';
        $htmlStr .= '<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }

    public function getPostData($data = "") {
        $this->dataStruct['amount'] = number_format(floatval($this->payInfo['money']), 2, '.', '');
        $this->dataStruct['currentTime'] = date('YmdHis');
        $this->dataStruct['merchant'] = $this->payInfo['merchant_code'];
        $this->dataStruct['notifyUrl'] = $this->payInfo['callback_url'];
        $this->dataStruct['orderNo'] = $this->payInfo['orderNo'];
        $this->dataStruct['payType'] = 'qqpay';
        $this->dataStruct['remark'] = 'shaunghui';
        $this->dataStruct['returnUrl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    public function getSign($data = []) {
        $sign = "amount=" . $data['amount'] . "&currentTime=" . $data['currentTime'] . "&merchant=" . $data['merchant'] . "&notifyUrl=" . $data['notifyUrl'] . "&orderNo=" . $data['orderNo'] . "&payType=" . $data['payType'];
        if (isset($data['remark']) && $data['remark'] != '') {
            $sign = $sign . "&remark=" . $data['remark'];
        }
        if (isset($data['returnUrl']) && $data['returnUrl'] != '') {
            $sign = $sign . "&returnUrl=" . $data['returnUrl'];
        }
        $sign = $sign . "#" . $this->payInfo['merchant_secret'];
        $sign = md5($sign);
        return $sign;
    }

    public function verify($data = '') {
        if ($data['sign'] == $this->getNotifyUrl($data)) {
            $this->res['flag'] = true;
        }
        return $this->res;
    }
    public function getNotifyUrl($data = '') {
        $accFlag = $data['accFlag']; //账号所属（1平台、2商户）
        $accName = $data['accName']; //收款账号（微信账号、支付宝账号等）
        $amount = number_format(floatval($data['amount']), 2, '.', ''); //订单金额（元，两位小数）
        $createTime = $data['createTime']; //创建时间 ( 格式为：yyyyMMddHHmmss )
        $currentTime = $data['currentTime']; //当前时间 ( 格式为：yyyyMMddHHmmss )
        $merchant = $data['merchant']; //商户号
        $orderNo = $data['orderNo']; //订单号
        $payFlag = $data['payFlag']; //支付状态 ( 1未支付，2已支付，3已关闭 ) 
        $payTime = $data['payTime']; //支付时间 ( 格式为：yyyyMMddHHmmss )
        $payType = $data['payType']; //支付类型
        $remark = $data['remark']; //备注信息
        $systemNo = $data['systemNo']; //同步回调地址
        $sign = $data['sign']; //md5密钥（KEY）
        $key = $this->payInfo['merchant_secret']; //md5密钥（KEY）
        $mySign = "accFlag=" . $data['accFlag'] . "&accName=" . $data['accName'] . "&amount=" . $data['amount'] . "&createTime=" . $data['createTime'] . "&currentTime=" . $data['currentTime'] . "&merchant=" . $data['merchant'] . "&orderNo=" . $data['orderNo'] . "&payFlag=" . $data['payFlag'] . "&payTime=" . $data['payTime'] . "&payType=" . $data['payType'];
        if ($remark != "") {
            $mySign = $mySign . "&remark=" . $remark;
        }
        $mySign = $mySign . "&systemNo=" . $systemNo;
        $mySign = $mySign . "#" . $key;
        $mySign = md5($mySign);

        if ($sign == $mySign) {
            return true;
        } else {
            return false;
        }
    }
    
    
     public function save_log( $path , $msg )
    {
        if (!is_dir($path)) {
            mkdir($path);
        }
        $filename = $path . '/' . date('YmdHi') . '.txt';
        $content = date("Y-m-d H:i:s") . "\r\n" . $msg . "\r\n \r\n \r\n ";
        file_put_contents($filename , $content , FILE_APPEND);
    }

}
