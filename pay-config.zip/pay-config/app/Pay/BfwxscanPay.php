<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/3
 * Time: 19:31
 */

namespace App\Pay;

class BfwxscanPay extends BfPay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantNo' => $this->payInfo['merchant_code'],
            'orderNum' => $this->payInfo['orderNo'],
            'randomNum' => (string)mt_rand(10000000,99999999),
            'payAmount' => (string)($this->payInfo['money']*100),
            'netwayCode' => 'WX',
            'callBackUrl' => $this->payInfo['callback_url'],
            'frontBackUrl' => $this->payInfo['redirect_url'],
            'goodsName' => 'jfcz',
            'requestIP' => $this->get_real_ip(),
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'], 'paramData='.json_encode($data));
        $data = json_decode($res, true);
        if ($data['resultCode'] == '00' && $this->getSign($data) == $data['sign']) {
            $this->curlPayData['qrUrl'] = $data['CodeUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo @$data['resultCode'] . ($data['resultMsg'] ?? '第三方通道异常');
    }
}