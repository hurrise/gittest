<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/4 0004
 * Time: 16:53
 */

namespace App\Pay;


class DszfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'agent_id' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_amount' => $this->payInfo['money'],
            'pay_applydate' => date('YmdHis'),
            'pay_bankcode' => 'ALIPAYPAYQR',
            'pay_notifyurl' => $this->payInfo['callback_url'],
        ];
        // 按字母顺序排列
        ksort($data);
        // 把所有的值连起来进行MD5加密变为签名
        $data['sign'] = md5(implode($data).$this->payInfo['merchant_secret']);
        $data['show_url'] = 0;
        $data = http_build_query($data);
        $url = trim($this->payInfo['gateway_address'],'/').'?'.$data;
        header('Location:'.$url);
    }
    public function verify($data = "")
    {
        $sign = $data['sign'];
        if($data['code'] == 10000){
            unset($data['sign']);
            foreach ($data as $k=>$v){
                if(is_null($data[$k])){
                    unset($data[$k]);
                }
            }
            $newSign = md5(implode($data).$this->payInfo['merchant_secret']);
            if($newSign == $sign){
                $this->res['flag'] = true;
            }
        }
        return $this->res;
    }
}