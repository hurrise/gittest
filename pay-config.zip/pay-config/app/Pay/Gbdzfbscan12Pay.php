<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/13
 * Time: 14:37
 */

namespace App\Pay;

class Gbdzfbscan12Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'price' => sprintf('%0.2f', $this->payInfo['money']),
            'paytype' => 12,
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
            'user_order_no' => $this->payInfo['orderNo'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = md5($data['uid'] . $data['price'] . $data['paytype'] . $data['notify_url'] . $data['return_url'] . $data['user_order_no'] . $this->payInfo['merchant_secret']);
        return $this->redirect($data,'post');
    }

    public function verify($data = '')
    {
        $sign = md5($data['user_order_no'] . $data['orderno'] . $data['tradeno'] . $data['price'] . $data['realprice'] . $this->payInfo['merchant_secret']);
        $this->res['flag'] = $sign == $data['sign'];
        return $this->res;
    }
}