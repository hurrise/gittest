<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-16
 * Time: 04:32
 */

namespace App\Pay;

class Suhzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->sh_curl_post($this->payInfo['gateway_address'],$this->getPostData($data));
            $urlarray = json_decode($url,true);
            if(isset($urlarray['is_success'])){  //响应成功
                if($urlarray['is_success'] == "TRUE"){
                    return redirect($urlarray['url']);
                }
                return $this->except($urlarray['msg']);
            }
            if(isset($urlarray['code'])){  //响应失败
                return $this->except($urlarray['message']);
            }
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
           "merchant_code" => $this->payInfo['merchant_code'],
            "order_no" => $this->payInfo['orderNo'],
            "order_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "pay_type" => 'ALIH5',   //支付方式,
            "bank_code" => 'ALIH5',   //银行编码(非网银支付请填入pay_type此参数相同的值),
            "order_time" => strtotime("now"),   //商户订单时间(时间戳),
            "customer_ip" => $this->get_real_ip(),   //消费者IP,
            "notify_url" => $this->payInfo['callback_url'],
            "return_url" => $this->payInfo['redirect_url'],
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['return_params'] = "";  //回传参数
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""||$v==NULL){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        if($data['trade_status']=="success" && $this->getSign($data) == $data['sign']){
            $this->res['flag']=true;
        }
        return $this->res;
    }
    protected function sh_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/json; charset=utf-8",
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
}