<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class SzhqqscanPay extends BasePay
{
    public function dorechange($data=""){
        $res = $this->curl_get($this->payInfo['gateway_address'].'?'.http_build_query($this->getPostData()));
        $data = json_decode($res,true);
        if($data['ok']){
            return redirect($data['img']);  //$data['img'] 二维码图片的地址，拿微信/支付宝扫一扫就能调起支付
            $this->curlPayData['qrUrl'] = $data['data'];    // $data['data'] 跳转到该URL就能调起支付
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $this->except($data['code'].' '.$data['msg']);
    }
    protected function getPostData(){
        $data = [
            'mchId' => $this->payInfo['merchant_code'],
            'pay_type' => 'qqqrcode',
            'amount' => $this->payInfo['money']*100,
            'time' => time(),
            'tradeNo' => $this->payInfo['orderNo'],
            'return_url' => $this->payInfo['redirect_url'],
            'notify_url' => $this->payInfo['callback_url'],
            'card_type' => 1,
            'yl_pay_type' => '',
            'bank_name' => '',
            'sign' => '',
            'extra' => 'shizihui',
            'client_ip' => get_real_ip()
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        $signStr = $data['tradeNo'].$data['amount'].$data['pay_type'].$data['time'].$data['mchId'].md5($this->payInfo['merchant_secret']);
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $signStr =  $data['tradeNo'].$data['orderNo'].$data['amount'].$data['mchId'].$data['pay_type'].$data['time'].md5($this->payInfo['merchant_secret']);
        if(strtolower(md5($signStr)) == $data['sign']){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
    protected function curl_get($url){
        $ch = curl_init();//初始化
        curl_setopt($ch,CURLOPT_URL,$url);//设置变量
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch,CURLOPT_HEADER,0);
        $output = curl_exec($ch);//执行并获取结果
        curl_close($ch);
        return $output;
    }

}