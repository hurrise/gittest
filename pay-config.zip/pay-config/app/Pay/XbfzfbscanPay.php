<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/18 0018
 * Time: 18:16
 */

namespace App\Pay;


use App\Sevice\CurlService;

class XbfzfbscanPay extends BasePay
{
    private $dataStruct = [
        'app_id' => null,
        'channel' => null,
        'order_sn' => null,
        'amount' => null,
        'notify_url' => null,
        'return_url' => null,
        'nonce_str' => null,
        'sign' => null,
    ];
    public function dorechange($data="")
    {
        $postData = $this->getPostData($this->payInfo);
        $res = CurlService::getInstance()->post($this->payInfo['gateway_address'],$postData);
        $res = json_decode($res,true);
        if($res['code'] == 200){
            return redirect($res['data']['cashier_url']);
        }else{
            return redirect(url('message/error/Error_'.$res['code'].'-'.$res['msg'])); //todo 报错信息页面;
        }
    }
    private function getPostData($data=""){
        $this->dataStruct['app_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['channel'] = $this->payInfo['extend1'];
        $this->dataStruct['order_sn'] = $this->payInfo['orderNo'];
        $this->dataStruct['amount'] = $this->payInfo['money'];
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = null;
        $this->dataStruct['nonce_str'] = $this->getNonce();
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    private function getSign($data = ""){
        $data = $this->unsetNull($data);
        ksort($data);
        $data['app_key'] = $this->payInfo['merchant_secret'];
        $signStr = urldecode(http_build_query($data));
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    private function getNonce(){
        return md5(uniqid());
    }

    /**
     * @param $data
     * @return bool
     */
    public function verify($data="")
    {
        $sign1 = $data['sign'];
        unset($data['sign']);
        $sign2 = $this->getSign($data);
        if($sign1 == $sign2){
            return true;
        }else{
            return false;
        }
    }
}