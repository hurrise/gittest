<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class SzhylkjPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData());
    }
    protected function getPostData(){
        $data = [
            'mchId' => $this->payInfo['merchant_code'],
            'pay_type' => 'ylpay',
            'amount' => $this->payInfo['money']*100,
            'time' => time(),
            'tradeNo' => $this->payInfo['orderNo'],
            'return_url' => $this->payInfo['redirect_url'],
            'notify_url' => $this->payInfo['callback_url'],
            'card_type' => 1,  //1.储蓄卡，2信用卡 (pay_type为ylpay必传)
            'yl_pay_type' => 'B2C', //B2C,B2B (pay_type为ylpay必传)
            'bank_name' => '',  //工商银行 具体附录联系客服(pay_type为ylpay必传)
            'sign' => '',
            'extra' => 'shizihui',
            'client_ip' => get_real_ip()
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        $signStr = $data['tradeNo'].$data['amount'].$data['pay_type'].$data['time'].$data['mchId'].md5($this->payInfo['merchant_secret']);
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $signStr =  $data['tradeNo'].$data['orderNo'].$data['amount'].$data['mchId'].$data['pay_type'].$data['time'].md5($this->payInfo['merchant_secret']);
        if(strtolower(md5($signStr)) == $data['sign']){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}