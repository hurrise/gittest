<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/23 0023
 * Time: 20:13
 */

namespace App\Pay;


class Jintzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'id' => $this->payInfo['merchant_code'],
            'money' => sprintf('%0.2f',$this->payInfo['money']),
            'notify_url' => $this->payInfo['callback_url'],
            'out_trade_no' => $this->payInfo['orderNo'],
            'user_name' => get_real_ip(),
            'type' => 'alipay',
            'sign' => '',
            'sign_type' => 'MD5',
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'],http_build_query($data));
        $data = json_decode($res,true);
        if($data['code'] == '1'){
            return redirect($data['data']['pay_url']);
        }
        echo $data['code'],' ',$data['msg'];

    }
    private function getSign($data=""){
        unset($data['sign']);
        unset($data['sign_type']);
        sort($data,SORT_STRING);
        $signStr = implode($data).$this->payInfo['merchant_secret'];
        return md5($signStr);
    }
    public function verify($data = ""){
        if($data['sign'] == $this->getSign($data)){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = '{"code":200,"msg":"已收到回调"}';
        return $this->res;
    }
}