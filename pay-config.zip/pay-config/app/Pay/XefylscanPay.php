<?php

namespace App\Pay;

class XefylscanPay extends BasePay {

    public function getPost() {
        $post = [
            'attach' => 'xefzfbscan',
            'curType' => 'CNY', //人民币
            'merchId' => $this->payInfo['merchant_code'], //商户ID
            'notifyUrl' => $this->payInfo['callback_url'], //需要使用服务器能访问的地址
            'orderId' => $this->payInfo['orderNo'], //订单号
            'payWay' => 'unionpay', //支付方式 支付宝：alipay QQ钱包：qqpay  百度钱包：bdpay   微信：weixin
            'title' => '积分充值', //标题
            'totalAmt' => $this->payInfo['money'] * 100, //金额 按分为单位。 100实际为1元
            'tranTime' => time() . rand(100, 200), //自己订单号
        ];
        return $post;
    }

    public function dorechange($data = '') {
        $postData = $this->getData();
        return $this->redirect($postData);
    }

    public function getData() {
        $post = $this->getPost();
        $sign = $this->getSign($post);
        $model = [//定义一个是数组用于POST
            'partner' => $this->payInfo['merchant_code'],
            'encryptType' => 'md5',
            'msgData' => base64_encode(json_encode($post)),
            'signData' => $sign,
        ];
        return $model;
    }

    public function getSign($param) {
        $mopost = json_encode($param); //数组转换成JSON
        $md5data = md5($mopost . $this->payInfo['merchant_secret']); //MD5加密和KEY加密验证
        return $md5data;
    }

    public function verify($data = "") {
        $msgdata = $data['msgData'];
        $md5data = md5($msgdata . $this->payInfo['merchant_secret']);
        if ($md5data == $data["signData"]) { //校验是否是你提交的数据
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = '000000';
        return $this->res;
    }
}
