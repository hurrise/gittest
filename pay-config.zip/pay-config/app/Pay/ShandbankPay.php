<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/20 0020
 * Time: 13:01
 */

namespace App\Pay;


class ShandbankPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'version' => '1.0',
            'customerid' => $this->payInfo['merchant_code'],
            'sdorderno' => $this->payInfo['orderNo'],
            'total_fee' => $this->payInfo['money'],
            'paytype' => 'bank',
            'bankcode' => $this->payInfo['bank'],
            'notifyurl' => $this->payInfo['callback_url'],
            'returnurl' => $this->payInfo['redirect_url'],
            'remark' => 'jfcz',
            'get_code' => null,
        ];
        $data['sign'] = md5("version={$data['version']}&customerid={$data['customerid']}&total_fee={$data['total_fee']}&sdorderno={$data['sdorderno']}&notifyurl={$data['notifyurl']}&returnurl={$data['returnurl']}&{$this->payInfo['merchant_secret']}");
        return $this->redirect($data,'post');
    }
    public function verify($data = "")
    {
        $this->res['callback_param'] = 'success';
        if($data['status'] == 1) {
            $sign = md5("customerid={$data['customerid']}&status={$data['status']}&sdpayno={$data['sdpayno']}&sdorderno={$data['sdorderno']}&total_fee={$data['total_fee']}&paytype={$data['paytype']}&{$this->payInfo['merchant_secret']}");
            if($sign == $data['sign']){
                $this->res['flag'] = true;
            }
        }
        return $this->res;
    }
}