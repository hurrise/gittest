<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/11 0011
 * Time: 15:54
 */

namespace App\Pay;


class TzzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'mch_id' => $this->payInfo['merchant_code'],
            'out_trade_no' => $this->payInfo['orderNo'],
            'body' => 'jfcz',
//            'sub_openid' => null,
            'callback_url' => $this->payInfo['redirect_url'],
            'notify_url' => $this->payInfo['callback_url'],
            'total_fee' => sprintf('%0.2f',$this->payInfo['money']),
            'service' => 'al',
            'way' => 'pay',
//            'Appid' => null,
            'format' => 'json',
//            'mch_create_ip' => $this->get_real_ip(),
//            'goods_tag' => null,
        ];
        $data['sign'] = md5($data['mch_id'].$data['out_trade_no'].$data['callback_url'].$data['notify_url'].$data['total_fee'].$data['service'].$data['way'].$data['format'].$this->payInfo['merchant_secret']);

        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['success']){
            $this->curlPayData['qrUrl'] = $res['pay_info'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $this->except();
    }
    public function verify($data = "")
    {
        if($data['result_code'] == 0) {
            $sign = md5($data['mch_id'] . $data['time_end'] . $data['out_trade_no'] . $data['ordernumber'] . $data['transtypeid'] . $data['transaction_id'] . $data['total_fee'] . $data['service'] . $data['way'] . $data['result_code'] . $this->payInfo['merchant_secret']);
            if(strtoupper($data['sign']) == strtoupper($sign)){
                $this->res['flag'] = true;
            }
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}