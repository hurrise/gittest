<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-07
 * Time: 10:46
 */

namespace App\Pay;

class Lszfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            $url = $this->ls_curl_post( $this->payInfo['gateway_address'],$this->getPostData($data));
            customWriteLog('Lszfbh5Pay',$url);
            $result = json_decode($url,true);
            if($result['return_code']=="0000"){
                return redirect($result['html']);
            }
            return $this->except($result['return_msg']);
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
            "merchantNo" => $this->payInfo['merchant_code'], //商户号（自己生产的）
            "userId" => $this->payInfo['merchant_code'], //平台商户号（第三方給予的）
            "tradeType" => '10C',   //交易类型(10C-支付宝H5、10F-银联H5、10H-微信H5、10J-QQ钱包wap、10M-网关支付、10S-快捷H5),
            "trxAmt" => $this->payInfo['money'],
            "orderNo" => $this->payInfo['orderNo'],
            "ip" => $this->get_real_ip(),   //交易ip,
            "returnUrl" => $this->payInfo['redirect_url'],
            "notifyUrl" => $this->payInfo['callback_url'],
            "productName" => 'LSzfbh5',   //商品名称,
            "productDes" => 'LSzfbh5',   //商品描述,
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('Lszfbh5Pay','getPostData  '.json_encode($data));
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        customWriteLog('Lszfbh5Pay','verify  '.json_encode($data));
        if($this->getSign($data) == $data['sign']){
            $this->res['flag']=true;

        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    public function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }

    protected function ls_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "accept: */*",
                "content-type: application/json; charset=utf-8",
                "connection: Keep-Alive",
                "user-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)"
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}