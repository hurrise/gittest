<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/21
 * Time: 19:48
 */

namespace App\Pay;

class Xwzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'app_id' => $this->payInfo['merchant_code'],
            'agentOrder' => $this->payInfo['orderNo'],
            'timestamp' => time(),
            'money' => $this->payInfo['money']*100,
            'channel' => 'alipay',
            'notifyUrl' => $this->payInfo['callback_url'],
        ];
        $data['sign'] = strtoupper(md5($data['app_id'].$this->payInfo['merchant_secret'].$data['timestamp']));
        $res = $this->curl_post($this->payInfo['gateway_address'], $data);
        $data = json_decode($res, true);
        is_array($data) or die('第三方通道异常');
        if (@$data['code'] == '1') {
            return redirect($data['data']['qrcode']);
        }
        echo @$data['code'] . ($data['msg'] ?? '第三方通道异常');
    }

    public function verify($data = '')
    {
        $arr = $data['data'];
        $sign = strtoupper(md5($arr['app_id'].$this->payInfo['merchant_secret'].$arr['timestamp'].$arr['orderId'].$arr['money']));
        $this->res['flag'] = $data['code'] == '1' && $sign == $arr['sign'];
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8','access-token:'.array_pop($data)));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}