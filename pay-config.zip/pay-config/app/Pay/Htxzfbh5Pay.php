<?php

namespace App\Pay;

class Htxzfbh5Pay extends BasePay
{
    private $dataStruct = [
        'shop_id' => null,
        'user_id' => null,
        'money' => null,
        'type' => null,
        'sign' => null,
        'shop_no' => null,
        'return_url' => null,//成功后网页跳转地址
        'notify_url' => null,//
    ];

    public function dorechange($data = ''){
        $postData = $this->getPostData();
        $pay_url = $this->payInfo[ 'gateway_address' ];
        $res = $this->query($pay_url,json_encode($postData));
        $res = json_decode($res,true);
        if($res['messages']['returncode'] == 'SUCCESS'){
            return redirect($res['payurl']);
        }
        $this->errorRedirect();
    }

    public function query($url,$data_string = ""){
        $ch = curl_init();//初始化
        curl_setopt($ch,CURLOPT_URL,$url);//设置变量
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        if(!empty($data)){
            //todo 模拟post请求
            curl_setopt($ch,CURLOPT_POST,1);
            curl_setopt($ch,CURLOPT_POSTFIELDS,$data_string);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_string)
            ));
        }else{
            curl_setopt($ch,CURLOPT_HEADER,0);
            //todo 模拟get请求
        }
        $output = curl_exec($ch);//执行并获取结果
        curl_close($ch);
        return $output;
    }

    public function getSign($data=""){
        $string = $data['shop_id'].$data['user_id'].$data['money'].$data['type'].$this->payInfo['merchant_secret'];
        return strtoupper(md5($string));
    }

    protected function getPostData(){
        $this->dataStruct['shop_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['user_id'] = 'test';
        $this->dataStruct['money'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['type'] = $this->payInfo['extend1'];
        $this->dataStruct['shop_no'] = $this->payInfo['orderNo'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }

    public function verify($data = ''){
        customWriteLog('verify',json_encode($data));
        $sign = $data["sign"];					//服务器API接口返回的唯一key
        $signStr = $data['shop_id'].$data['user_id'].$this->payInfo['orderNo'].$this->payInfo['merchant_secret'].$data['type'].$data['money'];
        $temp_sign = strtoupper(md5($signStr));

        if($temp_sign == $sign){
            return true;
        }
        return false;
    }
}