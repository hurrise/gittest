<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class Suhuizfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        $postData = $this->getPostData();
        $json = $this->curl_post($this->payInfo['gateway_address'],json_encode($postData));
        $data = json_decode($json,true);
        if($data['is_success'] && $this->verify($data)){
            return redirect($data['url']);
        }
        return $this->except($data['msg']);
    }
    protected function getPostData(){
        $data = [
            'merchant_code' => $this->payInfo['merchant_code'],
            'order_no' => $this->payInfo['orderNo'],
            'order_amount' => sprintf('%0.2f',$this->payInfo['money']),
            'pay_type' => 'ALIH5',
            'bank_code' => 'ALIH5',
            'order_time' => time(),
            'customer_ip' => get_real_ip(),
            'return_params' => '',
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url']
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['sign'])){
            unset($data['sign']);
        }
        ksort($data);
        $signStr = '';
        foreach($data as $k => $v) {
            if($v != '') {
                $signStr .= $k . "=" . $v . "&";
            }
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
        $sign = strtolower(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $sign = $this->getSign($data);
        if($sign == $data['sign']){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data)
        ));
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}