<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/10/29
 * Time: 21:14
 */
namespace App\Pay;

class SdwxsmPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData());
    }
    protected function getPostData(){
        $data = [
            "sdk" => $this->payInfo['merchant_code'],
            "order_id" => $this->payInfo['orderNo'],
            "money" => sprintf('%0.2f',$this->payInfo['money']),
            "refer" => $this->payInfo['redirect_url'],
            "notify_url" => $this->payInfo['callback_url'],
            "Identification" => $this->payInfo['app_id'],
        ];
        $data["sign"] = md5(md5($data['money'] . $data['order_id'] . $data['sdk']));
        return $data;
    }
    public function verify($data=""){
        $this->res['callback_param'] = 'SUCCESS';
        $data = json_decode(array_keys($data)[0],true);
        $signStr = sprintf('%0.2f',$data['old_money']) . $data['order_id'] . $data['sdk'] . $this->payInfo['merchant_secret'];
        $this->res['flag'] = md5(md5($signStr)) == $data['sign'];
        return $this->res;
    }
}