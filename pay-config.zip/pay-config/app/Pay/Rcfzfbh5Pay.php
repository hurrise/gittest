<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-28
 * Time: 02:14
 */

namespace App\Pay;

class Rcfzfbh5Pay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return '通道异常，请即时与第三方联系';
        }
    }
    
    protected function getPostData(){
        $data = [
           "requestNo" => $this->payInfo['orderNo'],   //请求流水号,
           "productId" => '0121',
            "transId" => '01',   //交易类型(扫码类的transId值为10,其它支付全是01),
            "merNo" => $this->payInfo['merchant_code'],
            "orderDate" => date("Ymd"),   //订单日期,
            "orderNo" => $this->payInfo['orderNo'],
            "returnUrl" => $this->payInfo['redirect_url'],
            "notifyUrl" => $this->payInfo['callback_url'],
            "transAmt" => sprintf('%s', $this->payInfo['money']*100),  //单位为分
            "commodityName" => '支付宝H5',   //商品名称,
            "memo" => 'rcfzfbh5',   //备注,
        ];
        $data['signature'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['version'] = 'V4.0';  //版本号
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        unset($data['signature']);
        foreach ($data as $k=>$v){
            if(empty($v)){
                unset($data[$k]);
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= substr($Str,0,-1).$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        if($data['respCode'] == '0000' && $this->getSign($data) == $data['signature']) {
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}