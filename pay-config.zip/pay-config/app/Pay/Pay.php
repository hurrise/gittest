<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/16 0016
 * Time: 19:05
 */

namespace App\Pay;


interface Pay
{
    public function dorechange($data="");
    public function verify($data="");
}