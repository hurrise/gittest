<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/17
 * Time: 14:33
 */

namespace App\Pay;

class Xxbzfbh5Pay extends BasePay
{

    public function postData()
    {
        $post = [
          'money'=>(int)$this->payInfo['money'],
          'paytype'=>'ALIPAY',
          'merchantId'=>$this->payInfo['merchant_code'],
          'timestamp'=>time()*1000,
          'goodsName'=>'积分充值',
          'notifyURL'=>$this->payInfo['callback_url'],
          'returnURL'=>$this->payInfo['redirect_url'],
          'merchantOrderId'=>$this->payInfo['orderNo'],
          'merchantUid'=>'',
        ];
        $post['sign'] = $this->getSign($post);
        return $post;
    }

    public function dorechange($data = '')
    {
        $params =  $this->postData($data);
//        $res = $this->curl_post($this->payInfo['gateway_address'],$params);
//        $res = json_decode($res,true);
//        dd($res);
//        if($res['code'] == '10000'){
//            return redirect($res['payURL']);
//        }
//        return $this->except($res['message']);
        return $this->redirect($params,'post');
    }

    public function getSign($data = [])
    {
      return md5($data['money'].'&'.$data['merchantId'].'&'.$data['notifyURL'].'&'.$data['returnURL'].'&'.$data['merchantOrderId'].'&'.$data['timestamp'].'&'.$this->payInfo['merchant_secret']);
    }

    public function verify($data = [])
    {
        $orderNo = $data["orderNo"];
        $merchantOrderNo = $data["merchantOrderNo"];
        $money = $data["money"];
        $payAmount = $data["payAmount"];
        $sign = $data["sign"];
        $md5_key = md5($orderNo.'&'.$merchantOrderNo.'&'.$money.'&'.$payAmount.'&'.$this->payInfo['merchant_secret']);
        $this->res['flag'] = $md5_key == $sign;
        $this->res['callback_param'] = 'success';
        return $this->res;
    }
}