<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/4
 * Time: 13:49
 */
namespace App\Pay;

class XmPay extends BasePay
{
    public function dorechange($data=""){
        $res = $this->curl_post($this->payInfo['gateway_address'],$this->getPostData());
        $data = json_decode($res,true);
        if($data['resultCode'] == '00' && $this->getSign($data) == $data['sign']){
            if(isset($data['payUrl'])){
                return redirect($data['payUrl']);
            }
            return $this->except($data['resultDesc']);
        }
        return $this->except($data['resultDesc']);
    }
    protected function getPostData(){
        $data = [
            'messageid' => null,
            "out_trade_no" => $this->payInfo['orderNo'],
            "back_notify_url" => $this->payInfo['callback_url'],
            "front_notify_url" => $this->payInfo['redirect_url'],
            "branch_id" => $this->payInfo['merchant_code'],
            'prod_name' => 'jfcz',
            'prod_desc' => 'jfcz',
            'client_ip' => get_real_ip(),
            "pay_type" => null,
            "total_fee" => $this->payInfo['money']*100,
            "nonce_str" => str_random(16),
            'sign' => '',
        ];
        $data["sign"] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        unset($data['sign']);
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=""){
        $this->res['callback_param'] = 'SUCCESS';
        $this->res['flag'] = $data['resultCode'] == '00' && $data['resCode'] == '00' && $this->getSign($data) == $data['sign'];
        return $this->res;
    }
    protected function curl_post($url,$data){
        $data_string = json_encode($data);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_string))
        );
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}