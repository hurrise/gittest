<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/27 0027
 * Time: 19:27
 */

namespace App\Pay;


class Jumpwxh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'Merch_Id' => $this->payInfo['merchant_code'],
            'Version' => 'V1.0.0',
            'Char_Type' => 'UTF-8',
            'Sign_Type' => 'MD5',
            'Cryp_Type' => 'RSA',
            'Data' => $this->getData(),
        ];
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['Err_Code'] == 0){
            return redirect($res['Pay_Url']);
        }
        return isset($res['Err_Mes'])?$res['Err_Mes']:'第三方通道异常';
    }
    public function getData(){
        $data = [
            'Merch_Order' => $this->payInfo['orderNo'],
            'Subject' => 'jfcz',
            'Body' => null,
            'Total_Amount' => $this->payInfo['money']*100,
            'IP_Adr' => get_real_ip(),
            'Acc_Type' => 'D0',
            'Auth_Code' => null,
            'Notify_Url' => $this->payInfo['callback_url'],
            'Pay_Type' => 200002,
        ];
        $data['Sign'] = $this->getSign($data);
        $json = json_encode($data);
        $public_key = openssl_pkey_get_public($this->getPublicKey($this->payInfo['public_key'],64));
        $crypto = '';
        foreach (str_split($json, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $public_key);
            $crypto = $crypto . $encryptData;
        }
        return base64_encode($crypto);
    }

    public function getSign($data=""){
        foreach ($data as $k=>$v){
            if(is_null($data[$k])){
                unset($data[$k]);
            }
        }
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data = "")
    {
        $resData = base64_decode($data['Data']);
        $private_key = openssl_pkey_get_private($this->getPrivateKey($this->payInfo['private_key'],64));
        $info = openssl_pkey_get_details($private_key);
        $decry = '';
        foreach (str_split($resData,$info['bits'] / 8) as $chunk){
            openssl_private_decrypt($chunk,$decryData,$private_key);
            $decry = $decry . $decryData;
        }
        $finalData = json_decode($decry,true);
        $sign = $finalData['Sign'];
        unset($finalData['Sign']);
        if($sign == $this->getSign($finalData)){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}