<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/24 0024
 * Time: 13:37
 */

namespace App\Pay;


class Jyqqh5Pay extends BasePay
{
    private $dataStruct = [
        'p1_mchtid' => null,
        'p2_paytype' => null,
        'p3_paymoney' => null,
        'p4_orderno' => null,
        'p5_callbackurl' => null,
        'p6_notifyurl' => null,
        'p7_version' => null,
        'p8_signtype' => null,
        'p9_attach' => null,
        'p10_appname' => null,
        'p11_isshow' => null,
        'p12_orderip' => null,
        'p13_memberid' => null,
        'sign' => null,
    ];

    public function dorechange($data=""){

        $postData = $this->getPostData($this->payInfo);
        return $this->redirect($postData,'post');
        $res = $this->curlPost($postData,$this->config['rechange_url']);
        $res = json_decode($res,true);
        if($res['rspCode'] == 1){
            return redirect($res['data']['r6_qrcode']);
        }
        return $this->except($res['rspMsg']);
    }

    public function curlPost($aPostData, $sUrl, $respondType = 1, $timeout = 5) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $sUrl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($aPostData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, (int)$timeout);
        curl_setopt($ch, CURLOPT_USERAGENT,
            'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.47 Safari/536.11');// 添加浏览器内核信息，解决403问题 add by ben 2017/10/25
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
    public function getPostData($data = "")
    {
        $this->dataStruct['p1_mchtid'] = $this->payInfo['merchant_code'];
        $this->dataStruct['p2_paytype'] = 'QQPAYWAP';
        $this->dataStruct['p3_paymoney'] = $this->payInfo['money'];
        $this->dataStruct['p4_orderno'] = $this->payInfo['orderNo'];
        $this->dataStruct['p5_callbackurl'] = $this->payInfo['callback_url'];
        $this->dataStruct['p6_notifyurl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['p7_version'] = "v2.8";
        $this->dataStruct['p8_signtype'] = 1;
        $this->dataStruct['p9_attach'] = $this->payInfo['attach'];
        $this->dataStruct['p10_appname'] = null;
        $this->dataStruct['p11_isshow'] = 0;
        $this->dataStruct['p12_orderip'] = $this->get_real_ip();
        $this->dataStruct['p13_memberid'] = uniqid();
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    protected function getSign($data = ""){
        unset($data['sign']);
        unset($data['p13_memberid']);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr = trim($signStr,'&').$this->payInfo['merchant_secret'];
        $sign = md5($signStr);
        return $sign;
    }

    public function verify($data=""){
        $signStr = "partner={$data['partner']}&ordernumber={$data['ordernumber']}&orderstatus={$data['orderstatus']}&paymoney={$data['paymoney']}".$this->payInfo['merchant_secret'];
        $newsign = md5($signStr);
        if($newsign == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}