<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/2
 * Time: 20:26
 */

namespace App\Pay;


class WftPay extends BasePay
{
    protected $dataStruct = [
        'shop_id' => null,
        'user_id' => null,
        'money' => null,
        'type' => null,
        'sign' => null,
        'shop_no' => null,
        'notify_url' => null,
        'return_url' => null
    ];

    protected function getPostData(){
        $this->dataStruct['shop_id'] = $this->payInfo['merchant_code'];
        $this->dataStruct['user_id'] = 'jfcz';
        $this->dataStruct['money'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['type'] = null;
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        $this->dataStruct['shop_no'] = $this->payInfo['orderNo'];
        $this->dataStruct['notify_url'] = $this->payInfo['callback_url'];
        $this->dataStruct['return_url'] = $this->payInfo['redirect_url'];
        return $this->dataStruct;
    }

    protected function getSign($data){
        return strtolower(md5($data['shop_id'].$data['user_id'].$data['money'].$data['type'].$this->payInfo['merchant_secret']));
    }

    protected function postJson($url, $data_string) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url );
        curl_setopt($ch, CURLOPT_POST, 1 );
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // https请求 不验证证书和hosts
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string)
        ));
        $post_result = curl_exec($ch);
        if (curl_errno($ch)) {
            customWriteLog('curlError',curl_error($ch));
        }
        $result = json_decode($post_result,true);
        $result['status'] = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $result;
    }

    protected function payResponseVerify($data = []){
        if($data['status'] == '200'){
            $sign = $data['sign'];
            $sign_tmp = strtolower(md5($this->payInfo['merchant_code'].$data['user_id'].$data['order_no'].$this->payInfo['merchant_secret'].$data['type'].$data['money']));
            return $sign == $sign_tmp ? true : false;
        }
        return false;
    }

    public function verify($data = ''){
        $data = json_decode($data,true);
        $sign = strtolower(md5(
            $this->payInfo['merchant_code'] .
            $data['user_id'] .
            $data['order_no'] .
            $this->payInfo['merchant_secret'].
            $data['money'].
            $data['type']
        ));
        if($data['sign'] == $sign){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}