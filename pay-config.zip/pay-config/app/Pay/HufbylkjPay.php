<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-14
 * Time: 10:04
 */

namespace App\Pay;

class HufbylkjPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
           "version" => 'V1',   //版本号,
            "mer_no" => $this->payInfo['merchant_code'],
            "mer_order_no" => $this->payInfo['orderNo'],
            "ccy_no" => 'CNY',   //币种,
            "order_amount" => $this->payInfo['money']*100, //分为单位，整数
            "busi_code" => '100401',   //业务编码(WAP:100401,支付宝H5:100203),
            "goods" => 'hufbylkj',   //商品名称,
            "bg_url" => $this->payInfo['callback_url'],
            "page_url" => $this->payInfo['redirect_url'],
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['reserver'] = null;  //保留信息
        customWriteLog('HufbylkjPay','postdata  '.json_encode($data));
        return $data;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(md5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        customWriteLog('HufbylkjPay',json_encode($data));
        if($data['status']=="SUCCESS" && $this->getSign($data) == $data['sign']){
            customWriteLog('HufbylkjPay',"验签成功");
            $this->res['flag']=true;
        }else{
            customWriteLog('HufbylkjPay',"验签失败");
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}