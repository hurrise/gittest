<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/23 0023
 * Time: 17:59
 */

namespace App\Pay;


class Jxzfbh5Pay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'version' =>  'V1',
            'mer_no' => $this->payInfo['merchant_code'],
            'mer_order_no' => $this->payInfo['orderNo'],
            'ccy_no' => 'CNY',
            'order_amount' => $this->payInfo['money']*100,
            'busi_code' => '100203',
            'goods' => '积分',
            'reserver' => $this->payInfo['attach'],
            'bg_url' => $this->payInfo['callback_url'],
            'bankCode' => null,
            'page_url' => $this->payInfo['redirect_url'],
        ];
        $data['sign'] = $this->getSign($data);
        $res = $this->curl_post($this->payInfo['gateway_address'],json_encode($data));
        $res = json_decode($res,true);
        if($res['status'] == "SUCCESS"){
            return redirect($res['order_data']);
//            $ptn = '/^<html>(.*?)<\/html>$/';
//            preg_match($ptn,$res['order_data'],$match);
//            if(!empty($match)){
//                echo $res['order_data'];
//            }else {
//                $this->curlPayData['qrUrl'] = $res['order_data'];
//                $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
//                return $this->qrRedirect($this->curlPayData);
//            }
        }
        return $this->except($res['err_msg']);
    }
    public function getSign($data=""){
        foreach ($data as $k=>$v){
            if(empty($data[$k])){
                unset($data[$k]);
            }
        }
        ksort($data);
        $signStr = "";
        foreach ($data as $k=>$v){
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'key='.$this->payInfo['merchant_secret'];
//        dd($signStr);
        return md5($signStr);
    }
    public function verify($data = "")
    {
        foreach ($data as $k=>$v){
            $data[$k] = urldecode($v);
        }
        $old = $data['sign'];
        unset($data['sign']);
        $now = $this->getSign($data);
        if($old == $now){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}