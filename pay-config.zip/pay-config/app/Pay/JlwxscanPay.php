<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;

class JlwxscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            'payKey' => $this->payInfo['merchant_code'],
            'orderPrice' => $this->payInfo['money'],
            'payType' => 'WEIXIN',
            'bankCode' => null,
            'orderNo' => $this->payInfo['orderNo'],
            'orderTime' => date('YmdHis'),
            'productName' => 'jfcz',
            'orderExp' => 5,
            'ipAddress' => get_real_ip(),
            'returnType' => 'html',
            'returnUrl' => $this->payInfo['redirect_url'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'remark' => '',
            'sign' => ''
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        if(isset($data['bankCode'])){
            unset($data['bankCode']);
        }
        unset($data['sign']);
        unset($data['remark']);
        if(!isset($data['payKey'])){
            $data['payKey'] = $this->payInfo['merchant_code'];
        }
        ksort($data);
        $signStr = urldecode(http_build_query($data)).'&paySecret='.$this->payInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data=""){
        if($this->getSign($data) == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
}