<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/19 0019
 * Time: 13:52
 */

namespace App\Pay;


use phpDocumentor\Reflection\Types\Array_;

class CsfzfbscanPay extends BasePay
{
    private $dataStruct = [
        'parter' => null,
        'type' => null,
        'value' => null,
        'orderid' => null,
        'callbackurl' => null,
        'hrefbackurl' => null,
        'payerIp' => null,
        'attach' => null,
        'sign' => null,
    ];
    public function dorechange($data = ""){
        $postData = $this->getPostData($this->payInfo);
        return $this->redirect($postData);
    }
    private function redirect($data = ""){
        $url = $this->payInfo['gateway_address'];
        $htmlStr = '<form id="submit" name="submit" method="get" action="'.$url.'">';
        foreach($data as $key => $val){
            $htmlStr.="<input type='hidden' name='".$key."' value='".$val."'>";
        }
        $htmlStr.='<input type="submit" value=="提交" style="display:none;" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }
    private function getPostData($data = ""){
        $this->dataStruct['parter'] = $this->payInfo['merchant_code'];
        $this->dataStruct['type'] = $this->payInfo['extend1'];
        $this->dataStruct['value'] = sprintf('%0.2f',$this->payInfo['money']);
        $this->dataStruct['orderid'] = $this->payInfo['orderNo'];
        $this->dataStruct['callbackurl'] = $this->payInfo['callback_url'];
        $this->dataStruct['hrefbackurl'] = $this->payInfo['redirect_url'];
        $this->dataStruct['payerIp'] = $_SERVER['REMOTE_ADDR'];
        $this->dataStruct['attach'] = $this->payInfo['attach'];
        $this->dataStruct['sign'] = $this->getSign($this->dataStruct);
        return $this->dataStruct;
    }
    private function getSign($data=""){
        $signStr = "parter=%s&type=%s&value=%s&orderid=%s&callbackurl=%s%s";
        $signStr = sprintf($signStr,$data['parter'],$data['type'],$data['value'],$data['orderid'],$data['callbackurl'],$this->payInfo['merchant_secret']);
        $sign = md5($signStr);
        return $sign;
    }
    public function verify($data = ""){
        $signStr = "orderid=%s&opstate=%s&ovalue=%s%s";
        $signStr = sprintf($signStr,$data['orderid'],$data['opstate'],$data['ovalue'],$this->payInfo['merchant_secret']);
        $sign = md5($signStr);
        if($sign == $data['sign']){
            return true;
        }else{
            return false;
        }
    }
}