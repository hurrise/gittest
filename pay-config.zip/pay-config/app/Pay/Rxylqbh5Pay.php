<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/8/22 0022
 * Time: 19:06
 */

namespace App\Pay;


class Rxylqbh5Pay extends BasePay
{
    private $data = [
        'version' => null,
        'method' => null,
        'partner' => null,
        'banktype' => null,
        'paymoney' => null,
        'ordernumber' => null,
        'callbackurl' => null,
        'hrefbackurl' => null,
        'goodsname' => null,
        'attach' => null,
        'isshow' => null,
        'sign' => null,
    ];
    public function dorechange($data=""){
        $postData = $this->getPostData($this->payInfo);
        $shopData = [
            'method' => 'get',
            'postData' => json_encode($postData),
            'gateway_address' => $this->payInfo['gateway_address'],
        ];
        echo $this->shopRedirect($shopData);
    }
    protected function getPostData($data=""){
        $this->data['version'] = '3.0';
        $this->data['method'] = 'Rx.online.pay';
        $this->data['partner'] = $this->payInfo['merchant_code'];
        $this->data['banktype'] = 'UNIONPAYWAP';
        $this->data['paymoney'] = $this->payInfo['money'];
        $this->data['ordernumber'] = $this->payInfo['orderNo'];
        $this->data['callbackurl'] = $this->payInfo['callback_url'];
        $this->data['hrefbackurl'] = $this->payInfo['redirect_url'];
        $this->data['goodsname'] = '积分充值';
        $this->data['attach'] = 'renxin';
        $this->data['isshow'] = 1;
        $this->data['sign'] = $this->getSign($this->data);
        return $this->data;
    }
    protected function getSign($data=""){
        $signStr = "version=%s&method=%s&partner=%s&banktype=%s&paymoney=%s&ordernumber=%s&callbackurl=%s%s";
        $signStr = sprintf($signStr,$data['version'],$data['method'],$data['partner'],$data['banktype'],$data['paymoney'],$data['ordernumber'],$data['callbackurl'],$this->payInfo['merchant_secret']);
        $sign = md5($signStr);
        return $sign;
    }
    public function verify($data=""){
        $signStr = "partner=%s&ordernumber=%s&orderstatus=%s&paymoney=%s%s";
        $signStr = sprintf($signStr,$data['partner'],$data['ordernumber'],$data['orderstatus'],$data['paymoney'],$this->payInfo['merchant_secret']);
        if($data['sign'] == md5($signStr)){
            $this->res['flag']=true;
        }
        $this->res['callback_param'] = 'ok';
        return $this->res;
    }
}