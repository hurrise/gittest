<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/16 0016
 * Time: 17:25
 */

namespace App\Pay;


use Illuminate\Support\Facades\DB;

class BasePay implements Pay
{
    protected $payInfo = [
        'merchant_code' => null,
        'merchant_secret' => null,
        'public_key' => null,
        'private_key' => null,
        'bank' => null,
        'money' => null,
        'orderNo' => null,
        'callback_url' => null,
        'redirect_url' => null,
        'gateway_address' => null,
        'app_id' => null,
        'third_domain' => null,
        'attach' => null,
    ];
    protected $curlPayData = [
        'qrUrl' => null,
        'orderNo' => null,
    ];
    protected $res = [
        'callback_param' => 'success',
        'flag' => false,
    ];

    protected $shopData = [
        'method' => null,
        'postData' => null,
        'gateway_address' => null,
    ];
    function __construct($params="")
    {
        $payment = DB::table('payment')->where('id',$params->payment_id)->first();
        $this->payInfo['merchant_code'] = $payment->merchant_code;
        $this->payInfo['merchant_secret'] = $payment->merchant_secret;
        $this->payInfo['app_id'] = $payment->app_id;
        $this->payInfo['public_key'] = $payment->public_key;
        $this->payInfo['private_key'] = $payment->private_key;
        $this->payInfo['orderNo'] = $params->order_no;
        $this->payInfo['money'] = $params->money;
        $this->payInfo['bank'] = $params->bank;
        $this->payInfo['redirect_url'] = 'http://'.request()->getHost().'/success';
        if(env('IS_TEST')){ //如果是测试环境
            $this->payInfo['redirect_url'] = 'http://45.77.242.9:9999/success';
        }
        if(isset($payment->third_domain)){
            $this->payInfo['third_domain'] = $payment->third_domain;
            $this->payInfo['callback_url'] = trim($payment->callback_domain,'/').'/order/callback';
            if($payment->uname == 'hfbbank' || $payment->uname == 'hfbylkj'){
                $this->payInfo['callback_url'] = $payment->callback_url;
            }
        }else{
            $this->payInfo['callback_url'] = 'http://'.request()->getHost().'/order/'.$this->payInfo['orderNo'].'/callback';
            if(env('IS_TEST')){ //如果是测试环境
                $this->payInfo['callback_url'] = 'http://45.77.242.9:9999/order/'.$this->payInfo['orderNo'].'/callback';
            }
        }
        $this->payInfo['gateway_address'] = $payment->gateway;
        $this->payInfo['attach'] = $payment->uname;
        //todo
        customWriteLog('payInfo',$this->payInfo);
        //记日志
    }
    public function except($msg){
        return isset($msg)?$msg:'第三方通道异常';
    }
    public function dorechange($data = "")
    {
        // TODO: Implement dorechange() method.
    }

    public function verify($data = "")
    {
        // TODO: Implement verify() method.
    }

    protected function shopRedirect($data = "",$method="post"){
        $url = $this->payInfo['third_url'];
        if(empty($url)){
            dd('该支付需要配置第三方域名,如有疑惑请联系平台技术支持,感谢您的支持与谅解.');
        }
        $htmlStr = '<form id="submit" name="submit" method="'.$method.'" action="'.$url.'">';
        foreach($data as $key => $val){
            $htmlStr.="<input type='hidden' name='".$key."' value='".$val."'>";
        }
        $htmlStr.='<input type="submit" value="提交" style="display:none;" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }

    protected function redirect($data = "",$method="get"){
        $url = $this->payInfo['gateway_address'];
        $htmlStr = '<form id="submit" name="submit" method="'.$method.'" action="'.$url.'">';
        foreach($data as $key => $val){
            $htmlStr.="<input type='hidden' name='".$key."' value='".$val."'>";
        }
        $htmlStr.='<input type="submit" value="提交" style="display:none;" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }

    protected function qrRedirect($data = ""){
        $url = '/payto/message/apiqrpay';
        $htmlStr = '<form id="submit" name="submit" method="post" action="'.$url.'">';
        foreach($data as $key => $val){
            $htmlStr.="<input type='hidden' name='".$key."' value='".$val."'>";
        }
        $htmlStr.='<input type="submit" value="提交" style="display:none;" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo $htmlStr;
    }

    protected function getPublicKey($publicKey="",$splitLength = 64){
        $public_key = "-----BEGIN PUBLIC KEY-----\r\n";
        foreach (str_split($publicKey,$splitLength) as $str){
            $public_key .= $str . "\r\n";
        }
        $public_key .="-----END PUBLIC KEY-----";
        return $public_key;
    }
    protected function getPrivateKey($privateKey="",$splitLength = 64){
        $private_key = "-----BEGIN PRIVATE KEY-----\r\n";
        foreach (str_split($privateKey,$splitLength) as $str){
            $private_key .= $str . "\r\n";
        }
        $private_key .="-----END PRIVATE KEY-----";
        return $private_key;
    }

    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
//        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }

    protected function curl_get($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_HEADER,0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }

    protected function unsetNull($data){
        foreach ($data as $k => $v){
            if(is_null($v)){
                unset($data[$k]);
            }
        }
        return $data;
    }
    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unshift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
    public function myTrim($str=""){
        return str_replace("\r\n",'',str_replace("\n",'',$str));
    }

    protected function myLog($data,$attach = '',$dir = 'postData'){
        $attach or $attach = '调用于'.debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT,1)[0]['line'].'行';
        $path = storage_path('logs/'.trim($dir,'/').'.log');
        $handlers[] = ($monolog = Log::getMonolog())->popHandler();
        Log::useFiles($path);
        Log::info($attach);
        Log::info($data);
        $monolog->setHandlers($handlers);
    }
}