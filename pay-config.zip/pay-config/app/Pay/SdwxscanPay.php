<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-10-29
 * Time: 10:00
 */

namespace App\Pay;

class SdwxscanPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect_2($this->getPostData(),'get');
    }
    
    protected function getPostData(){
        $data = [
            "order_id" => $this->payInfo['orderNo'],
            "money" => sprintf('%0.2f',$this->payInfo['money']),
            "sdk" => $this->payInfo['merchant_code'],   //收款账号sdk
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['notify_url'] = $this->payInfo['callback_url'];
        $data['refer'] = $this->payInfo['redirect_url'];
        $data['Identification']= $this->payInfo['app_id'];;   //识别类型(固定)
        
        return $data;
    }
    
    protected function getSign($data = ""){
        $key = '';
        $money = $data['money'];
        if(isset($data['old_money'])){
            $money = sprintf('%0.2f',$data['old_money']) ;
            $key = $this->payInfo['merchant_secret'];
        }
        $Str =md5(md5($money.$data['order_id'].$data['sdk'].$key));
        return $Str;
    }
    
    public function verify($data=""){
        $this->res['callback_param'] = 'SUCCESS';
        $data = json_decode(array_keys($data)[0],true);
        $this->res['flag'] = $this->getSign($data) == $data['sign'];
        return $this->res;
    }

    protected function redirect_2($data = "",$method="get"){
        $url = $this->payInfo['gateway_address'];
        $htmlStr = '<form id="submit" name="submit" method="'.$method.'" action="'.$url.'" enctype="application/x-www-form-urlencode">';
        foreach($data as $key => $val){
            $htmlStr.="<input type='hidden' name='".$key."' value='".$val."'>";
        }
        $htmlStr.='<input type="submit" value=="提交" style="display:none;" />';
        $htmlStr.='</form>';
        $htmlStr.='<script>document.forms["submit"].submit();</script>';
        echo  $htmlStr;
    }
}