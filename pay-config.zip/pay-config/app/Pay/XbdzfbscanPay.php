<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/11 0011
 * Time: 22:09
 */

namespace App\Pay;


class XbdzfbscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'version' => '1.0',
            'customerid' => $this->payInfo['merchant_code'],
            'sdorderno' => $this->payInfo['orderNo'],
            'orderuser' => uniqid(),
            'total_fee' => $this->payInfo['money']*100,
            'paytype' => 'alipaywap',
            'bankcode' => null,
            'notifyurl' => $this->payInfo['callback_url'],
            'returnurl' => $this->payInfo['redirect_url'],
            'remark' => 'jfcz',
            'get_code' => 1,
        ];
        $signStr = "version={$data['version']}&customerid={$data['customerid']}&total_fee={$data['total_fee']}&sdorderno={$data['sdorderno']}&notifyurl={$data['notifyurl']}&returnurl={$data['returnurl']}&".$this->payInfo['merchant_secret'];
        $data['sign'] = md5($signStr);
        $res = $this->curl_post($this->payInfo['gateway_address'],$data);
        $res = json_decode($res,true);
        if($res['code'] == 1){
            $this->curlPayData['qrUrl'] = $res['url'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        return $this->except($res['msg']);
    }
    public function verify($data = "")
    {
        if($data['status'] == 1) {
            $sign = md5("customerid={$data['customerid']}&status={$data['status']}&sdpayno={$data['sdpayno']}&sdorderno={$data['sdorderno']}&total_fee={$data['total_fee']}&paytype={$data['paytype']}&" . $this->payInfo['merchant_secret']);
            if($sign == $data['sign']){
                $this->res['flag'] = true;
            }
        }
        return $this->res;
    }
}