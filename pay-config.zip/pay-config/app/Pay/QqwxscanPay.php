<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/13
 * Time: 14:37
 */

namespace App\Pay;

class QqwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'uid' => $this->payInfo['merchant_code'],
            'price' => sprintf('%0.2f', $this->payInfo['money']),
            'paytype' => 4,
            'notify_url' => $this->payInfo['callback_url'],
            'return_url' => $this->payInfo['redirect_url'],
            'user_order_no' => $this->payInfo['orderNo'],
            'sign' => 'jfcz',
        ];
        $data['sign'] = $this->getSign($data);
        myLog('postData', json_encode($data,JSON_UNESCAPED_SLASHES));
        $res = $this->curl_post($this->payInfo['gateway_address'], json_encode($data,JSON_UNESCAPED_SLASHES));
        myLog('postData', $res);
        $data = json_decode($res, true);
        myLog('postData', $data);
        if ($data['Code'] == 1) {
            return redirect($data['QRCodeLink']);
            $this->curlPayData['qrUrl'] = $data['data'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo @$data['Code'] . ($data['message'] ?? $data['errorMsg'] ?? '第三方通道异常');
    }

    protected function getSign($data = [])
    {
        unset($data['sign']);
        $signStr = join('',$data)  . $this->payInfo['merchant_secret'];
        myLog('postData', $signStr);
        return md5($signStr);
    }

    public function verify($data = '')
    {
        myLog('postData', $data);
        $this->res['flag'] = $this->getSign($data) == $data['sign'];
        return $this->res;
    }

    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}