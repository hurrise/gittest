<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-11-05
 * Time: 11:27
 */

namespace App\Pay;

class Jmwxh5Pay extends BasePay
{
    public function dorechange($data=""){
        $url = $this->curlget($this->payInfo['gateway_address'].'?'.$this->getPostData($data));
        $array = json_decode($url,true);
        if($array['retCode']=='SUCCESS'){
            $payParams=json_decode($array['payParams'],true);
            $this->curlPayData['qrUrl'] = $payParams['qrcode'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo $array['retMsg'];
    }
    
    protected function getPostData(){
        $data = [
            "amount" => sprintf('%d',$this->payInfo['money']*100),
            "mchId" => $this->payInfo['merchant_code'],
            "productId" => 8017,
            "mchOrderNo" => $this->payInfo['orderNo'],
            "subject" => '支付个人收款码',   //商品主题,
            "body" => '支付个人收款码',   //商品描述信息,
            "appId" => $this->payInfo['public_key'], //应用Id
            "notifyUrl" => $this->payInfo['callback_url'],
            "currency" => 'cny',   //币种,
        ];
        $data['sign'] = $this->getSign($data);
        /**其他不参与签名的参数*/
        $data['extra'] = "";  //附加参数
        $data['clientIp'] = "";  //客户端IP
        $data['device'] = "";  //设备
        $data['param1'] = "";  //扩展参数1
        $data['param2'] = "";  //扩展参数2

        $redata= ["params"=>json_encode($data)];
        $reStr = http_build_query($redata);
        return $reStr;
    }
    
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."key=".$this->payInfo['merchant_secret'];
        $Str =strtoupper(MD5($stringSignTemp));
        return $Str;
    }
    
    public function verify($data=""){
        $this->res['flag'] = $data['status'] === '2' && $this->getSign($data) == $data['sign'];
        $this->res['callback_param'] = 'success';
        return $this->res;
    }

    protected function curlget($url=""){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_TIMEOUT, 500);
        curl_setopt($curl, CURLOPT_URL, $url);
        $res = curl_exec($curl);
        curl_close($curl);

        return $res;
    }
}