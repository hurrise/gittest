<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-15
 * Time: 08:08
 */

namespace App\Pay;

class WfbankPay extends BasePay
{
    public function dorechange($data=""){
        try{
            return $this->redirect($this->getPostData(),'post');
        }catch (\Exception $exception){
            return $this->except();
        }
    }
    
    protected function getPostData(){
        $data = [
            "trxType" => 'OnlinePay',   //交易类型
            "r1_merchantNo" => $this->payInfo['merchant_code'],
            "r2_orderNumber" => $this->payInfo['orderNo'],
            "r3_amount" => sprintf('%0.2f',$this->payInfo['money']),
            "r4_bankId" => $this->payInfo['extend1'], //银行编码(若传值则表示直连网银，若为空则跳转网银网关页面)--目前不支持為空
            //icbc=ICBC-NET-B2C|cmb=CMBCHINA-NET-B2C|ccb=CCB-NET-B2C|boco=BOCO-NET-B2C|cib=CIB-NET-B2C|cmbc=CMBC-NET-B2C|ceb=CEB-NET-B2C|boc=BOC-NET-B2C|pingan=PINGANBANK-NET-B2C|ecitic=ECITIC-NET-B2C|sdb=SDB-NET-B2C|gdb=GDB-NET-B2C|shb=SHB-NET-B2C|spdb=SPDB-NET-B2C|hxb=HXB-NET-B2C|bccb=BCCB-NET-B2C|abc=ABC-NET-B2C|post=POST-NET-B2C|bjrcb=BJRCB-NET-B2C
            "r5_business" => 'B2C',   //对公对私标志
            "r6_timestamp" => null,//date('YmdHis'),   //时间戳
            "r7_goodsName" => null, //商品名称
            "r8_period" => null, //有效期
            "r9_periodUnit" => null, //有效期单位
            "r10_callbackUrl" => $this->payInfo['redirect_url'],
            "r11_serverCallbackUrl" => $this->payInfo['callback_url'],
            "r12_orderIp" => $this->get_real_ip(),   //发起方IP
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('WfbankPay','postdata  '.json_encode($data));
        return $data;
    }
    
    protected function getSign($data = "",$falg=false){
        $Str='#';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$v."#";
            }
        }
        if($falg){
            $stringSignTemp= $Str.$this->payInfo['public_key'];
        }else{
            $stringSignTemp= $Str.$this->payInfo['merchant_secret'];
        }
        $Str =md5($stringSignTemp);
        return $Str;
    }
    
    public function verify($data=""){
        customWriteLog('WfbankPay',json_encode($data));
        $signdata=[
            "trxType" => $data['trxType'],
            "retCode" => $data['retCode'],
            "retMsg" => isset($data['retMsg'])?$data['retMsg']:null,
            "r1_merchantNo" => $data['r1_merchantNo'],
            "r2_orderNumber" => $data['r2_orderNumber'],
            "r3_amount" => $data['r3_amount'],
            "r7_completeDate" => $data['r7_completeDate'],
            "r8_orderStatus" => $data['r8_orderStatus'],
        ];
        if($data['retCode']=="0000" && $data['r8_orderStatus']=="SUCCESS" && $this->getSign($signdata,true) == $data['sign']){
            customWriteLog('WfbankPay',"验签成功");
            $this->res['flag']=true;
        }else{
            customWriteLog('WfbankPay',"验签失败");
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    protected function get_real_ip() {
        $ip = false;
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
            if ($ip) {
                array_unift($ips, $ip);
                $ip = FALSE;
            }
            for ($i = 0; $i < count($ips); $i++) {
                if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                    $ip = $ips[$i];
                    break;
                }
            }
        }
        return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
    }
}