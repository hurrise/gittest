<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-02-01
 * Time: 10:51
 */

namespace App\Pay;

class GskhylscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'merchantNo' => $this->payInfo['merchant_code'],  //商户编号
            'orderPrice' => $this->payInfo['money'], //订单金额
            'outOrderNo' => $this->payInfo['orderNo'],  //商户支付订单号
            'tradeType' => 'yl_pay_t0', //交易类别--银联T0扫码支付
            'tradeTime' => date('YmdHis'),  //交易下单时间
            'goodsName' => 'Gskhylscan',  //商品名称
            'tradeIp' => $this->get_real_ip(),  //交易IP
            'returnUrl' => $this->payInfo['redirect_url'], //页面通知地址
            'notifyUrl' => $this->payInfo['callback_url'], //后台异步通知地址
            'remark' =>  'Gskhylscan' //备注
        ];
        $data['sign'] = $this->getSign($data);
        customWriteLog('GskhylkjPay','postdata '.json_encode($data));
        $getpost= $this->gskh_curl_post($this->payInfo['gateway_address'],$data);
        $getpostarray = json_decode($getpost,true);
        if($getpostarray['resultCode'] == "0000"){
            return redirect($getpostarray['payMsg']);
        }
        return $this->except($getpostarray['errMsg']);
    }
    protected function getSign($data = ""){
        ksort($data);
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="sign"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$k."=".$v."&";
            }
        }
        $stringSignTemp= $Str."secretKey=".$this->payInfo['merchant_secret'];
        customWriteLog('GskhylkjPay','$stringSignTemp '.$stringSignTemp);
        $Str =strtoupper(MD5($stringSignTemp));
        return $Str;
    }

    public function verify($data = "")
    {
        if($data['tradeStatus'] == 'SUCCESS' && $this->getSign($data) == $data['sign']){
            return $this->res;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }

    protected function gskh_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded",
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}