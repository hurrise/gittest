<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2018/11/8
 * Time: 21:31
 */
namespace App\Pay;

class HbzfbscanPay extends HbPay
{
    protected function getPostData(){
        $data = [
            'pay_memberid' => $this->payInfo['merchant_code'],
            'pay_orderid' => $this->payInfo['orderNo'],
            'pay_amount' => sprintf('%0.2f',$this->payInfo['money']),
            'pay_applydate' => date("Y-m-d H:i:s"),
            'pay_bankcode' => 903,
            'pay_notifyurl' => $this->payInfo['callback_url'],
            'pay_callbackurl' => $this->payInfo['redirect_url'],
        ];
        $data['pay_md5sign'] = $this->getSign($data);
        $data['pay_attach'] = 'jfcz';
        $data['pay_productname'] = 'jfcz';
        return $data;
    }
}