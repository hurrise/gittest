<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/10/7
 * Time: 15:27
 */

namespace App\Pay;


class WfbkjpcPay extends BasePay
{
    public function dorechange($data=""){
        return $this->redirect($this->getPostData(),'post');
    }
    protected function getPostData(){
        $data = [
            'payKey' => $this->payInfo['merchant_code'],
            'orderPrice' => sprintf('%0.2f',$this->payInfo['money']),
            'outTradeNo' => $this->payInfo['orderNo'],
            'productType' => '40000303',
            'orderTime' => date('YmdHis'),
            'payBankAccountNo' => '123456789',
            'productName' => 'jfcz',
            'orderIp' => get_real_ip(),
            'returnUrl' => $this->payInfo['redirect_url'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'remark' => '',
            'sign' => ''
        ];
        $data['sign'] = $this->getSign($data);
        return $data;
    }
    protected function getSign($data=[]){
        unset($data['sign']);
        ksort($data);
        $signStr = '';
        foreach($data as $k => $v) {
            if($v != '') {
                $signStr .= $k . "=" . $v . "&";
            }
        }
        $signStr .= 'paySecret='.$this->payInfo['merchant_secret'];
        $sign = strtoupper(md5($signStr));
        return $sign;
    }
    public function verify($data=""){
        $sign = $this->getSign($data);
        if($sign == $data['sign']){
            $this->res['flag'] = true;
        }
        $this->res['callback_param'] = 'SUCCESS';
        return $this->res;
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
}