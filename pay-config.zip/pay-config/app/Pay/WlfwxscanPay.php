<?php
/**
 * Created by PhpStorm.
 * User: DongNi
 * Date: 2019/1/18
 * Time: 16:38
 */

namespace App\Pay;

class WlfwxscanPay extends BasePay
{
    public function dorechange($data = "")
    {
        $data = [
            'txnType' => '01',
            'txnSubType' => '31',
            'secpVer' => 'icp3-1.1',
            'secpMode' => 'perm',
            'macKeyId' => $this->payInfo['merchant_code'],
            'orderDate' => date('Ymd'),
            'orderTime' => date('His'),
            'merId' => $this->payInfo['merchant_code'],
            'productTitle' => 'jfcz',
            'orderId' => $this->payInfo['orderNo'],
            'txnAmt' => (string)($this->payInfo['money']*100),
            'currencyCode' => '156',
            'timeStamp' => date('YmdHis'),
            'notifyUrl' => $this->payInfo['callback_url'],
            'pageReturnUrl' => $this->payInfo['redirect_url'],
            'mac' => 'jfcz',
        ];
        $data['mac'] = $this->getSign($data);
        $data = json_decode($this->curl_post($this->payInfo['gateway_address'],http_build_query($data)),true);
        if(@$data['respCode'] == '0000'){
            $this->curlPayData['qrUrl'] = $data['codeImgUrl'];
            $this->curlPayData['orderNo'] = $this->payInfo['orderNo'];
            return $this->qrRedirect($this->curlPayData);
        }
        echo @$data['respCode'].($data['txnStatusDesc']??$data['respMsg']??'第三方通道异常');
    }

    protected function getSign($data = [])
    {
        unset($data['mac']);
        ksort($data);
        $signStr = '';
        foreach ($data as $k => $v) {
            $signStr .= $k.'='.$v.'&';
        }
        $signStr .= 'k=' . $this->payInfo['merchant_secret'];
        return md5($signStr);
    }

    public function verify($data = '')
    {
        $this->res['flag'] = $data['txnStatus'] == '10' && $this->getSign($data) == $data['mac'];
        return $this->res;
    }
}