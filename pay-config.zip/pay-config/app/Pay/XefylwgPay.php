<?php

namespace App\Pay;

class XefylwgPay extends BasePay {
    public function dorechange($data = '') {
        return $this->redirect($this->getData(),'post');
    }
    protected function getData() {
        $post = [
            'bankCode' => $this->payInfo['bank'], //支付方式 支付宝：alipay QQ钱包：qqpay  百度钱包：bdpay   微信：weixin
            'cardType' => '01',
            'clientType' => '2',
            'commodityDesc' => 'jfcz',
            'commodityName' => 'jfcz',
            'merchId' => $this->payInfo['merchant_code'],
            'notifyUrl' => $this->payInfo['callback_url'],
            'orderNo' => $this->payInfo['orderNo'], //订单号
            'returnUrl' => $this->payInfo['redirect_url'],
            'transAmt' => $this->payInfo['money'] * 100, //金额 按分为单位。 100实际为1元
        ];
        $post['sign'] = $this->getSign($post);
        $model = [//定义一个是数组用于POST
            'merchId' => $this->payInfo['merchant_code'],
            'encryptType' => 'md5',
            'msgId' => $this->payInfo['orderNo'],
            'cipherData' => base64_encode(json_encode($post)),
            'reqTime' => date("YmdHis"),
            'accountNo' => 'jfcz',
        ];
        return $model;
    }
    protected function getSign($param) {
        return md5(
            md5(
                urldecode(http_build_query($param)).
                "&key=" . $this->payInfo['merchant_secret']
            )
            ."&key=" . $this->payInfo['merchant_secret']
        );
    }
    public function verify($data = "") {
        $msgdata = $data["cipherData"]; //接收字符串
        $data1 = base64_decode($msgdata,true);
        $arr=(array)json_decode($data1);
        $mData="merchId=".$arr['merchId']."&orderNo=".$arr['orderNo']."&origRespCode=".$arr['origRespCode']."&origRespDesc=".$arr['origRespDesc']."&spbillno=".$arr['spbillno']."&transAmt=".$arr['transAmt']."&key=".$this->payInfo['merchant_secret'];
        $mData=iconv('utf-8','gbk',$mData);
        $md5data=md5(md5($mData)."&key=".$this->payInfo['merchant_secret']);
        if ($md5data == $arr["sign"]) { //校验是否是你提交的数据
            $this->res['flag']=true;
        }
        $this->res['callback_param']="000000";
        return $this->res;
    }
}