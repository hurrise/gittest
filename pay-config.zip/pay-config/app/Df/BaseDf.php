<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/18 0018
 * Time: 16:46
 */

namespace App\Df;


use Illuminate\Support\Facades\DB;

class BaseDf
{
    protected $dfInfo = [
        'merchant_code' => null,
        'merchant_secret' => null,
        'public_key' => null,
        'private_key' => null,
        'app_id' => null,
        'order_no' => null,
        'money' => null,
        'callback_url' => null,
        'bank' => null,
        'gateway_address' => null,
        'third_url' => null,
        'member_name' => null,
        'member_card' => null,
    ];
    public function __construct($params="")
    {
        $payment = DB::table('payment')->where('id',$params->payment_id)->first();
        $this->dfInfo['merchant_code'] = $payment->merchant_code;
        $this->dfInfo['merchant_secret'] = $payment->merchant_secret;
        $this->dfInfo['public_key'] = $payment->public_key;
        $this->dfInfo['private_key'] = $payment->private_key;
        $this->dfInfo['app_id'] = $payment->app_id;
        $this->dfInfo['order_no'] = $params->order_no;
        $this->dfInfo['money'] = $params->money;
        $this->dfInfo['callback_url'] = 'http://'.request()->getHost() . '/' . 'order/' . $params->order_no . '/dfCallback';
        if(env('IS_TEST')){ //如果是测试环境
            $this->dfInfo['callback_url'] = 'http://45.77.242.9:9999/order/'.$params->order_no.'/dfCallback';
        }
        $this->dfInfo['bank'] = $params->bank;
        $this->dfInfo['gateway_address'] = $payment->gateway;
        $this->dfInfo['third_url'] = $payment->third_domain;
        $this->dfInfo['member_name'] = $params->person;
        $this->dfInfo['member_card'] = $params->card;
        customWriteLog('dfInfo',$this->dfInfo);
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
//        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
    protected $res = [
        'callback_param' => 'success',
        'flag' => false,
    ];
    public function dorechange($data = "")
    {
        // TODO: Implement dorechange() method.
    }

    public function verify($data = "")
    {
        // TODO: Implement verify() method.
    }

    public function toNotice($flag='SUCCESS',$data=[]){
        customWriteLog('df_return_data',$data);
        $arr = [
            'errorCode' => $flag,
            'msg' => $flag == 'SUCCESS'? '第三方代付请求成功' : '第三方代付请求失败',
            'data' => $data,
        ];
        return $arr;
    }
}