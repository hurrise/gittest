<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/18 0018
 * Time: 12:31
 */

namespace App\Df;


use App\Service\RsaService;

class BsdfDf extends BaseDf
{
    public function dorechange($data = "")
    {
        $data = [
            'payKey' => $this->dfInfo['app_id'],
            'cardNo' => $this->dfInfo['member_card'],
            'cardName' => $this->dfInfo['member_name'],
            'noticeUrl' => $this->dfInfo['callback_url'],
            'orderNo' => $this->dfInfo['order_no'],
            'tranTime' => date('YmdHis'),
            'tranAmt' => str_pad('',12-strlen($this->dfInfo['money']*100),0).$this->dfInfo['money']*100,
        ];
        $postData = [
            'merId' => md5($this->dfInfo['merchant_code']),
            'encryptData' => (new RsaService())->setPublicKey($this->dfInfo['public_key'])->publicKeyToEncrypt($data)->getEncryptData(),
            'signData' => $this->getSign($data),
        ];
        $res = $this->curl_post($this->dfInfo['gateway_address'],$postData);
//        customWriteLog('bs',['data'=>$data,'postData'=>$postData,'res'=>$res,'dfInfo'=>$this->dfInfo]);
//        $res = json_decode($res,true);


//        customWriteLog('bs',['data'=>$data,'postData'=>$postData,'res'=>$res,'dfInfo'=>$this->dfInfo]);
        $res = (new RsaService())->setPrivateKey($this->dfInfo['private_key'])->privateKeyToDecrypt($res)->getDecryptData();
//        customWriteLog('bs',['data'=>$data,'postData'=>$postData,'res'=>$res,'dfInfo'=>$this->dfInfo]);
        if($res['respCode'] == '0000'){
            return $this->toNotice();
        }
        return $this->toNotice('ERROR');
    }
    protected function curl_post($url,$data){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Content-type:application/json;charset=utf-8;cache-control:no-cache'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            return curl_error($ch);
        }
        curl_close($ch);
        return $result;
    }
    protected function la_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(
                "accept: */*",
                "content-type: application/json; charset=utf-8"
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
    protected function getSign($data = ""){
        ksort($data);
        $signStr = '';
        foreach ($data as $k=>$v){
            $signStr .= $k . '=' . $v . '&';
        }
        $signStr .= 'paySecret=' . $this->dfInfo['merchant_secret'];
        return strtoupper(md5($signStr));
    }
    public function verify($data = "")
    {
        $rsa = new RsaService();
        $decData = $rsa->setPrivateKey($this->dfInfo['private_key'])->privateKeyToDecrypt($data['transData'])->getDecryptData();
//        customWriteLog('cbs',['decData'=>$decData,'data'=>$data]);
        if($decData['respCode'] == '0000' && $decData['resultFlag'] == 0){
            $this->res['flag'] = true;
            $this->res['callback_param'] = 0;
        }
        return $this->res;
    }
}