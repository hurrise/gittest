<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/18 0018
 * Time: 16:46
 */

namespace App\Df;


interface Df
{
    public function dorechange($data="");
    public function verify($data="");
}