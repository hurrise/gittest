<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/10 0010
 * Time: 14:16
 */

namespace App\Df;


class XcfdfDf extends BaseDf
{
    public function dorechange($data = "")
    {
        $staticdata = array(
            'app_id' => $this->dfInfo['merchant_code'],
            'app_secret' => $this->dfInfo['merchant_secret'],
            'timestamp' => time(),
        );
        $data = [
            'bank_name' => $this->dfInfo['member_name'],
            'bank_card' => $this->dfInfo['member_card'],
            'money' => sprintf('%0.2f',$this->dfInfo['money']),
            'order_num' => $this->dfInfo['order_no'],
            'notice_url' => $this->dfInfo['callback_url'],
        ];
        $data = array_merge($staticdata, $data);
        $data['signature'] = $this->sign($data);
        $ret = $this->send($this->dfInfo['gateway_address'], $data);
        $res = json_decode($ret, true);
        if($res['code'] == 0){
            return $this->toNotice('SUCCESS');
        }
        return $this->toNotice('ERROR');
    }
    //签名
    protected function sign($data)
    {
        $getdata = $data;
        if (isset($getdata['signature'])) {
            unset($getdata['signature']);
        }

        $signstr = $this->joinMapValue($getdata);
        $signature = $this->MakeSign($signstr);
        return $signature;
    }
    //生成签名
    protected function MakeSign($data)
    {
        $signature = strtoupper(md5(sha1($data)));

        return $signature;
    }

    //序列化
    protected function joinMapValue($sign_params)
    {
        ksort($sign_params);
        $sign_str = "";
        foreach ($sign_params as $key => $val) {
            $sign_str .= sprintf("%s=%s&", $key, $val);
        }
        return substr($sign_str, 0, -1);
    }

    //发送请求
    protected function send($url, $post_data, $method = 'POST')
    {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => $method, //or GET
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url . ($method == 'POST' ? '' : '?' . $postdata), false, $context);
        $result = trim($result,chr(239).chr(187).chr(191));
        return $result;
    }
    public function verify($data = "")
    {
        if($data['code'] == 0 && $data['data']['state'] == 4){
            $this->res['flag'] = true;
        }
        return $this->res;
    }
}
