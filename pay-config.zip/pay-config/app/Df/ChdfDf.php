<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019-01-22
 * Time: 11:44
 * 北哥表示目前用不到畅汇的代付
 * 这个代付对接提交是成功的
 * 但验签的部份还没有回调可以验证
 */

namespace App\Df;

class ChdfDf extends BaseDf
{
    public function dorechange($data = ""){
        $url = $this->chdf_curl_post($this->dfInfo['gateway_address'],$this->getPostData($data));
        customWriteLog('ChdfDf','回传讯息: '.$url);
        $urlarray = json_decode($url,true);
        if($urlarray['r1_Code'] == "0000"){
            return $this->toNotice('SUCCESS');
        }
        return $this->toNotice('ERROR'.$urlarray['r7_Desc']);
    }

    protected function getPostData($postdata=""){
        $data = [
            "p0_Cmd" => 'TransPay',   //业务类型,
            "p1_MerId" => $this->dfInfo['merchant_code'],
            "p2_Order" => $this->dfInfo['order_no'],
            "p3_CardNo" =>  $this->dfInfo['member_card'],   //卡号,
            "p4_BankName" => $this->dfInfo['bank'],   //银行名称,
            "p5_AtName" =>  $this->dfInfo['member_name'],   //账户名,
            "p6_Amt" => sprintf('%0.2f', $this->dfInfo['money']),
            "pb_CusUserId" => "",   //商户用户 id
            "pc_NewType" => 'PRIVATE',   //代付类型,
            "pd_BranchBankName" => "",   //支行名称,
            "pe_Province" => "",   //开户行所在省,
            "pf_City" => "",   //开户行所在市,
            "pg_Url" => $this->dfInfo['callback_url'],   //回调
        ];
        $data['hmac'] = $this->getSign($data);
        customWriteLog('ChdfDf','json  '.json_encode($data));
        return $data;
    }

    protected function getSign($data = ""){
        $Str='';
        foreach ($data as $k=>$v){
            if($k=="hmac"){
                continue;
            }if($v==""){
                continue;
            }else{
                $Str.=$v;
            }
        }
        $Sign = $this->HmacMd5($Str,$this->dfInfo['merchant_secret']);
        customWriteLog('ChdfDf','HmacMd5前  '.$Str);
        return $Sign;
    }

    public function verify($data = ""){
        customWriteLog('ChdfDf','callbackdata  '.json_encode($data));
        $signdata=[
            "p1_MerId" => $data['p1_MerId'],
            "r0_Cmd" => $data['r0_Cmd'],
            "r1_Code" => $data['r1_Code'],
            "r2_TrxId" => $data['r2_TrxId'],
            "r3_Amt" => $data['r3_Amt'],
            "r4_Cur" => $data['r4_Cur'],
            "r5_Pid" => $data['r5_Pid'],
            "r6_Order" => $data['r6_Order'],
            "r8_MP" => $data['r8_MP'],
            "r9_BType" => $data['r9_BType'],
            "ro_BankOrderId" => $data['ro_BankOrderId'],
            "rp_PayDate" => $data['rp_PayDate'],
        ];
        if($data['r1_Code']=="1" && $this->getSign($signdata) == $data['hmac']){
            customWriteLog('ChdfDf','验签成功');
            $this->res['flag'] = true;
        }else{
            customWriteLog('ChdfDf','验签失败');
        }
        return $this->res;
    }

    protected function HmacMd5($data,$key)
    {
        $key = iconv("GB2312","UTF-8",$key);
        $encode = mb_detect_encoding($data,array("ASCII","GB2312","GBK",'BIG5','UTF-8'));
        $data = iconv($encode, "UTF-8",$data);
        customWriteLog('ChdfDf','HmacMd5编译后的data  '.$data);
        $b = 64; // byte length for md5
        if (strlen($key) > $b) {
            $key = pack("H*",md5($key));
        }
        $key = str_pad($key, $b, chr(0x00));
        $ipad = str_pad('', $b, chr(0x36));
        $opad = str_pad('', $b, chr(0x5c));
        $k_ipad = $key ^ $ipad ;
        $k_opad = $key ^ $opad;
        return md5($k_opad . pack("H*",md5($k_ipad . $data)));
    }

    protected function chdf_curl_post($url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => urldecode(http_build_query($data)),
            CURLOPT_HTTPHEADER => array(),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            return "cURL Error #:" . $err;
        } else {
            return $response;
        }
    }
}