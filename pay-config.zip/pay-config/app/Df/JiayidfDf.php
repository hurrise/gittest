<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/18 0018
 * Time: 16:45
 */

namespace App\Df;


class JiayidfDf extends BaseDf
{

}