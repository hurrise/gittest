<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 19:13
 */

namespace App\Service;


class ConstMapService
{
    public $superAuth = 2;
    public $normalAuth = 1;
    public $avatar = '/admin/images/avatar.jpg';
    public $forumDomain = 'http://103.100.60.133:8666';

    public $normalStatus = 1; //正常的状态
    public $disableStatus = 0; //禁用的状态

    public $pageNum = 10; //每页的数量

    public $salt = 'secret'; //用户的盐
    public $auth = [
        1 => '普通会员',
        2 => '管理员',
    ];

    public $giftTag = [
        'popular' => '紧俏',
        'new' => '新进',
        'vip' => 'VIP专享',
    ];

    public $topicsType_pt = 0;
    public $topicsType_zd = 9;
    public $topicsType_jh = 1;
    public $topicsType_gg = 2;
    public $topicsType_rt = 3;
    public $topicsType_zztj = 4;

    public function topicsType()
    {
        return [
            $this->topicsType_pt => '普通',
            $this->topicsType_zd => '置顶',
            $this->topicsType_jh => '精华',
            $this->topicsType_gg => '公告',
            $this->topicsType_rt => '热帖',
            $this->topicsType_zztj => '站长推荐',
        ];
    }
    public $source = ['signIn'=>'签到','signCycleBonus'=>'连签期满','topicPost' => '发帖','topicReply' => '回帖','topicFavour' => '赞帖'];
    public $userAct = [
        'all' => '全部会员',
        'today' => '今天活跃的会员',
        'week' => '最近七天活跃的会员',
        'month' => '最近一个月活跃的会员',
        'half_year' => '最近半年活跃的会员',
    ];
    public $voteRadio = 1;
    public $voteMultiple = 2;

    public $content = [
        'hzlz', 'hzxx'
    ];

    public $topicsCacheKey = 'topicsKey';
    public $commentsCacheKey = 'commentsKey';
    public $navCacheKey = 'navKey';
    public $contentCacheKey = 'contentKey';
    public $voteCacheKey = 'voteKey';
    public $contentDetailCacheKay = 'contentDetailKey';
    public $voteDetailCacheKay = 'voteDetailKey';
    public $topicsDetailCacheKay = 'topicsDetailKey';
    public $topicsFavourCacheKey = 'topicsFavourKey';
    public $giftCacheKey = 'giftCacheKey';
}