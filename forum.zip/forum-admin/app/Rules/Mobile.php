<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class Mobile implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        //
        if (strlen($value) == "11") {
            $n = preg_match_all("/13[123456789]{1}\\d{8}|15[123456789]\\d{8}|18[123456789]\\d{8}|17[123456789]\\d{8}|188\\d{8}/", $value, $array);
            if(!empty($array[0])){
                return true;
            }else{
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return '手机号不符合规则';
    }
}
