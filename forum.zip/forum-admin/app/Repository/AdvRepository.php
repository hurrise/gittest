<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/5 0005
 * Time: 12:48
 */

namespace App\Repository;


use App\Service\FactoryService;
use Carbon\Carbon;

class AdvRepository extends BaseRepository
{
    public function send($request=""){
        $data = $request->all();
        $users = $this->getUsers($data);
        $smsService = FactoryService::generateService('Sms');
        foreach ($users as $k=>$v){
            $smsService->send($v->mobile,$data['content']);
        }
        return ajaxReturn(200,'发放成功');
    }
    private function getUsers($data=""){
        $user = $this->getOtherModel('user');
        switch ($data['range']){
            case 'all':
                $users = $user->where('auth','<>',$this->const->superAuth)->get();
                break;
            case 'today':
                $users = $user->where('last_login_time','>=',Carbon::today())->where('auth','<>',$this->const->superAuth)->get();
                break;
            case 'week':
                $users = $user->where('last_login_time','>=',Carbon::now()->subDays(7))->where('auth','<>',$this->const->superAuth)->get();
                break;
            case 'month':
                $users = $user->where('last_login_time','>=',Carbon::now()->subDays(30))->where('auth','<>',$this->const->superAuth)->get();
                break;
            case 'half_year':
                $users = $user->where('last_login_time','>=',Carbon::now()->subDays(180))->where('auth','<>',$this->const->superAuth)->get();
                break;
            default:
                $users = $user->where('auth','<>',$this->const->superAuth)->get();
                break;
        }
        return $users;
    }
}