<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/17 0010
 * Time: 18:48
 */

namespace App\Repository;


class GiftRepository extends BaseRepository
{
    public function add($request=""){
        if($this->model->checkFieldRepeat('name',$request->all()['name'])){
            return ajaxReturn(400,'礼品名已存在');
        }
        return parent::add($request);
    }
    public function edit($request="",$id=""){
        if($this->getDataById($id)->name != $request->all()['name'] && $this->model->checkFieldRepeat('name',$request->all()['name'])){
            return ajaxReturn(400,'礼品名已存在');
        }
        return parent::edit($request,$id);
    }
}