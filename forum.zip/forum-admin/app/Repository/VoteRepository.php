<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 11:58
 */

namespace App\Repository;



class VoteRepository extends BaseRepository
{
    public function add($request=""){
        $data = $request->all();
        if($data['start_time'] >= $data['end_time']){
            return ajaxReturn(400,'开始时间必须小于结束时间');
        }
        if($data['end_time'] <= date('Y-m-d H:i:s')){
            return ajaxReturn(400,'结束时间必须大于当前时间');
        }
        return parent::add($request);
    }
    public function edit($request="",$id=""){
        $data = $request->all();
        if($data['start_time'] >= $data['end_time']){
            return ajaxReturn(400,'开始时间必须小于结束时间');
        }
        return parent::edit($request,$id);
    }

    public function list($request)
    {
        return $this->model->list($request);
    }
}