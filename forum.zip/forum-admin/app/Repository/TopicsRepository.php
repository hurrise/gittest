<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/12 0012
 * Time: 14:36
 */

namespace App\Repository;


class TopicsRepository extends BaseRepository
{
    public function batchdel($id='')
    {
        return $this->model->batchdel($id);
    }
}