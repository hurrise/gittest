<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/11 0011
 * Time: 19:47
 */

namespace App\Repository;


class LoginRepository extends BaseRepository
{
    public function login($request=""){
        $data = $request->all();
        $model = $this->getOtherModel('User');
        if(strtoupper($data['captcha']) != strtoupper(session('captcha'))){
            return ajaxReturn(400,'验证码错误');
        }
        if(empty($user = $model->where('username',$data['username'])->orWhere('mobile',$data['username'])->first())){
            return ajaxReturn(400,'用户名或密码错误');
        }
        if($user->auth != $this->const->superAuth){
            return ajaxReturn(400,'您无权限访问');
        }
        if($user->status != $this->const->normalStatus){
            return ajaxReturn(400,'该用户已停用');
        }
        if($user->password != toEncrypt($data['password'],$this->const->salt)){
            return ajaxReturn(400,'用户名或密码错误');
        }
        $user->login_ip = get_real_ip();
        $user->last_login_time = date('Y-m-d H:i:s');
        $user->save();
        session(['user'=>$user]);
        return ajaxReturn(200, '登录成功');
    }

}