<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 15:43
 */

namespace App\Repository;


class UserRepository extends BaseRepository
{
    public function add($request=""){
        if($this->model->checkFieldRepeat('username',$request->all()['username'])){
            return ajaxReturn(400,'用户名已存在');
        }
        if($this->model->checkFieldRepeat('mobile',$request->all()['mobile'])){
            return ajaxReturn(400,'该手机号已经注册过了');
        }
        return parent::add($request);
    }
    public function edit($request="",$id=""){
        if($this->getDataById($id)->username != $request->all()['username'] && $this->model->checkFieldRepeat('username',$request->all()['username'])){
            return ajaxReturn(400,'用户名已存在');
        }
        return parent::edit($request,$id);
    }
    public function changePassword($request="",$id=""){
        if($this->getDataById($id)->password != toEncrypt($request->all()['oldPassword'],$this->const->salt)) {
            return ajaxReturn(400, '原密码不正确');
        }
        return $this->model->changeField('password',toEncrypt($request->all()['password'],$this->const->salt),$id);
    }

    public function focus($request)
    {
        return $this->model->focus($request);
    }
    public function reply($request)
    {
        return $this->model->reply($request);
    }

    public function friends($request='')
    {
        return $this->model->friends($request);
    }

    public function friend($request='',$id=0)
    {
        return $this->model->friend($request,$id);
    }

    public function focu($request='',$id=0)
    {
        return $this->model->focu($request,$id);
    }
}