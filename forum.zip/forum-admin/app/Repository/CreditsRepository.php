<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/12 0012
 * Time: 14:36
 */

namespace App\Repository;


class CreditsRepository extends BaseRepository
{
    public function index($request=''){
        return $this->model->index($request);
    }
}