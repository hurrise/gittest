<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 15:39
 */

namespace App\Repository;


use App\Service\FactoryService;

class BaseRepository
{
    protected $model;
    protected $const;
    public  function __construct($modelName=""){$this->model = FactoryService::generateModel($modelName);$this->const = FactoryService::generateService('ConstMap');}
    public function index($request=""){return $this->model->index($request);}
    public function add($request=""){return $this->model->add($request);}
    public function edit($request="",$id=""){return $this->model->edit($request,$id);}
    public function del($id=""){return $this->model->del($id);}
    public function getDataById($id){return $this->model->getDataById($id);}
    public function status($id,$status){return $this->model->status($id,$status);}
    public function getOtherModel($modelName=""){return FactoryService::generateModel($modelName);}
    public function order($request=""){return $this->model->order($request);}
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
}