<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 15:39
 */

namespace App\Repository;


class RedeemRepository extends BaseRepository
{
    public function index($request='')
    {
        return $this->model->index($request);
    }

    public function deal($id=[])
    {
        return $this->model->deal($id);
    }
}