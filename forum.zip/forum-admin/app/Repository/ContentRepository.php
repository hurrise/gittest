<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 15:35
 */

namespace App\Repository;


class ContentRepository extends BaseRepository
{
    public function batchdel($id='')
    {
        return $this->model->batchdel($id);
    }
}