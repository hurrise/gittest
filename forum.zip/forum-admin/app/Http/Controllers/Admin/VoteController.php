<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Vote\VoteAddValidate;
use App\Http\Requests\Vote\VoteEditValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class VoteController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('request','data'));
    }

    public function add(VoteAddValidate $request){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('const'));
    }
    public function edit(VoteEditValidate $request,$id){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('const','data'));
    }

    public function list(Request $request)
    {
        $data = $this->repo->list($request);
        return view($this->view,compact('data','request'));
    }

    public function result(Request $request,$id)
    {
        if($request->isMethod('post')){
            $input = json_encode($request->except('_token'));
            if(DB::update("UPDATE `forum_vote_result` SET `result` = :input WHERE `id` = :id",[':input'=>$input,':id'=>$id])){
                return ajaxReturn(200,'修改成功');
            }
            return ajaxReturn(400,'修改失败');
        }
        $data = DB::select("SELECT `result`,`vote_id`,`options` FROM `forum_vote_result`,`forum_vote` WHERE `vote_id`=$id AND `vote_id`=`forum_vote`.`id`")[0];
        $id = $data->vote_id;
        $options = json_decode($data->options,true);
        $data = json_decode($data->result,true);
        foreach ($options as $option) {
            if(!isset($data[$option])){
                $data[$option] = 0;
            }
        }
        return view($this->view,compact('data','id'));
    }
}
