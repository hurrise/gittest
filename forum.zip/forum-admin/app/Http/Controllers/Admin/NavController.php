<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Nav\NavAddValidate;
use App\Http\Requests\Nav\NavEditValidate;
use Illuminate\Http\Request;

class NavController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('request','data'));
    }

    public function add(NavAddValidate $request){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('const'));
    }

    public function edit(NavEditValidate $request,$id){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('const','data'));
    }
}
