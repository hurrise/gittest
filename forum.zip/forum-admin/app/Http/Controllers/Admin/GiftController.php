<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Gift\GiftAddValidate;
use App\Http\Requests\Gift\GiftEditValidate;
use Illuminate\Http\Request;

class GiftController extends BaseController
{
    public function index(Request $request)
    {
        $data = $this->repo->index($request);
        $params = $request->all();
        return view($this->view,compact('data','giftTag','params'));
    }
    public function add(GiftAddValidate $request){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('const'));
    }
    public function edit(GiftEditValidate $request,$id){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        $tag = explode(',',trim($data->tag,','));
        return view($this->view,compact('const','data','tag'));
    }
}
