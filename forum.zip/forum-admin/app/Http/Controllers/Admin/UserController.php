<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\User\UserAddValidate;
use App\Http\Requests\User\UserEditValidate;
use App\Http\Requests\User\UserPasswordValidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('data','request'));
    }
    public function add(UserAddValidate $request){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('const'));
    }
    public function edit(UserEditValidate $request,$id){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('const','data'));
    }
    public function password(UserPasswordValidate $request,$id){
        if($request->isMethod('post')){
            return $this->repo->changePassword($request,$id);
        }
        return view($this->view,compact('id'));
    }

    public function focus(Request $request)
    {
        $data = $this->repo->focus($request);
        $const = $this->const;
        return view($this->view,compact('data','request','const'));
    }
    public function reply(Request $request)
    {
        $data = $this->repo->reply($request);
        $const = $this->const;
        return view($this->view,compact('data','request','const'));
    }
    public function reStatus($id,$status)
    {
        $status = $this->const->normalStatus == $status ? $this->const->disableStatus : $this->const->normalStatus;
        DB::table('reply')->where('id',$id)->update(['status'=>$status]);
        return back();
    }
    public function replyDel($id)
    {
        if (DB::table('reply')->where('id',$id)->delete()){
            return ajaxReturn(200,'操作成功');
        }
        return ajaxReturn(400,'操作失败');
    }
    public function friends(Request $request)
    {
        $data = $this->repo->friends($request);
        $const = $this->const;
        return view($this->view,compact('data','request','const'));
    }
    public function friend(Request $request,$id=0)
    {
        $data = $this->repo->friend($request,$id);
        $const = $this->const;
        return view($this->view,compact('request','const','data','id'));
    }

    public function focu(Request $request,$id=0)
    {
        $data = $this->repo->focu($request,$id);
        $const = $this->const;
        return view($this->view,compact('request','data','const','id'));
    }
}
