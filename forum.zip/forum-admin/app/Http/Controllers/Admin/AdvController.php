<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Adv\SendValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdvController extends BaseController
{
    public function send(SendValidate $request){
        if($request->isMethod('post')){
            return $this->repo->send($request);
        }
        $const = $this->const;
        return view($this->view,compact('const'));
    }
}
