<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CommentController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('data','request'));
    }

    public function topic(Request $request,$id){
        $data = $this->repo->topic($request,$id);
        return view($this->view,compact('data','request'));
    }

}
