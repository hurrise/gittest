<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Topics\TopicsAddValidate;
use App\Http\Requests\Topics\TopicsEditValidate;
use Illuminate\Http\Request;

class TopicsController extends BaseController
{
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('request','data'));
    }

    public function add(TopicsAddValidate $request){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('const'));
    }

    public function edit(TopicsEditValidate $request,$id){
        $const = $this->const;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('const','data'));
    }

    public function batchdel($id)
    {
        return $this->repo->batchdel($id);
    }
}
