<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Login\LoginValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class LoginController extends BaseController
{
    public function index(LoginValidate $request){
        if($request->isMethod('post')){
            return $this->repo->login($request);
        }
        return view($this->view);
    }

    public function logout(){
        session()->forget('user');
        return redirect(url('admin/login/index'));
    }
}
