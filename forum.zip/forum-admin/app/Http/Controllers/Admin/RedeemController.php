<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RedeemController extends BaseController
{
    public function index(Request $request)
    {
        $data = $this->repo->index($request);
        $const = $this->const;
        return view($this->view,compact('data','request','const'));
    }

    public function deal($id)
    {
        return $this->repo->deal(explode(',',trim($id,',')));
    }
}