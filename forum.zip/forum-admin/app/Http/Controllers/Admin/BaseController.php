<?php

namespace App\Http\Controllers\Admin;

use App\Service\FactoryService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    //
    protected $repo;
    protected $const;
    protected $view;
    public function __construct(Request $request){$controller = $this->getController($request);$this->repo = FactoryService::generateRepository($controller,$controller);$this->view = $request->route()->getName();$this->const = FactoryService::generateService('ConstMap');}
    private function getController($request=""){$url = $request->path();$index = strpos($url,'/');$url = substr($url,$index+1);$index = strpos($url,'/');$url = substr($url,0,$index);$controller = ucfirst(trim($url,' '));return $controller;}
    public function status($id,$status){return $this->repo->status($id,$status);}
    public function del($id){return $this->repo->del($id);}
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
    public function order(Request $request){return $this->repo->order($request);}
}
