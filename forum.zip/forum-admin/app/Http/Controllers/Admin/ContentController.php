<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Content\ContentAddValidate;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ContentController extends BaseController
{
    protected $fields;
    public function __construct(Request $request)
    {
        parent::__construct($request);
        foreach ($this->const->content as $k=>$v) {
            $this->fields[$v] = $this->getOtherRepo('nav')->getNavName($v);
        }
    }
    public function index(Request $request){
        $data = $this->repo->index($request);
        return view($this->view,compact('request','data'));
    }
    public function add(ContentAddValidate $request){
        $fields = $this->fields;
        if($request->isMethod('post')){
            return $this->repo->add($request);
        }
        return view($this->view,compact('fields'));
    }
    public function edit(Request $request,$id){
        $fields = $this->fields;
        if($request->isMethod('post')){
            return $this->repo->edit($request,$id);
        }
        $data = $this->repo->getDataById($id);
        return view($this->view,compact('fields','data'));
    }
    public function batchdel($id)
    {
        return $this->repo->batchdel($id);
    }
}
