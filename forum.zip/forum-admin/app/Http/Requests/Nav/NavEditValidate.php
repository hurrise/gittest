<?php

namespace App\Http\Requests\Nav;

use Illuminate\Foundation\Http\FormRequest;

class NavEditValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')) {
            return [
                'name' => 'required',
                'api' => !empty($this->input('api')) && $this->input('api') != '/' ? 'url' : '',
            ];
        }
        return [];
    }
    public function messages()
    {
        return [
            'name.required' => '导航名必填',
            'api.url' => 'api格式不正确',
        ];
    }
}
