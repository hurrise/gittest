<?php

namespace App\Http\Requests\Nav;

use Illuminate\Foundation\Http\FormRequest;

class NavAddValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')){
            return [
                'name' => 'required',
                'uname' => ['required','alpha','unique:nav'],
                 'api' => !empty($this->input('api')) ? 'url' : '',
            ];
        }
        return [];
    }
    public function messages()
    {
        return [
            'name.required' => '导航名必填',
            'uname.required' => '导航别名必填',
            'uname.alpha' => '别名只能用英文字母组成',
            'uname.unique' => '该别名已存在',
            'api.url' => 'api格式不正确',
        ];
    }
}
