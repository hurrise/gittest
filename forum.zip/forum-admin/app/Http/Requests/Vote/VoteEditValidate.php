<?php

namespace App\Http\Requests\Vote;

use Illuminate\Foundation\Http\FormRequest;

class VoteEditValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')) {
            return [
                'title' => 'required',
                'options' => 'required',
                'start_time' => 'required',
                'end_time' => 'required',
            ];
        }
        return [];
    }


    public function messages()
    {
        return [
            'title.required' => '请填写标题',
            'options.required' => '请添加选项',
            'start_time.required' => '开始时间必填',
            'end_time.required' => '结束时间必填',
        ];
    }
}
