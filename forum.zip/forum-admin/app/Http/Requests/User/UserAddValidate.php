<?php

namespace App\Http\Requests\User;

use App\Rules\Mobile;
use Illuminate\Foundation\Http\FormRequest;

class UserAddValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')){
            return [
                'username' => 'required',
                'mobile' => ['required',new Mobile()],
                'password' => 'required',
            ];
        }
        return [];
    }
    public function messages()
    {
        return [
            'username.required' => '请填写用户名',
            'mobile.required' => '请填写手机号',
            'password.required' => '请填写密码',
        ];
    }
}
