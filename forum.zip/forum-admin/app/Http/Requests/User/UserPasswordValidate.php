<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;

class UserPasswordValidate extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if($this->isMethod('post')){
            return [
                'oldPassword' => 'required',
                'password' => 'required|confirmed',
                'password_confirmation' => 'required',
            ];
        }
        return [];
    }
    public function messages()
    {
        return [
            'oldPassword.required' => '请填写原密码',
            'password.required' => '请填写新密码',
            'password_confirmation.required' => '请填写确认新密码',
            'password.confirmed' => '新密码与确认新密码必须一致',
        ];
    }
}
