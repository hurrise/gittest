<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class UserModel extends BaseModel
{
    protected $table = 'user';
    public function add($request=""){
        $data = $request->all();
        $this->username = $data['username'];
        $this->mobile = $data['mobile'];
        $this->password = toEncrypt($data['password'],$this->const->salt);
        $this->avatar = $this->const->avatar;
        $this->auth = $data['auth'];
        $this->status = $data['status'];
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function edit($request="",$id=""){
        $data = $request->all();
        $user = $this->getDataById($id);
        $user->username = $data['username'];
        $user->credit = $data['credit'];
        $user->auth = $data['auth'];
        $user->status = $data['status'];
        if($user->save()) {
            return ajaxReturn(200, '编辑成功');
        }
        return ajaxReturn(400,'编辑失败');
    }
    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'username','like','%'.$search['search_one'].'%' ];
        }
        return $this->where($where)->orderByDesc('status')->orderByDesc('auth')->paginate($this->const->pageNum);
    }

    public function topics(){
        return $this->hasMany('App\Model\TopicsModel','user_id','id');
    }

    public function focus($request)
    {
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'from_user','like','%'.$search['search_one'].'%' ];
        }
        if (!empty($search[ 'search_two' ])) {
            $where[] = [ 'to_user','like','%'.$search['search_two'].'%' ];
        }
        return $this->getOtherModel('Focus')->where($where)->orderByDesc('status')->orderBy('from_user')->orderBy('to_user')->paginate($this->const->pageNum);
    }
    public function reply($request)
    {
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'reply.created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'reply.created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'from_user','like','%'.$search['search_one'].'%' ];
        }
        if (!empty($search[ 'search_two' ])) {
            $where[] = [ 'to_user','like','%'.$search['search_two'].'%' ];
        }
        if (!empty($search[ 'search_three' ])) {
            $where[] = [ 'title','like','%'.$search['search_three'].'%' ];
        }
        return DB::table('reply')->join('topics','reply.topics_id','=','topics.id')->select( 'topics.title','from_user', 'to_user', 'reply.content', 'reply.status','reply.id', 'comment_content', 'reply.created_at', 'reply.updated_at')->where($where)->orderByDesc('reply.status')->orderBy('title')->orderBy('from_user')->orderBy('to_user')->paginate($this->const->pageNum);
    }

    public function friends($request)
    {
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (isset($search[ 'search_one' ])) {
            $where[] = [ 'from_user','like','%'.$search['search_one'].'%' ];
        }
        if (isset($search[ 'search_two' ])) {
            $where[] = [ 'to_user','like','%'.$search['search_two'].'%' ];
        }
        return DB::table('friend')->where($where)->orderByDesc('status')->orderBy('from_user')->orderBy('to_user')->paginate($this->const->pageNum);
    }

    public function getAvatarAttribute($value)
    {
        if(preg_match('/^\/api_avatar.*/',$value)){
            return $this->const->forumDomain.$value;
        }
        return $value;
    }

    public function focu($request='',$id=0)
    {
        $search = $request->all();
        $where = [];
        if($search){
            isset($search['direction']) && ($where[] = $search['direction'] ? ['from_id',$id] : ['to_id',$id]);
        }
        $friend = $this->getOtherModel('focus')->where($where ?: function($query) use($id){
            $query->where('from_id',$id)->orWhere('to_id',$id);
        });
        $data = $friend->paginate($this->const->pageNum);
        $data->total_num = $friend->count();
        foreach ($data as $k=>$v) {
            if($v->from_id == $id){
                $data[$k]->username=$v->to_user;
                $data[$k]->avatar=$v->to_avatar;
                $data[$k]->direction='关注';
            }
            if($v->to_id == $id){
                $data[$k]->username=$v->from_user;
                $data[$k]->avatar=$v->from_avatar;
                $data[$k]->direction='粉丝';
            }
        }
        return $data;
    }

    public function friend($request='',$id=0)
    {
        $search = $request->all();
        $where = [];
        if($search){
            isset($search['direction']) && ($where[] = $search['direction'] ? ['from_id',$id] : ['to_id',$id]);
            isset($search['status']) && ($where[] = ['status',$search['status']]);
        }
        $friend = $this->getOtherModel('friend')->where($where ?: function($query) use($id){
            $query->where('from_id',$id)->orWhere('to_id',$id);
        });
        $data = $friend->paginate($this->const->pageNum);
        $data->total_num = $friend->count();
        foreach ($data as $k=>$v) {
            if($v->from_id == $id){
                    $data[$k]->username=$v->to_user;
                    $data[$k]->avatar=$v->to_avatar;
            }
            if($v->to_id == $id){
                    $data[$k]->username=$v->from_user;
                    $data[$k]->avatar=$v->from_avatar;
            }
        }
        return $data;
    }
}
