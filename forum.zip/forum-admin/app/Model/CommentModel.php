<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CommentModel extends BaseModel
{
    protected $table = 'comment';
    public function topics(){
        return $this->belongsTo('App\Model\TopicsModel','topics_id','id');
    }
    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'comment.created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'comment.created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'comment.username','like','%'.$search['search_one'].'%' ];
        }
        $data = $this->join('topics','comment.topics_id','=','topics.id')->
        select('topics.title','comment.username','comment.avatar','comment.content',
            'comment.favours','comment.created_at','comment.updated_at','comment.status','comment.id')
            ->where($where)->orderByDesc('comment.status')->orderByDesc('comment.updated_at')
            ->orderByDesc('comment.created_at')->paginate($this->const->pageNum);
        return $data;
    }
    public function topic($request="",$id){
        $search = $request->all();
        $where = [['topics_id',$id]];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'username','like','%'.$search['search_one'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('created_at')->paginate($this->const->pageNum);
        return $data;
    }
}
