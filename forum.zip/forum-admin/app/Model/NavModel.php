<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class NavModel extends BaseModel
{
    protected $table = 'nav';
    public function add($request=""){
        $data = $request->all();
        $this->name = $data['name'].$data['color'];
        $this->uname = $data['uname'];
        $this->api = $data['api']?$data['api']:'/';
        $this->status = $data['status'];
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'name','like','%'.$search['search_one'].'%' ];
        }
        return $this->where($where)->orderByDesc('status')->orderByDesc('order')->paginate($this->const->pageNum);
    }
    public function edit($request="",$id=""){
        $data = $request->all();
        $model = $this->getDataById($id);
        $model->name = $data['name'].$data['color'];
        $model->api = $data['api']?$data['api']:'/';
        $model->status = $data['status'];
        if($model->save()){
            return ajaxReturn(200,'编辑成功');
        }
        return ajaxReturn(400,'编辑失败');
    }
}
