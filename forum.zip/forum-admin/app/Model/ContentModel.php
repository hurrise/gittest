<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ContentModel extends BaseModel
{
    protected $table='content';
    public function add($request=""){
        $data = $request->all();
        $this->user_id = getMe('id');
        $this->username = getMe('username');
        $this->title = $data['title'].$data['color'];
        $this->content = $data['content'];
        $this->type = $data['type'];
        $this->status = $this->const->normalStatus;
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'title','like','%'.$search['search_one'].'%' ];
        }
        return $this->where($where)->orderByDesc('status')->orderByDesc('order')->orderByDesc('created_at')->paginate($this->const->pageNum);
    }

    public function getTypeAttribute($value){
        return $this->getOtherRepo('nav')->getNavName($value);
    }

    public function edit($request="",$id=""){
        $data = $request->all();
        $model = $this->getDataById($id);
        $model->title = $data['title'].$data['color'];
        $model->content = $data['content'];
        $model->type = $data['type'];
        $model->pageview = $data['pageview'];
        if($model->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
    public function batchdel($id='')
    {
        $ids = explode(',',trim($id,','));
        if($this->whereIn('id',$ids)->delete() == count($ids)){
            return ajaxReturn(200,'批量删除成功');
        }
        return ajaxReturn(400,'批量删除失败');
    }
}
