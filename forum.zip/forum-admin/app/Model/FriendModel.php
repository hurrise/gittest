<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FriendModel extends BaseModel
{
    protected $table = 'friend';
}
