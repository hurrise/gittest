<?php

namespace App\Model;

class TopicsModel extends BaseModel
{
    protected $table = 'topics';
    public function add($request=""){
        $data = $request->all();
        $this->title = $data['title'].$data['color'];
        $this->content = $data['content'];
        $this->special = $data['special'];
        $this->user_id = getMe('id');
        $this->username = getMe('username');
        $this->avatar = getMe('avatar');
        $this->status = $this->const->normalStatus;
        if($this->save()){
            return ajaxReturn(200,'发布成功');
        }
        return ajaxReturn(400,'发布失败');
    }
    public function user(){
        return $this->belongsTo('App\Model\UserModel','user_id','id');
    }

    public function comment()
    {
        return $this->hasMany('App\Model\CommentModel','topics_id','id');
    }
    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'username','like','%'.$search['search_one'].'%' ];
        }
        if (!empty($search[ 'search_two' ])) {
            $where[] = [ 'title','like','%'.$search['search_two'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('order')->orderByDesc('created_at')->paginate($this->const->pageNum);
        foreach ($data as $k=>$v){
            $data[$k]['special'] = explode(',',trim($v->special,','));
        }
        return $data;
    }

    public function edit($request="",$id=""){
        $data = $request->all();
        $topic = $this->getDataById($id);
        $topic->title = $data['title'].$data['color'];
        $topic->content = $data['content'];
        $topic->special = $data['special'];
        $topic->comments = $data['comments'];
        $topic->pageview = $data['pageview'];
        if($topic->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }

    public function batchdel($id='')
    {
        $ids = explode(',',trim($id,','));
        if($this->whereIn('id',$ids)->delete() == count($ids)){
            return ajaxReturn(200,'批量删除成功');
        }
        return ajaxReturn(400,'批量删除失败');
    }
}
