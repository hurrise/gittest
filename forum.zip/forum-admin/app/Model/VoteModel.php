<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class VoteModel extends BaseModel
{
    protected $table = 'vote';
    public function add($request=""){
        $data = $request->all();
        $this->title = $data['title'].$data['color'];
        $this->content = $data['content'];
        $this->type = $data['type'];
        $this->options = collect($data['options'])->toJson();
        $this->start_time = $data['start_time'];
        $this->end_time = $data['end_time'];
        $this->status = $this->const->normalStatus;
        $this->user_id = getMe('id');
        $this->username = getMe('username');
        if($this->save()){
            return ajaxReturn(200,'发布成功');
        }
        return ajaxReturn(400,'发布失败');
    }
    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'title','like','%'.$search['search_one'].'%' ];
        }
        return $this->where($where)->orderByDesc('status')->orderByDesc('order')->orderByDesc('created_at')->paginate($this->const->pageNum);
    }
    public function getOptionsAttribute($value){
        return json_decode($value,true);
    }

    public function list($request)
    {
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'vote_record.created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'vote_record.created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'vote.title','like','%'.$search['search_one'].'%' ];
        }
        if (!empty($search[ 'search_two' ])) {
            $where[] = [ 'vote_record.username','like','%'.$search['search_two'].'%' ];
        }
        return $this->join('vote_record','vote_record.vote_id','=','vote.id')->select('vote.title','vote_record.username','vote_record.pollopts','vote_record.created_at','vote_record.updated_at','vote_record.id','vote_record.vote_id')->where($where)->orderByDesc('vote.title')->orderBy('vote_record.username')->orderByDesc('vote_record.created_at')->paginate($this->const->pageNum);
    }

    public function edit($request="",$id=""){
        $data = $request->all();
        $model = $this->getDataById($id);
        $model->title = $data['title'].$data['color'];
        $model->content = $data['content'];
        $model->type = $data['type'];
        $model->options = collect($data['options'])->toJson();
        $model->start_time = $data['start_time'];
        $model->end_time = $data['end_time'];
        $model->pageview = $data['pageview'];
        if($model->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
}
