<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class RedeemModel extends BaseModel
{
    protected $table = 'redeem';

    public function index($request='')
    {
        $const = $this->const;
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        isset($search[ 'search_one' ]) && ($where[] = [ 'user','like','%'.$search['search_one'].'%' ]);
        isset($search[ 'search_two' ]) && ($where[] = [ 'admin','like','%'.$search['search_two'].'%' ]);
        isset($search[ 'search_three' ]) && ($where[] = [ 'giftname','like','%'.$search['search_three'].'%' ]);
        isset($search[ 'status' ]) && ($where[] = [ 'status',$search[ 'status' ] ]);
        $redeem = $this->where($where);
        $data = $redeem->orderByDesc('created_at')->orderByDesc('status')->paginate($const->pageNum);
        $data->total_num = $redeem->count('id');
        return $data;
    }
    public function status($id,$status){
        $model = $this->find($id);
        $model->status = $status == $this->const->normalStatus ? $this->const->disableStatus : $this->const->normalStatus;
        $model->admin_id = session('user')['id'];
        $model->admin = session('user')['username'];
        if($model->save()) {
            return back();
        }
    }
    public function deal($id=[]){
        $user = session('user');
        DB::beginTransAction();
        if($this->whereIn('id',$id)->update(['status'=>$this->const->normalStatus,'admin_id'=>$user['id'],'admin'=>$user['username']]) == count($id)) {
            DB::commit();
            return ajaxReturn(200,'批量审核成功');
        }
        DB::rollback();
        return ajaxReturn(400,'批量操作失败');
    }
}
