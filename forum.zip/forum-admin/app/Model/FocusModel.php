<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FocusModel extends BaseModel
{
    protected $table = 'focus';
    public function getFromAvatarAttribute($value){
        if(preg_match('/^\/api_avatar.*/',$value)){
            return $this->const->forumDomain.$value;
        }
        return $value;
    }
    public function getToAvatarAttribute($value){
        if(preg_match('/^\/api_avatar.*/',$value)){
            return $this->const->forumDomain.$value;
        }
        return $value;
    }
}
