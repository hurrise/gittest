<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CreditsModel extends BaseModel
{
    protected $table = 'credits';
    public function getSourceAttribute($value)
    {
        return $this->const->source[$value];
    }

    public function index($request)
    {
        $search = $request->all();
        $where = [];
        if (!empty($search[ 'start' ]) && !empty($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (!empty($search[ 'search_one' ])) {
            $where[] = [ 'username','like','%'.$search['search_one'].'%' ];
        }
        isset($search['source']) && ($where[] = ['source',$search['source']]);
        $credit = $this->where($where);
        $data = $credit->orderByDesc('created_at')->orderBy('username')->paginate($this->const->pageNum);
        $data->total_num = $credit->count();
        return $data;
    }
}
