<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 16:48
 */

namespace App\Model;


use App\Service\FactoryService;
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
    public $const;
    public function __construct(){$this->const = FactoryService::generateService('ConstMap');}
    public function checkFieldRepeat($field="",$value=""){if($this->where($field,'=',$value)->first()){return true;}return false;}
    public function getDataById($id=""){return $this->find($id);}
    public function del($id=""){if($this->destroy($id)) {return ajaxReturn(200, '删除成功');}return ajaxReturn(400,'删除失败');}
    public function changeField($field,$value="",$id=""){
        if($this->where('id',$id)->update([$field=>$value])){return ajaxReturn(200,'修改成功');}return ajaxReturn(400,'修改失败');
    }
    public function getOtherModel($modelName=""){return FactoryService::generateModel($modelName);}
    public function status($id,$status){
        $model = $this->getDataById($id);
        $model->status = $status == $this->const->normalStatus ? $this->const->disableStatus : $this->const->normalStatus;
        if($model->save()) {
            return back();
        }
    }
    public function order($request=""){$data = $request->all();$model = $this->getDataById($data['id']);$model->order = $data['order'];if($model->save()){return ajaxReturn(200,'排序成功');}return ajaxReturn(400,'排序失败');}
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
}