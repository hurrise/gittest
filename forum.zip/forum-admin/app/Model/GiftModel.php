<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class GiftModel extends BaseModel
{
    protected $table = 'gift';

    public function index($request=""){
        $search = $request->all();
        $where = [];
        if (isset($search[ 'start' ]) && isset($search[ 'end' ])) {
            $where[] = [ 'created_at' , '>=' , $search[ 'start' ] ];
            $where[] = [ 'created_at' , '<=' , $search[ 'end' ] ];
        }
        if (isset($search[ 'search_one' ])) {
            $where[] = [ 'name','like','%'.$search['search_one'].'%' ];
        }
        $data = $this->where($where)->orderByDesc('status')->orderByDesc('order')->paginate($this->const->pageNum);
        return $data;
    }
    public function add($request=""){
        $data = $request->all();
        $this->name = $data['name'];
        $this->img = $request->has('img') ? savefile($request,'img','image') : $this->const->avatar;
        isset($data['description']) && ($this->description = $data['description']);
        $this->price = $data['price'];
        $this->stock = $data['stock'];
        isset($data['tag']) && ($this->tag = $data['tag']);
        isset($data['order']) && ($this->order = $data['order']);
        isset($data['attach']) && ($this->attach = $data['attach']);
        $this->status = $data['status'];
        $this->user_id = getMe('id');
        $this->username = getMe('username');
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function edit($request="",$id=""){
        $data = $request->all();
        $gift = $this->getDataById($id);
        $gift->name = $data['name'];
        $gift->img = $request->has('img') ? savefile($request,'img','image') : $this->const->avatar;
        isset($data['description']) && ($gift->description = $data['description']);
        $gift->price = $data['price'];
        $gift->stock = $data['stock'];
        isset($data['tag']) && ($gift->tag = $data['tag']);
        isset($data['order']) && ($gift->order = $data['order']);
        isset($data['attach']) && ($gift->attach = $data['attach']);
        $gift->status = $data['status'];
        $gift->user_id = getMe('id');
        $gift->username = getMe('username');
        if($gift->save()){
            return ajaxReturn(200,'修改成功');
        }
        return ajaxReturn(400,'修改失败');
    }
}
