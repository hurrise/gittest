###
#
#
###

#帖子表

create table `forum_topics`(
	`id` int(11) unsigned auto_increment,
	`title` varchar(255)  not null default '' comment '帖子标题',
	`content` longblob not null comment '帖子内容',
	`user_id` int(11) not null default 0 comment '发表人id',
	`username` varchar(100) not null default '' comment '发表人',
	`avatar` varchar(255) not null default '' comment '发帖人头像',
	`favours` int(11) not null default 0 comment '点赞数量',
	`treads` int(11) not null default 0 comment '踩的数量',
	`special` varchar(30) not null default '' comment '帖子的特殊性',
	`order` int(11) not null default 1 comment '帖子排序',
	`status` tinyint(1) not null default 0 comment '帖子状态',
	`pageview` int(11) not null default 0 comment '帖子浏览量',
	`comments` int(11) not null default 0 comment '帖子的评论数量',
	`created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key t_name(`username`),
	key title(`title`)
)engine=innodb default charset=utf8mb4;

#评论表
create table `forum_comment`(
	`id` int(11) unsigned auto_increment,
	`topics_id` int(11) not null default 0 comment '帖子id',
	`user_id` int(11) not null default 0 comment '回贴人id',
	`username` varchar(100) not null default '' comment '回帖人',
	`avatar` varchar(255) not null default '' comment '回帖人头像',
	`content` text not null comment '评论的内容',
	`favours` int(11) not null default 0 comment '评论的赞的数量',
	`status` tinyint(1) not null default 0 comment '状态',
	`created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key c_name(`username`)
)engine=innodb default charset=utf8mb4;

#用户表
create table `forum_user`(
	`id` int(11) unsigned auto_increment,
	`username` varchar(100) not null default '' comment '用户名',
	`mobile` varchar(15) not null default '' comment '手机号',
	`password` varchar(255) not null default '' comment '密码',
	`auth` tinyint(1) not null default 1 comment '用户权限',
	`avatar` varchar(255) not null default '' comment '头像',
	`qq` VARCHAR (20) not null DEFAULT '' comment 'qq',
	`credit` int(11) not null default 0 comment '积分',
	`signed_days` int(11) not null default 0 comment '累计签到天数',
	`status` tinyint(1) not null default 0 comment '状态',
	`login_ip` varchar(20) not null default '' comment '登录ip',
	`last_login_time` varchar(30) not null default '' comment '最后一次登录时间',
	`fans` int(11) not null default 0 comment '粉丝数量',
	`focus` int(11) not null default 0 comment '关注了多少人',
	`created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	unique key username(`username`),
	key u_name(`username`)
)engine=innodb default charset=utf8mb4;


#底部导航
create table `forum_nav`(
  `id` int(11) unsigned auto_increment,
  `name` varchar(100) not null DEFAULT '' comment '导航名称',
  `uname` varchar(20) not null DEFAULT '' comment '导航别名',
  `api` VARCHAR(255) NOT NULL DEFAULT '' comment '所用api',
  `order` int(5) not null DEFAULT 0 comment '排序',
  `status` tinyint(1) not null default 0 comment '状态',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	unique key uname(`uname`),
	key u_name(`name`)
)engine=innodb default charset=utf8mb4;

#投票内容表
create TABLE `forum_vote`(
  `id` int(11) unsigned auto_increment,
  `title` varchar(255)  not null default '' comment '投票标题',
  `user_id` int(11) not null default 0 comment '发表人id',
	`username` varchar(100) not null default '' comment '发表人',
  `content` text  comment '投票内容',
  `type` tinyint(1) not null DEFAULT 1 comment '投票类型',
  `options` text  comment '投票选项',
  `start_time` varchar(30) not null default ''  comment '开始时间',
  `end_time` varchar(30) not null default ''  comment '结束时间',
  `pageview` INT(11) NOT NULL DEFAULT 0 comment '浏览量',
  `status` tinyint(1) not null default 0 comment '状态',
  `order` int(11) not null default 1 comment '排序',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key v_c_title(`title`)
)engine=innodb default charset=utf8mb4;

#投票记录表
create TABLE `forum_vote_record`(
  `id` int(11) unsigned auto_increment,
  `user_id` int(11) not null DEFAULT 0 comment '投票人id',
  `username` varchar(30) not null DEFAULT '' comment '投票人',
  `vote_id` int(11) not null DEFAULT 0 comment '投票id',
  `pollopts` text  comment '投票数据',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`)
)engine=innodb default charset=utf8mb4;

#投票结果表
CREATE TABLE `forum_vote_result`(
  `id` int(11) unsigned auto_increment,
  `vote_id` int(11) not null DEFAULT 0 comment '投票id',
  `result` text  comment '投票结果',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`)
)engine=innodb default charset=utf8mb4;

#其他内容
CREATE TABLE `forum_content`(
  `id` int(11) unsigned auto_increment,
  `user_id` int(11) not null default 0 comment '发表人id',
	`username` varchar(100) not null default '' comment '发表人',
	`title` varchar(255)  not null default '' comment '标题',
	`content` text  comment '内容',
	`pageview` INT(11) NOT NULL DEFAULT 0 comment '浏览量',
	`status` tinyint(1) not null default 0 comment '状态',
  `order` int(11) not null default 1 comment '排序',
  `type` VARCHAR (20) not NULL DEFAULT '' comment '所属模块',
	`created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key v_cont_title(`title`),
	key v_cont_type(`type`)
)engine=innodb default charset=utf8mb4;

#礼品表
CREATE TABLE `forum_gift`(
  `id` int(11) unsigned auto_increment,
  `name` varchar(100) not null default '' comment '礼品名',
  `img` varchar(255) not null default '' comment '礼品图片',
  `description` text comment '礼品描述',
  `price` int(11) not null default 0 comment '积分价格',
  `redeemed` int(11) not null default 0 comment '已兑换数量',
  `stock` int(11) not null default 0 comment '礼品库存',
  `status` tinyint(1) not null default 0 comment '礼品状态',
  `order` int(11) not null default 0 comment '礼品排序',
  `tag` varchar(255) not null default '' comment '礼品标签',
  `user_id` int(11) not null default 0 comment '礼品发布者id',
  `username` varchar(100) not null default '' comment '礼品发布者',
  `attach` varchar(255) not null default '' comment '礼品备注',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	unique key name(`name`),
	key g_name(`name`)
)engine=innodb default charset=utf8mb4;

#回复表
CREATE TABLE `forum_reply`(
  `id` int(11) unsigned auto_increment,
  `from_id` int(11) not null DEFAULT 0 comment '来自谁',
  `to_id` int(11) not null DEFAULT 0 comment '到谁',
  `from_user` VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `from_avatar` VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `to_user`  VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `to_avatar`  VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `content` text comment '内容',
  `status` tinyint(1) not null DEFAULT 0 comment '状态',
  `topics_id` int(11) not null DEFAULT 0 comment '帖子id',
  `comment_id` int(11) not null DEFAULT 0 comment '评论id',
  `comment_content` text comment '被评论的内容',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key r_f_u(`from_user`),
	key r_t_u(`to_user`)
)engine=innodb default charset=utf8mb4;

#关注表
CREATE TABLE `forum_focus`(
  `id` int(11) unsigned auto_increment,
  `from_id` int(11) not null DEFAULT 0 comment '谁关注',
  `to_id` int(11) not null DEFAULT 0 comment '关注谁',
  `from_user` VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `from_avatar` VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `to_user`  VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `to_avatar`  VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	KEY `from_user` (`from_user`),
	KEY `to_user` (`to_user`)
)engine=innodb default charset=utf8mb4;


#朋友表
CREATE TABLE `forum_friend`(
  `id` int(11) unsigned auto_increment,
  `from_id` int(11) not null DEFAULT 0 comment '加好友者id',
  `to_id` int(11) not null DEFAULT 0 comment '被加者id',
  `from_user` VARCHAR(200) not NULL DEFAULT '' comment '谁加的',
  `from_avatar` VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `to_user`  VARCHAR(200) not NULL DEFAULT '' comment '加的谁',
  `to_avatar`  VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:申请中,1:是好友',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	KEY `f_f_user` (`from_user`),
	KEY `f_t_user` (`to_user`)
)engine=innodb default charset=utf8mb4;

#点赞表
CREATE TABLE `forum_favours`(
  `id` int(11) unsigned auto_increment,
  `from_id` int(11) not null DEFAULT 0 comment '来自谁',
  `to_id` int(11) not null DEFAULT 0 comment '到谁',
  `from_user` VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `from_avatar` VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `to_user`  VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `to_avatar`  VARCHAR(200) not NULL DEFAULT '' comment '头像',
  `comment` text comment '被赞的评论',
  `topics_id` int(11) not null DEFAULT 0 comment '帖子id',
  `title` varchar(255)  not null default '' comment '帖子标题',
  `comment_id` int(11) not null DEFAULT 0 comment '评论id',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key f_f_u(`from_user`),
	key f_t_u(`to_user`)
)engine=innodb default charset=utf8mb4;

#积分明细表
CREATE TABLE `forum_credits`(
  `id` int(11) unsigned auto_increment,
  `source` varchar(30) not null DEFAULT 0 comment '积分来源',
  `value` tinyint(3) not null DEFAULT 0 comment '分值',
  `user_id` int(11) not NULL DEFAULT 0 comment '用户id',
  `username` VARCHAR(200) not NULL DEFAULT '' comment '用户名',
  `avatar` VARCHAR(200) not NULL DEFAULT '' comment '用户头像',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key source(`source`),
	key c_uname(`username`)
)engine=innodb default charset=utf8mb4;

#兑换表
CREATE TABLE `forum_redeem`(
  `id` int(11) unsigned auto_increment,
  `user_id` int(11) not NULL DEFAULT 0 comment '兑换用户id',
  `user` varchar(200) not NULL DEFAULT '' comment '用户名',
  `admin_id` int(11) not NULL DEFAULT 0 comment '处理管理员id',
  `admin` varchar(200) not NULL DEFAULT '' comment '管理员名',
  `gift_id` int(11) not NULL DEFAULT 0 comment '礼品id',
  `giftname` varchar(200) not NULL DEFAULT '' comment '礼品名',
  `price` int(11) not null default 0 comment '积分价格',
  `status` tinyint(1) not null default 0 comment '兑换状态',
  `created_at` varchar(30) not null default '',
	`updated_at` varchar(30) not null default '',
	primary key id(`id`),
	key user(`user`),
	key admin(`admin`),
	key  giftname(`giftname`)
)engine=innodb default charset=utf8mb4;
