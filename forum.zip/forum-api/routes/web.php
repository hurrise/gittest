<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('/index.html');
});

Route::group(['namespace'=>'Api','prefix'=>'api/'],function (){
    Route::group(['namespace'=>'V1','prefix'=>'v1/'],function (){
        Route::post('login',['uses'=>'LoginController@login','as'=>'api.login.login']); //登录
        Route::post('register',['uses'=>'LoginController@register','as'=>'api.login.register']); //注册
        Route::get('check',['uses'=>'LoginController@check','as'=>'api.login.check']); //检测token
        Route::get('captcha',['uses'=>'CaptchaController@grant','as'=>'api.captcha.grant']); //获取短信验证码
        Route::get('reset.captcha',['uses'=>'CaptchaController@reset','as'=>'api.captcha.reset']); //获取找回密码 短信验证码
        Route::get('topics/{pageSize?}/{currPage?}',['uses'=>'TopicsController@index','as'=>'api.topics.index']); //帖子列表
        Route::get('comments/{pageSize?}/{currPage?}',['uses'=>'CommentController@index','as'=>'api.comment.index']); //评论列表
        Route::get('contents/{type?}/{pageSize?}/{currPage?}',['uses'=>'ContentController@index','as'=>'api.content.index']); //内容列表
        Route::get('votes/{pageSize?}/{currPage?}',['uses'=>'VoteController@index','as'=>'api.vote.index']); //投票列表
        Route::get('navs',['uses'=>'NavController@index','as'=>'api.nav.index']); //底部导航
        Route::get('topics.detail',['uses'=>'TopicsController@detail','as'=>'api.topics.detail']); //帖子详情
        Route::get('content.detail',['uses'=>'ContentController@detail','as'=>'api.content.detail']); //内容详情
        Route::get('vote.detail',['uses'=>'VoteController@detail','as'=>'api.vote.detail']); //投票详情
        Route::post('reset.password',['uses'=>'LoginController@reset','as'=>'api.login.reset']); //重置密码
        Route::group(['middleware'=>'login'],function (){
            Route::post('topics.post',['uses'=>'TopicsController@post','as'=>'api.topics.post']); //发帖
            Route::post('comment.post',['uses'=>'CommentController@post','as'=>'api.comment.post']); //回帖
            Route::post('topics.favour',['uses'=>'TopicsController@favour','as'=>'api.topics.favour']); //帖子点赞
            Route::post('vote.post',['uses'=>'VoteController@post','as'=>'api.vote.post']); //投票
            Route::post('reply.post',['uses'=>'ReplyController@post','as'=>'api.reply.post']); //回复
            Route::post('comment.favour',['uses'=>'CommentController@favour','as'=>'api.comment.favour']); //评论点赞
            Route::get('ucenter',['uses'=>'UserController@center','as'=>'api.user.center']); //uCenter
            Route::post('focus',['uses'=>'UserController@focus','as'=>'api.user.foucs']); //关注

            Route::get('my.topics/{pageSize?}/{currPage?}',['uses'=>'TopicsController@my','as'=>'api.topics.my']); //我的帖子
            Route::get('my.comments/{pageSize?}/{currPage?}',['uses'=>'CommentController@my','as'=>'api.comment.my']); //我的评论
            Route::post('friend.add',['uses'=>'FriendController@add','as'=>'api.friend.add']); //添加好友
            Route::get('friend.apply',['uses'=>'FriendController@apply','as'=>'api.friend.apply']); //加我列表
            Route::post('friend.accept',['uses'=>'FriendController@accept','as'=>'api.friend.accept']); //处理加友请求
            Route::get('friend/{pageSize?}/{currPage?}',['uses'=>'FriendController@index','as'=>'api.friend.index']); //我的好友
            Route::get('homepage/{id}',['uses'=>'UserController@homepage','as'=>'api.user.homepage']); //个人主页 个人信息
            Route::get('his.topics/{id}/{pageSize?}/{currPage?}',['uses'=>'TopicsController@his','as'=>'api.topics.his']); //个人主页 他的帖子
            Route::get('his.comments/{id}/{pageSize?}/{currPage?}',['uses'=>'CommentController@his','as'=>'api.comment.his']); //个人主页 他的回复
            Route::get('logout',['uses'=>'LoginController@logout','as'=>'api.login.logout']); //退出登录
            Route::post('repasswd',['uses'=>'LoginController@repasswd','as'=>'api.login.repasswd']); //修改密码
            Route::get('atme/{pageSize?}/{currPage?}',['uses'=>'ReplyController@atme','as'=>'api.reply.atme']); //@我的
            Route::post('change.avatar',['uses'=>'UserController@avatar','as'=>'api.user.avatar']); //修改头像
            Route::get('my.focus/{pageSize?}/{currPage?}',['uses'=>'FocusController@focus','as'=>'api.focus.focus']); //我的关注
            Route::get('my.fans/{pageSize?}/{currPage?}',['uses'=>'FocusController@fans','as'=>'api.focus.fans']); //我的粉丝
            Route::get('my.favoured/{pageSize?}/{currPage?}',['uses'=>'CommentController@favoured','as'=>'api.comment.favoured']); //赞我的
            Route::get('sign.info',['uses'=>'UserController@info','as'=>'api.user.info']); //签到信息
            Route::get('sign',['uses'=>'UserController@sign','as'=>'api.user.sign']); //签到
            Route::post('friend.del',['uses'=>'FriendController@del','as'=>'api.friend.del']); //删除好友
            Route::get('mission',['uses'=>'UserController@mission','as'=>'api.user.mission']); //每日任务信息
            Route::get('credits/{pageSize?}/{currPage?}',['uses'=>'CreditController@index','as'=>'api.credit.index']); //积分明细
            Route::get('gift/{pageSize?}/{currPage?}',['uses'=>'GiftController@index','as'=>'api.gift.index']); //礼品列表
            Route::get('gift.redeem',['uses'=>'GiftController@redeem','as'=>'api.gift.redeem']); //礼品兑换
            Route::get('redeem/{all?}/{pageSize?}/{currPage?}',['uses'=>'RedeemController@index','as'=>'api.redeem.index']); //兑换记录
        });
    });
});
