<?php

namespace App\Providers;

use App\Model\CommentModel;
use App\Model\ContentModel;
use App\Model\GiftModel;
use App\Model\NavModel;
use App\Model\RedeemModel;
use App\Model\TopicsModel;
use App\Model\VoteModel;
use App\Observer\CommentObserver;
use App\Observer\ContentObserver;
use App\Observer\GiftObserver;
use App\Observer\NavObserver;
use App\Observer\RedeemObserver;
use App\Observer\TopicsObserver;
use App\Observer\VoteObserver;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        TopicsModel::observe(TopicsObserver::class);
        NavModel::observe(NavObserver::class);
        ContentModel::observe(ContentObserver::class);
        VoteModel::observe(VoteObserver::class);
        CommentModel::observe(CommentObserver::class);
        GiftModel::observe(GiftObserver::class);
        RedeemModel::observe(RedeemObserver::class);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
