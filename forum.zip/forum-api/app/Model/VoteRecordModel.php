<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class VoteRecordModel extends Model
{
    protected $table = 'vote_record';
}
