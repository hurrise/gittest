<?php

namespace App\Model;

use App\Lib\FriendException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class FriendModel extends BaseModel
{
    protected $table = 'friend';
    public function add($data=[])
    {
        if ($data['to_id'] == $data['user']['id']){
            throw new FriendException(['status'=>7410,'msg'=>'不能添加自己为好友']);
        }
        if (!DB::table('user')->where('id',$data['to_id'])->first()){
            throw new FriendException(['status'=>7441,'msg'=>'用户不存在,请检查用户id']);
        }
        $user = $this->getOtherModel('user')->where('id',$data['to_id'])->select('username','avatar')->get()[0]->toArray();
        if($this->where('from_id',$data['user']['id'])->where('to_id',$data['to_id'])->where('status',$this->const->disableStatus)->first()){
            throw new FriendException(['status'=>7430,'msg'=>'您已申请加他好友了,请等待他通过']);
        }
        if($this->where('from_id',$data['user']['id'])->where('to_id',$data['to_id'])->where('status',$this->const->normalStatus)->first()
         || $this->where('to_id',$data['user']['id'])->where('from_id',$data['to_id'])->where('status',$this->const->normalStatus)->first()){
            throw new FriendException(['status'=>7420,'msg'=>'您们已是好友了']);
        }
        $this->from_id = $data['user']['id'];
        $this->from_user = $data['user']['username'];
        $this->from_avatar = $data['user']['avatar'];
        $this->to_id = $data['to_id'];
        $this->to_user = $user['username'];
        $this->to_avatar = $user['avatar'];
        if($this->save()){
            return ajaxReturn(7200,'发送加好友请求成功');
        }
        throw new FriendException(['status'=>7400,'msg'=>'操作失败']);
    }

    public function apply($id=0)
    {
        $data =  $this->select('id','from_id','from_user','from_avatar','created_at')->where('to_id',$id)->where('status',$this->const->disableStatus)->get()->toArray();
        return ajaxReturn($this->const->successStatus,'获取成功',$data);
    }

    public function accept($data=[])
    {
        if($data['status'] == $this->const->cancelFocus){
            if($this->where('id',$data['id'])->delete()){
                return ajaxReturn($this->const->successStatus,'操作成功');
            }
            throw new FriendException(['status'=>7530,'msg'=>'操作失败']);
        }
        if($this->where('id',$data['id'])->update(['status'=>$this->const->normalStatus])){
            return ajaxReturn($this->const->successStatus,'操作成功');
        }
        throw new FriendException(['status'=>7540,'msg'=>'操作失败']);
    }

    public function index($id=0,$pageSize=0,$currPage=0)
    {
        $friend = $this->where('from_id',$id)->orWhere('to_id',$id);
        $data = $friend->select('id','from_id','to_id','from_user','from_avatar','to_user','to_avatar','updated_at')->where('status',$this->const->normalStatus)->orderByDesc('updated_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
        $result=[];
        foreach ($data as $v) {
            if($v['from_id'] == $id){
                $result[] = [
                    'id'=>$v['id'],
                    'user_id'=>$v['to_id'],
                    'username'=>$v['to_user'],
                    'avatar'=>$v['to_avatar'],
                    'created_at'=>$v['updated_at'],
                ];
            }
            if($v['to_id'] == $id){
                $result[] = [
                    'id'=>$v['id'],
                    'user_id'=>$v['from_id'],
                    'username'=>$v['from_user'],
                    'avatar'=>$v['from_avatar'],
                    'created_at'=>$v['updated_at'],
                ];
            }
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['friends'=>$result,'total'=>$friend->count()]);
    }
    public function del($id=0)
    {
        if($this->find($id)->delete()){
            return ajaxReturn($this->const->successStatus,'操作成功');
        }
        throw new FriendException(['status'=>7550,'msg'=>'操作失败']);
    }
}
