<?php

namespace App\Model;

use App\Lib\LoginException;
use App\Lib\UserException;
use App\Service\FactoryService;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class UserModel extends BaseModel
{
    protected $table = 'user';
    public function add($data=""){
        $this->username = $data['username'];
        $this->mobile = $data['mobile'];
        $this->password = toEncrypt($data['password'],$this->const->salt);
        $this->auth = $this->const->normalAuth;
        $this->qq = isset($data['qq']) && !empty($data['qq'])?$data['qq']:'';
        $this->avatar = $this->const->avatar;
        $this->status = $this->const->normalStatus;
        $this->login_ip = get_real_ip();
        $this->last_login_time = Carbon::now();
        if($id = $this->save()){
            $user = $this->getDataById($this->getKey());
            return ajaxReturn($this->const->successStatus,'注册成功',['token' => FactoryService::generateService('Token')->grantToken($user)]);
        }
        throw new LoginException(['status'=>2007,'msg'=>'注册失败']);
    }
    public function topics(){
        return $this->hasMany('App\Model\TopicsModel','user_id','id');
    }
    public function comment(){
        return $this->hasMany('App\Model\CommentModel','user_id','id');
    }

    public function focus($data=""){
        $focus = $this->getOtherModel('Focus');
        $to = $this->getDataById($data['to_id']);
        $from = $this->getDataById($data['user']['id']);
        if(!empty($to) && !empty($from)) {
            if($to->id == $from->id){
                throw new UserException(['status'=>6002,'msg'=>'自己不能关注自己的~亲!']);
            }
            if($data['direction'] == $this->const->focus) {
                if($focus->where('from_id',$from->id)->where('to_id',$to->id)->first()){
                    throw new UserException(['status'=>6003,'msg'=>'您已经关注过了']);
                }
                $focus->from_id = $from->id;
                $focus->from_user = $from->username;
                $focus->from_avatar = $from->avatar;
                $focus->to_id = $to->id;
                $focus->to_user = $to->username;
                $focus->to_avatar = $to->avatar;
                $from->increment('focus');
                $to->increment('fans');
                if ($focus->save()) {
                    return ajaxReturn($this->const->successStatus, '关注成功');
                }
            }elseif($data['direction'] == $this->const->cancelFocus){
                $from->where('focus','>','0')->decrement('focus');
                $to->where('fans','>','0')->decrement('fans');
                if($focus->where('from_id',$from->id)->where('to_id',$to->id)->delete()){
                    return ajaxReturn($this->const->successStatus,'取消成功');
                }
            }
        }
        throw new UserException(['status'=>6001,'msg'=>'操作失败']);
    }

    public function homepage($id=0,$cur_user_id=0)
    {
        $userInfo = $this->where('id',$id)->select('id', 'username', 'avatar', 'credit', 'fans', 'focus')->get()[0]->toArray();
        $userInfo['is_focued'] = $this->getOtherModel('focus')->where('from_id',$cur_user_id)->where('to_id',$id)->first() ? true : false;
        $friend = $this->getOtherModel('friend');
        $userInfo['is_friend'] = ($friend->where('from_id',$cur_user_id)->where('to_id',$id)->first() || $friend->where('from_id',$id)->where('to_id',$cur_user_id)->first()) ? true : false;
        $userInfo['is_myself'] = $id == $cur_user_id;
        return ajaxReturn($this->const->successStatus,'获取他的信息成功',$userInfo);
    }

    public function avatar($id=0,$data="")
    {
        if($this->where('id',$id)->update(['avatar'=>$data])){
            return ajaxReturn($this->const->successStatus,'修改成功',['avatar'=>$data]);
        }
        throw new UserException(['status'=>6101,'msg'=>'系统异常,操作失败']);
    }
    public function sign($user=[])
    {
        $key = md5($this->const->signInKey).$user['id'];    //当前用户签到redis key
        $ckey = md5($this->const->signCycleContinuousKey).$user['id'];   ////当前用户周期连续签到天数 redis key
        if(empty(Redis::get($key))){
            Redis::setex($key,strtotime(date('Ymd'))+24*60*60-time(),1);
            if(empty($signDays = Redis::get($ckey))){
                Redis::setex($ckey,strtotime(date('Ymd'))+24*60*60*2-time(),1); //连续签到key不存在则设置,否则value增1并重新设置有效期2,若value=连签周期,则重新设置有效期1并加积分
            } elseif(Redis::expire($ckey,strtotime(date('Ymd'))+24*60*60*2-time()) && Redis::incr($ckey) == $this->const->signConst['signCycle']) {
                Redis::expire($ckey,strtotime(date('Ymd'))+24*60*60-time());
                DB::beginTransaction();
                $signCredit = $this->const->signConst['signCycleBonus'];
                $flagU = $this->where('id',$user['id'])->increment('credit',$signCredit);
                $credits = $this->getOtherModel('credits');
                $credits->source = $this->const->signCycleContinuousKey;
                $credits->value = $signCredit;
                $credits->user_id = $user['id'];
                $credits->username = $user['username'];
                $credits->avatar = $user['avatar'];
                $flagC = $credits->save();
                if ($flagU && $flagC){
                    DB::commit();
                } else {
                    DB::rollback();
                }
            }
            DB::beginTransaction();
            $signInfo = $this->const->signConst;
            $signCredit = $signInfo['signCredit'];
            $flagU = $this->where('id',$user['id'])->increment('credit',$signCredit,['signed_days'=>DB::raw('signed_days +1')]);
            $credits = $this->getOtherModel('credits');
            $credits->source = $this->const->signInKey;
            $credits->value = $signCredit;
            $credits->user_id = $user['id'];
            $credits->username = $user['username'];
            $credits->avatar = $user['avatar'];
            $flagC = $credits->save();
            if ($flagU && $flagC){
                DB::commit();
                $info = $this->const->signConst;
                $info['signed_days'] = $this->find($user['id'])->signed_days;
                $info['is_signed'] = Redis::get($key) ? true : false;
                return ajaxReturn($this->const->successStatus,'签到成功',$info);
            }
            DB::rollback();
            throw new UserException(['status'=>6111,'msg'=>'系统异常,操作失败']);
        }
        throw new UserException(['status'=>6112,'msg'=>'您已经签过到了']);
    }

    public function info($id=0)
    {
        $info = $this->const->signConst;
        $info['signed_days'] = $this->find($id)->signed_days;
        $info['is_signed'] = Redis::get(md5($this->const->signInKey).$id) ? true : false;
        $signCK = md5($this->const->signCycleContinuousKey).$id;
        $info['continuous_signed'] = Redis::exists($signCK) ? Redis::get($signCK) : 0;
        return ajaxReturn($this->const->successStatus,'获取签到信息成功',$info);
    }
    public function mission($id=0)
    {
        $const = $this->const;
        $heat = $const->missionFinishRate;
        foreach ($heat as $k=>$v) {
            $heat[$k] = (int)$v *(100+mt_rand(-6,9))/100;
        }
        $data = [
          'post'=>sprintf('%d',(Redis::get(md5($const->topicMossionKey).$id) ?: 0)/(float)$const->topicMossionNum*100).'%',
          'reply'=>sprintf('%d',(Redis::get(md5($const->replyMossionKey).$id) ?: 0)/(float)$const->replyMossionNum*100).'%',
          'favour'=>sprintf('%d',(Redis::get(md5($const->favourMossionKey).$id) ?: 0)/(float)$const->favourMossionNum*100).'%',
        ];
        return ajaxReturn($const->successStatus,'获取任务信息成功',array_merge($data,$heat));
    }
}
