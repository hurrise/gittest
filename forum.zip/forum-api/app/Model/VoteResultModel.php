<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class VoteResultModel extends Model
{
    protected $table = 'vote_result';
}
