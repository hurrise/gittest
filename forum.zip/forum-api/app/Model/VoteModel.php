<?php

namespace App\Model;

use App\Lib\ParamException;
use App\Lib\VoteException;
use Illuminate\Support\Facades\DB;

class VoteModel extends BaseModel
{
    protected $table = 'vote';
    public function add($data=""){
        if(!empty($this->getOtherModel('VoteRecord')->where('user_id',$data['user']['id'])->where('vote_id',$data['vote_id'])->first())){
            throw new VoteException();
        }
        $vote = $this->getDataById($data['vote_id']);
        $options = json_decode($vote->options,true);
        if(!is_array($data['pollopts'])){
            throw new ParamException(['status'=>1902,'msg'=>'投票数据必须为数组格式']);
        }
        foreach ($data['pollopts'] as $k=>$v) {
            if (!in_array($v, $options)) {
                throw new ParamException(['status' => 1900, 'msg' => '您所提交的选项['.$v.']不在本题的选项内']);
            }
        }
        if($vote->type == $this->const->voteRadio){
            if(count($data['pollopts']) > 1){
                throw new ParamException(['status'=>1901,'msg'=>'此题为单选题']);
            }
        }
        DB::beginTransAction();
        $voteRecord = $this->getOtherModel('VoteRecord');
        $voteRecord->user_id = $data['user']['id'];
        $voteRecord->username = $data['user']['username'];
        $voteRecord->vote_id = $data['vote_id'];
        $voteRecord->pollopts = collect($data['pollopts'])->toJson();
        if($voteRecord->save()){
            if(empty($voteResult = $this->getOtherModel('VoteResult')->where('vote_id',$data['vote_id'])->first())){
                foreach ($data['pollopts'] as $k=>$v){
                    $result[$v] = 1;
                }
                $voteResult = $this->getOtherModel('VoteResult');
                $voteResult->vote_id = $data['vote_id'];
                $voteResult->result = collect($result)->toJson();
                $flag = $voteResult->save();
            }else{
                $result = json_decode($voteResult->result,true);
                foreach ($data['pollopts'] as $k=>$v){
                    if(array_key_exists($v,$result)){
                        $result[$v] += 1;
                    }else{
                        $result[$v] = 1;
                    }
                }
                $voteResult->result = collect($result)->toJson();
                $flag = $voteResult->save();
            }
            if($flag){
                DB::commit();
                return ajaxReturn($this->const->successStatus,'投票成功');
            }else{
                DB::rollback();
                throw new VoteException(['status'=>5001,'msg'=>'操作失败']);
            }
        }
        throw new VoteException(['status' => 5001, 'msg' => '操作失败']);
    }
}
