<?php

namespace App\Model;

use App\Lib\ContentException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class CommentModel extends BaseModel
{
    protected $table = 'comment';
    protected $touches = ['topics'];

    public function topics(){
        return $this->belongsTo('App\Model\TopicsModel','topics_id','id');
    }
    public function user(){
        return $this->belongsTo('App\Model\UserModel','user_id','id');
    }

    public function reply()
    {
        return $this->hasMany('App\Model\ReplyModel','comment_id');
    }

    public function index($pageSize="",$currPage="",$data="")
    {
        if (empty($finalData = Redis::get(md5($this->const->commentsCacheKey) . '_' . $data['id'] . '_' . $pageSize . '_' . $currPage))) {
            $comment = $this->where('topics_id', $data['id'])->where('status',$this->const->normalStatus)
                ->offset(($currPage - 1) * $pageSize)->limit($pageSize)->orderByDesc('created_at')->with('reply')->get();
//                ->with(['reply'=>function($query){ $query->select('id','from_id','from_user','from_avatar','content','comment_content','created_at');}])
            if (!$comment->isEmpty()) {
                foreach ($comment as $k => $v) {
                    $returnData['id'] = $v->id;
                    $returnData['avatar'] = $v->avatar;
                    $returnData['user_id'] = $v->user_id;
                    $returnData['username'] = $v->username;
                    $returnData['created_at'] = $v->created_at->toDateTimeString();
                    $returnData['favours'] = $v->favours;
                    $returnData['content'] = $v->content;
                    $returnData['replies'] = $v->reply;
                    $finalData[] = $returnData;
                }
                Redis::setex(md5($this->const->commentsCacheKey) . '_' . $data['id'] . '_' . $pageSize . '_' . $currPage, $this->const->cahceExpireTime, collect($finalData)->toJson());
            }else{
                $finalData = [];
            }
        }else{
            $finalData = json_decode($finalData,true);
        }
        $total = $this->where('topics_id',$data['id'])->count('id');
        return ajaxReturn($this->const->successStatus,'获取成功',['comments'=>$finalData,'total'=>$total]);
    }
    public function add($data = ""){
        DB::beginTransAction();
        $this->topics_id = $data['topics_id'];
        $topics = $this->getOtherModel('Topics')->getDataById($data['topics_id']);
        $this->title = $topics->title;
        $this->content = $data['content'];
        $this->user_id = $data['user']['id'];
        $user = $this->getOtherModel('User')->getDataById($data['user']['id']);
        $this->username = $user->username;
        $this->avatar = $user->avatar;
        $this->status = $this->const->normalStatus;
        if($this->save()){
            $topics = $this->getOtherModel('Topics')->getDataById($data['topics_id']);
            $topics->comments += 1;
            if($topics->save()) {
                DB::commit();
                $key = md5($this->const->replyMossionKey).$user->id;
                if(empty($mission = Redis::get($key))){
                    Redis::setex($key,strtotime(date('Ymd'))+24*60*60-time(),1);
                } elseif ($mission < $this->const->replyMossionNum) {
                    Redis::incr($key);
                    if(Redis::get($key) == $this->const->replyMossionNum){
                        DB::beginTransAction();
                        $flagU = $user->increment('credit',$this->const->replyMossionCredit);
                        $credits = $this->getOtherModel('credits');
                        $credits->source = $this->const->replyMossionKey;
                        $credits->value = $this->const->replyMossionCredit;
                        $credits->user_id = $user->id;
                        $credits->username = $user->username;
                        $credits->avatar = $user->avatar;
                        $flagC = $credits->save();
                        if($flagU && $flagC){
                            DB::commit();
                        } else {
                            DB::rollback();
                        }
                    }
                }
                return ajaxReturn($this->const->successStatus, '回帖成功');
            }
            DB::rollback();
            throw new ContentException(['status'=>4300,'msg'=>'回帖失败']);
        }
        throw new ContentException(['status'=>4300,'msg'=>'回帖失败']);
    }

    public function favour($data=""){
        if(empty(Redis::get(md5($this->const->commentFavourCacheKey).'_'.$data['comment_id'].'_'.$data['user']['id']))) {
            $model = $this->getDataById($data['comment_id']);
            $favour = $this->getOtherModel('favours');
            $favour->comment_id = $data['comment_id'];
            $favour->topics_id = $data['topics_id'];
            $favour->title = $data['title'];
            $favour->comment = $data['comment'];
            $favour->to_user = $data['to_user'];
            $favour->to_avatar = $data['to_avatar'];
            $favour->to_id = $data['to_id'];
            $favour->from_user = $data['user']['username'];
            $favour->from_avatar = $data['user']['avatar'];
            $favour->from_id = $data['user']['id'];
            $model->favours = $model->favours + 1;
            if ($favour->save() && $model->save()) {
                Redis::setex(md5($this->const->commentFavourCacheKey) . '_' . $data['comment_id'] . '_' . $data['user']['id'], $this->const->cahceExpireTime, 'favour');
                return ajaxReturn($this->const->successStatus, '点赞成功~!');
            }
            throw new ContentException(['status' => 4020, 'msg' => '操作失败']);
        }else{
            throw new ContentException(['status'=>4501,'msg'=>'您已经赞过了~!']);
        }
    }

    public function favoured($id=0,$pageSize=0,$currPage=0){
        $favoured = $this->getOtherModel('favours')->where('to_id',$id);
        $favoureds = $favoured->select('topics_id','title','from_user','from_avatar','comment','created_at')
            ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
        return ajaxReturn($this->const->successStatus,'获取数据成功',['favoureds'=>$favoureds,'total'=>$favoured->count()]);
    }
}
