<?php

namespace App\Model;

class ContentModel extends BaseModel
{
    protected $table = 'content';

    public function previous($order="",$type="",$created_at=""){
        return $this->where('order', '>=', $order)->where('type',$type)->where('created_at','>',$created_at)->first();
    }

    public function next($order="",$type="",$created_at=""){
        return $this->where('order', '<=', $order)->where('type',$type)->where('created_at','<',$created_at)->first();
    }
}
