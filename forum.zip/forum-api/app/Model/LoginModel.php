<?php

namespace App\Model;

class LoginModel extends BaseModel
{
}
