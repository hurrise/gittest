<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CaptchaModel extends BaseModel
{
    //
}
