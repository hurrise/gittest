<?php

namespace App\Model;

use App\Lib\ContentException;
use Illuminate\Database\Eloquent\Model;

class ReplyModel extends BaseModel
{
    protected $table = 'reply';
    public function add($data=""){
        $this->from_id = $data['user']['id'];
        $user = $this->getOtherModel('User')->getDataById($data['user']['id']);
        $this->from_user = $user->username;
        $this->from_avatar = $user->avatar;
        $comment = $this->getOtherModel('Comment')->getDataById($data['comment_id']);
        $this->to_id = $comment->user->id;
        $this->to_user = $comment->user->username;
        $this->to_avatar = $comment->user->avatar;
        $this->content = $data['content'];
        $this->status = $this->const->normalStatus;
        $this->topics_id = $comment->topics->id;
        $topics = $this->getOtherModel('Topics')->getDataById($comment->topics->id);
        $this->title = $topics->title;
        $this->comment_id = $comment->id;
        $this->comment_content = $comment->content;
        if($this->save()){
            (new \App\Observer\CommentObserver)->clearCache();
            return ajaxReturn($this->const->successStatus,'已回复');
        }
        throw new ContentException(['status'=>4014,'msg'=>'系统异常回复失败']);
    }
    public function atme($id=0,$pageSize=0,$currPage=0)
    {
        $comment = $this->where('to_id',$id)->where('status',$this->const->normalStatus);
        $comments = $comment->select('topics_id','from_avatar','from_user','content','comment_content','created_at')
            ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
        return ajaxReturn($this->const->successStatus,'获取数据成功',['comments'=>$comments,'total'=>$comment->count()]);
    }
}
