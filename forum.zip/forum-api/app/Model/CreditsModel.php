<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CreditsModel extends BaseModel
{
    protected $table = 'credits';
}
