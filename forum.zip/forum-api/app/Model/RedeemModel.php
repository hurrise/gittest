<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Redis;

class RedeemModel extends BaseModel
{
    protected $table = 'redeem';
    public function index($id=0,$pageSize=0,$currPage=0)
    {
        $const = $this->const;
        if($id){
            $redeemModel = $this->where('user_id',$id);
            $redeem = $redeemModel->select('user_id', 'user', 'gift_id', 'giftname', 'price','created_at')
                ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
            $total = $redeemModel->count();
            return ajaxReturn($const->successStatus,'获取个人兑换记录成功',compact('redeem','total'));
        }
        $key = md5($const->redeemCacheKey).'_'.$pageSize.'_'.$currPage;
        if($redeem = Redis::get($key)){
            $redeem = json_decode($redeem,true);
        } else {
            $redeem = $this->select('user_id', 'user', 'gift_id', 'giftname', 'price','created_at')
                ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
            $redeem['total'] = $this->count('id');
            Redis::setex($key,$const->cahceExpireTime,collect($redeem)->toJson());
        }
        $total = array_pop($redeem);
        return ajaxReturn($const->successStatus,'获取兑换记录成功',compact('redeem','total'));
    }
}
