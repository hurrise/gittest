<?php

namespace App\Model;

use App\Lib\ParamException;
use App\Lib\UserException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class GiftModel extends BaseModel
{
    protected $table = 'gift';
    public function getTagAttribute($value)
    {
        $tag = $this->const->giftTag;
        return array_map(function ($v) use($tag){
            return $tag[$v];
        },explode(',',trim($value,',')));
    }

    public function index($pageSize=0,$currPage=0)
    {
        $key = md5($this->const->giftCacheKey).'_'.$pageSize.'_'.$currPage;
        if($gift = Redis::get($key)){
            $gift = json_decode($gift,true);
        } else {
            $model = $this->where('status',$this->const->normalStatus);
            $gift = $model->select('id', 'name', 'img', 'description', 'price', 'redeemed', 'stock','tag','created_at')->orderByDesc('order')
                ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
            $gift['total'] = $model->count();
            Redis::setex($key, $this->const->cahceExpireTime,collect($gift)->toJson());
        }
        $total = array_pop($gift);
        return ajaxReturn($this->const->successStatus,'礼品数据获取成功',compact('gift','total'));
    }
    public function redeem($data=[],$user=[])
    {
        $redeem = $this->getOtherModel('redeem');
        $gift = $this->find($data['id']);
        $userModel = $this->getOtherModel('user')->find($user['id']);
        $redeem->user_id = $user['id'];
        $redeem->user = $user['username'];
        $redeem->gift_id = $gift->id;
        $redeem->giftname = $gift->name;
        $price = $gift->price;
        $redeem->price = $price;
        DB::beginTransAction();
        if($gift->where('stock','>',0)->decrement('stock') && $userModel->where('credit','>=',$price)->decrement('credit',$price) && $redeem->save()){
            DB::commit();
            return ajaxReturn($this->const->successStatus,'兑换成功,请等待审核');
        }
        DB::rollback();
        throw new UserException(['status'=>6510,'msg'=>'兑换失败']);
    }
}
