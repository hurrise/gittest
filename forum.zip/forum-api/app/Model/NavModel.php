<?php

namespace App\Model;

class NavModel extends BaseModel
{
    protected $table = 'nav';
}
