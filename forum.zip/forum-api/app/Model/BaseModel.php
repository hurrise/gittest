<?php

namespace App\Model;

use App\Service\FactoryService;
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
    public $const;
    public function __construct(){$this->const = FactoryService::generateService('ConstMap');}
    public function checkFieldRepeat($field="",$value=""){if($this->where($field,'=',$value)->first()){return true;}return false;}
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
    public function getDataById($id=""){return $this->find($id);}
    public function getOtherModel($modelName=""){
        return FactoryService::generateModel($modelName);
    }
}
