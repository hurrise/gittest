<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FocusModel extends BaseModel
{
    protected $table = 'focus';
    public function focus($id=0,$pageSize=0,$currPage=0)
    {
        $focu = $this->where('from_id',$id);
        $focus = $focu->select('to_id','to_avatar','to_user')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
        return ajaxReturn($this->const->successStatus,'获取数据成功',['focus'=>$focus,'total'=>$focu->count()]);
    }

    public function fans($id=0,$pageSize=0,$currPage=0)
    {
        $fan = $this->where('to_id',$id);
        $fans = $fan->select('from_id','from_avatar','from_user')->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
        return ajaxReturn($this->const->successStatus,'获取数据成功',['fans'=>$fans,'total'=>$fan->count()]);
    }
}
