<?php

namespace App\Model;

use App\Lib\ContentException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class TopicsModel extends BaseModel
{
    protected $table = 'topics';
    protected $appends = ['title_color'];

    public function getTitleColorAttribute()
    {
        $title = $this->title;
        return substr($title,strrpos($title,'#'));
    }
    public function user(){
        return $this->belongsTo('App\Model\UserModel','user_id','id');
    }
    public function comment(){
        return $this->hasMany('App\Model\CommentModel','topics_id','id');
    }
    public function add($data = ""){
        $user = $this->getOtherModel('User')->getDataById($data['user']['id']);
        $this->title = $data['title'].$this->const->topicsTitleDefaultColor;
        $this->content = $data['content'];
        $this->user_id = $data['user']['id'];
        $this->username = $user->username;
        $this->avatar = $user->avatar;
        $this->special = $this->const->topicsType_pt;
        $this->status = $this->const->normalStatus;
        if($this->save()){
            $key = md5($this->const->topicMossionKey).$user->id;
            if(empty($mission = Redis::get($key))){
                Redis::setex($key,strtotime(date('Ymd'))+24*60*60-time(),1);
            } elseif ($mission < $this->const->topicMossionNum) {
                Redis::incr($key);
                if(Redis::get($key) == $this->const->topicMossionNum){
                    DB::beginTransaction();
                    $flagU = $user->increment('credit',$this->const->topicMossionCredit);
                    $credits = $this->getOtherModel('credits');
                    $credits->source = $this->const->topicMossionKey;
                    $credits->value = $this->const->topicMossionCredit;
                    $credits->user_id = $user->id;
                    $credits->username = $user->username;
                    $credits->avatar = $user->avatar;
                    $flagC = $credits->save();
                    if($flagU && $flagC){
                        DB::commit();
                    } else {
                        DB::rollback();
                    }
                }
            }
            return ajaxReturn($this->const->successStatus,'发帖成功');
        }
        throw new ContentException(['status'=>4200,'msg'=>'发帖失败']);
    }

    public function favour($data="")
    {
        if(empty($opt = Redis::get(md5($this->const->topicsFavourCacheKey).'_'.$data['user']['id'].'_'.$data['topics_id']))) {
            $model = $this->getDataById($data['topics_id']);
            if ($data['favour'] == $this->const->favour) {
                $model->favours = $model->favours + 1;
            }
            if ($data['favour'] == $this->const->tread) {
                $model->treads = $model->treads + 1;
            }
            if ($model->save()) {
                $user = $this->getOtherModel('User')->getDataById($data['user']['id']);
                $key = md5($this->const->favourMossionKey).$user->id;
                if(empty($mission = Redis::get($key))){
                    Redis::setex($key,strtotime(date('Ymd'))+24*60*60-time(),1);
                } elseif ($mission < $this->const->favourMossionNum) {
                    Redis::incr($key);
                    if(Redis::get($key) == $this->const->favourMossionNum){
                        DB::beginTransaction();
                        $flagU = $user->increment('credit',$this->const->favourMossionCredit);
                        $credits = $this->getOtherModel('credits');
                        $credits->source = $this->const->favourMossionKey;
                        $credits->value = $this->const->favourMossionCredit;
                        $credits->user_id = $user->id;
                        $credits->username = $user->username;
                        $credits->avatar = $user->avatar;
                        $flagC = $credits->save();
                        if($flagU && $flagC){
                            DB::commit();
                        } else {
                            DB::rollback();
                        }
                    }
                }
                Redis::setex(md5($this->const->topicsFavourCacheKey) . '_' . $data['user']['id'] . '_' . $data['topics_id'], $this->const->cahceExpireTime, 'favour');
                return ajaxReturn($this->const->successStatus, '点赞成功');
            }
            throw new ContentException(['status' => 4500, 'msg' => '操作失败']);
        }else{
            throw new ContentException(['status'=>4501,'msg'=>'您已经赞过了~!']);
        }
    }

    public function his($id=0,$pageSize=30,$currPage=1)
    {
        if(empty($topics = Redis::get(md5($this->const->topicsCacheKey).'_'.$id.'_'.$pageSize.'_'.$currPage))){
            $topics = $this->select('title','special','id','comments')->where('user_id',$id)
                ->where('status',$this->const->normalStatus)->orderByDesc('order')->orderByDesc('created_at')
                ->skip(($currPage-1)*$pageSize)->take($pageSize)->get()->toArray();
            if($topics){
                foreach ($topics as $k=>$topic) {
                    $topics[$k]['title'] = color_text($topic['title']);
                }
            }
            Redis::setex(md5($this->const->topicsCacheKey).'_'.$id.'_'.$pageSize.'_'.$currPage,$this->const->cahceExpireTime, collect($topics)->toJson());
        } else{
            $topics = json_decode($topics,true);
        }
        $total = $this->where('user_id',$id)->where('status',$this->const->normalStatus)->count();
        return ajaxReturn($this->const->successStatus,'获取他的帖子成功',['topics'=>$topics,'total'=>$total]);
    }
}
