<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CreditModel extends BaseModel
{
    protected $table = 'credits';

    public function getSourceAttribute($value)
    {
        $source = ['signIn'=>'签到','signCycleBonus'=>'连签期满','topicPost' => '发帖','topicReply' => '回帖','topicFavour' => '赞帖'];
        return $source[$value];
    }

    public function index($id=0,$pageSize=0,$currPage=0)
    {
        $credit = $this->select('source','value','created_at')->where('user_id',$id)
            ->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)->take($pageSize)
            ->get();
        return ajaxReturn($this->const->successStatus,'获取积分数据成功',['credit'=>$credit]);
    }
}
