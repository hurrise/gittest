<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FavoursModel extends BaseModel
{
    protected $table = 'favours';
}
