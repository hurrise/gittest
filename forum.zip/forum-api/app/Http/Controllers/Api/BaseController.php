<?php

namespace App\Http\Controllers\Api;

use App\Lib\ParamException;
use App\Service\FactoryService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    public $repo;
    public $const;
    public $data;
    public function __construct(Request $request)
    {
        $controller = $this->getController($request);
        $this->repo = FactoryService::generateRepository($controller,$controller);
        $this->const = FactoryService::generateService('ConstMap');
        $this->data = $this->secF($request);
    }

    private function getController($request=""){
        $route = $request->route()->getName();
        return explode('.',$route)[1];
    }

    /**过滤不安全的字段并报出异常
     * @param string $request
     * @return array
     * @throws ParamException
     */
    private function secF($request=""){
        $originData = $request->all();
        $route = $request->route()->getName();
        $apiNameArr = explode('.',$route);
        $apiNameStr = $apiNameArr[1].'_'.$apiNameArr[2].'ApiData';
        $apiData = $this->const->$apiNameStr;
        $data = [];
        if(!empty($originData)) {
            foreach ($originData as $k => $v) {
                if (in_array($k, $apiData)) {
                    $data[$k] = $v;
                }
            }
        }
        if(!empty($apiData)) {
            foreach ($apiData as $k => $v) {
                if (!array_key_exists($v, $originData) && $k !== '?') {
                    throw new ParamException(['msg' => '必传的字段{' . $v . '}您没有上传!']);
                }
                if (is_null($data[$v]) && $k !== '?') {
                    throw new ParamException(['msg' => '必传的字段{' . $v . '}不能为空!']);
                }
            }
        }
        return $data;
    }
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
}
