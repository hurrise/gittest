<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class VoteController extends BaseController
{
    public function index($pageSize=30,$currPage=1){
        return $this->repo->index($pageSize,$currPage);
    }
    public function detail(){
        return $this->repo->detail($this->data);
    }
    public function post(Request $request){
        return $this->repo->post($request,$this->data);
    }
}
