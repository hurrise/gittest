<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CaptchaController extends BaseController
{
    public function grant(){
        return $this->repo->grant($this->data);
    }
    public function reset(){
        return $this->repo->reset($this->data);
    }
}
