<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;

class GiftController extends BaseController
{
    public function index($pageSize=30,$currPage=1)
    {
        return $this->repo->index($pageSize,$currPage);
    }

    public function redeem(Request $request)
    {
        return $this->repo->redeem($this->data,$request->user);
    }
}
