<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redis;

class LoginController extends BaseController
{
    public function login(){
        return $this->repo->login($this->data);
    }

    public function register(){
        return $this->repo->register($this->data);
    }

    public function check(Request $request){
        return $this->repo->check($request);
    }

    public function logout(Request $request)
    {
        return $this->repo->logout($request);
    }

    public function repasswd(Request $request)
    {
        return $this->repo->repasswd($request->header('token'),$request->user,$this->data);
    }

    public function reset()
    {
        return $this->repo->reset($this->data);
    }
}
