<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;

class UserController extends BaseController
{
    public function center(Request $request){
        return $this->repo->center($request);
    }
    public function focus(Request $request){
        return $this->repo->focus($request,$this->data);
    }

    public function homepage($id,Request $request)
    {
        return $this->repo->homepage($id,$request->user['id']);
    }

    public function avatar(Request $request)
    {
        return $this->repo->avatar($request->user['id'],$this->data);
    }
    public function sign(Request $request)
    {
        return $this->repo->sign($request->user);
    }
    public function info(Request $request)
    {
        return $this->repo->info($request->user['id']);
    }
    public function mission(Request $request)
    {
        return $this->repo->mission($request->user['id']);
    }
}
