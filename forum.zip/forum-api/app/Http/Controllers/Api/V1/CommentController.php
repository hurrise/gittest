<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;

class CommentController extends BaseController
{
    public function post(Request $request){
        return $this->repo->post($request,$this->data);
    }
    public function index($pageSize=30,$currPage=1){
        return $this->repo->index($pageSize,$currPage,$this->data);
    }
    public function my(Request $request,$pageSize=30,$currPage=1){
        return $this->repo->my($request,$pageSize,$currPage);
    }
    public function his($id=0,$pageSize=30,$currPage=1){
        return $this->repo->his($id,$pageSize,$currPage);
    }
    public function favour(Request $request){
        return $this->repo->favour($request,$this->data);
    }
    public function favoured(Request $request,$pageSize=30,$currPage=1){
        return $this->repo->favoured($request->user['id'],$pageSize,$currPage);
    }
}
