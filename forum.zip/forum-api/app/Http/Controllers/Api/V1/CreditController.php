<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CreditController extends BaseController
{
    public function index(Request $request,$pageSize=30,$currPage=1)
    {
        return $this->repo->index($request->user['id'],$pageSize,$currPage);
    }
}
