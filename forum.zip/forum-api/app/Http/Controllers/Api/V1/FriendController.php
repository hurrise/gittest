<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FriendController extends BaseController
{
    public function add(Request $request)
    {
        $this->data['user'] = $request->user;
        return $this->repo->add($this->data);
    }

    public function apply(Request $request)
    {
        return $this->repo->apply($request->user['id']);
    }

    public function accept()
    {
        return $this->repo->accept($this->data);
    }

    public function index(Request $request,$pageSize=30,$currPage=1)
    {
        return $this->repo->index($request->user['id'],$pageSize,$currPage);
    }

    public function del()
    {
        return $this->repo->del($this->data['id']);
    }
}
