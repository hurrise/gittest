<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ContentController extends BaseController
{
    public function index($type="hzlz",$pageSize=30,$currPage=1){
        return $this->repo->index($type,$pageSize,$currPage);
    }
    public function detail(){
        return $this->repo->detail($this->data);
    }
}
