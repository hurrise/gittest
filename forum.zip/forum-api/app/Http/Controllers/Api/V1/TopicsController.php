<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TopicsController extends BaseController
{
    public function index($pageSize=30,$currPage=1){
        return $this->repo->index($pageSize,$currPage);
    }
    public function my(Request $request,$pageSize=30,$currPage=1){
        return $this->repo->my($request,$pageSize,$currPage);
    }

    public function his($id=0,$pageSize=30,$currPage=1)
    {
        return $this->repo->his($id,$pageSize,$currPage);
    }
    public function detail(){
        return $this->repo->detail($this->data);
    }
    public function post(Request $request){
        return $this->repo->post($request,$this->data);
    }
    public function favour(Request $request){
        return $this->repo->favour($request,$this->data);
    }
}
