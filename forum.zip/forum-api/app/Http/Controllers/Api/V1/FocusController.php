<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class FocusController extends BaseController
{
    public function focus(Request $request,$pageSize=30,$currPage=1)
    {
        return $this->repo->focus($request->user['id'],$pageSize,$currPage);
    }

    public function fans(Request $request,$pageSize=30,$currPage=1)
    {
        return $this->repo->fans($request->user['id'],$pageSize,$currPage);
    }
}
