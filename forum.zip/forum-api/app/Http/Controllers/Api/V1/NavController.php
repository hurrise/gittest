<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class NavController extends BaseController
{
    public function index(){
        return $this->repo->index();
    }
}
