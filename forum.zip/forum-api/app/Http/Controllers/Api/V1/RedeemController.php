<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RedeemController extends BaseController
{
    public function index(Request $request,$all=0,$pageSize=30,$currPage=1)
    {
        return $this->repo->index($all?$request->user['id']:$all,$pageSize,$currPage);
    }
}
