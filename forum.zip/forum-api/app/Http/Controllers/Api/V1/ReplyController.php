<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\BaseController;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ReplyController extends BaseController
{
    public function post(Request $request){
        return $this->repo->post($request,$this->data);
    }
    public function atme(Request $request,$pageSize=30,$currPage=1){
        return $this->repo->atme($request->user['id'],$pageSize,$currPage);
    }
}
