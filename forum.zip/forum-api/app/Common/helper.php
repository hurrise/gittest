<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 18:22
 */
use \Illuminate\Support\Facades\Redis;
function toEncrypt($password="",$salt=""){
    return md5($password.md5($salt));
}

function ajaxReturn($status = 0,$msg = 'success',$data = []){
    $arr = [
        'status' => $status,
        'msg' => $msg,
        'data' => $data,
    ];
    return response()->json($arr);
}

function get_real_ip() {
    $ip = false;
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(', ', $_SERVER['HTTP_X_FORWARDED_FOR']);
        if ($ip) {
            array_unshift($ips, $ip);
            $ip = FALSE;
        }
        for ($i = 0; $i < count($ips); $i++) {
            if (!preg_match('/^(10│172.16│192.168)./', $ips[$i])) {
                $ip = $ips[$i];
                break;
            }
        }
    }
    return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}
function color_text($value){
    return substr($value,0,strrpos($value,'#'));
}

function getColorValue($value){
    return substr($value,strrpos($value,'#'));
}

function clearCache($key="",$wildcard=""){
    if(!empty($wildcard)){
        $keys = Redis::keys($key.$wildcard);
        if(!empty($keys)){
            foreach ($keys as $k=>$v){
                if (Redis::exists($v)) {
                    Redis::del($v);
                }
            }
        }
    }else {
        if (Redis::exists($key)) {
            Redis::del($key);
        }
    }
}

function savefile($request,$filename='',$dir='')
{
    if ($request->isMethod('POST') && $request->hasFile($filename)) {
        $file = $request->file($filename);
        if ($file->isValid()) {
            $ext = $file->getClientOriginalExtension();
            $filename = date('YmdHis').str_random(6).'.'.$ext;
            $dir = 'uploads/'.trim($dir,'/');
            if(!is_dir($dir)){
                mkdir($dir,0777,true);
            }
            $file->move($dir,$filename);
            return $dir.'/'.$filename;
        }
    }
}


function customWriteLog($directory,$msg){
    $path = storage_path().'/logs/'.$directory;
    if(!is_dir($path)){
        mkdir($path);
    }
    $path .= '/'.date('Y-m');
    if(!is_dir($path)){
        mkdir($path);
    }
    $path .= '/'.date('d').'.log';
    \Illuminate\Support\Facades\Log::useFiles($path);
    \Illuminate\Support\Facades\Log::info($msg);
}