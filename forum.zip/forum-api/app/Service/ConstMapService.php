<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 19:13
 */

namespace App\Service;


class ConstMapService
{
    public $superAuth = 2;
    public $normalAuth = 1;
    public $avatar = '/api_avatar/front_default_avatar.png';

    public $normalStatus = 1; //正常的状态
    public $disableStatus = 0; //禁用的状态

    public $pageNum = 10; //每页的数量

    public $salt = 'secret'; //用户的盐
    public $auth = [
        1 => '普通会员',
        2 => '管理员',
    ];

    public $signInKey = 'signIn'; //签到 redis缓存key
    public $signCycleContinuousKey = 'signCycleBonus'; //周期连续签到天数 redis缓存key
    public $signConst = [
        'signCredit' => 1, //签到 积分奖励值
        'signCycle' => 7, //签到 周期
        'signCycleBonus' => 10, //签到 周期额外奖励
    ];
    public $missionFinishRate = [
        'postHeat' => 1258,
        'replyHeat' => 568,
        'favourHeat' => 217
    ];
    public $topicMossionKey = 'topicPost'; //每日任务 发帖 redis缓存key
    public $replyMossionKey = 'topicReply'; //每日任务 回帖 redis缓存key
    public $favourMossionKey = 'topicFavour'; //每日任务 赞帖 redis缓存key
    public $topicMossionNum = 1; //每日任务 发帖数
    public $replyMossionNum = 5; //每日任务 回帖数
    public $favourMossionNum = 5; //每日任务 赞帖数
    public $topicMossionCredit = 3; //每日任务 发帖 奖励积分数
    public $replyMossionCredit = 5; //每日任务 回帖 奖励积分数
    public $favourMossionCredit = 5; //每日任务 赞帖 奖励积分数

    public $topicsType_pt = 0;
    public $topicsType_zd = 9;
    public $topicsType_jh = 1;
    public $topicsType_gg = 2;
    public $topicsType_rt = 3;
    public $topicsType_zztj = 4;

    public function topicsType(){
        return [
            $this->topicsType_pt => '普通',
            $this->topicsType_zd => '置顶',
            $this->topicsType_jh => '精华',
            $this->topicsType_gg => '公告',
            $this->topicsType_rt => '热帖',
            $this->topicsType_zztj => '站长推荐',
        ];
    }

    public function topicsTypeApi(){
        return [
            $this->topicsType_pt => 'ifNormal',
            $this->topicsType_zd => 'ifTop',
            $this->topicsType_jh => 'ifJingHua',
            $this->topicsType_gg => 'ifNotice',
            $this->topicsType_rt => 'ifHot',
            $this->topicsType_zztj => 'iftuijian',
        ];
    }

    public $voteRadio = 1;
    public $voteMultiple = 2;

    public $login_loginApiData = [
        'account',
        'password'
    ];

    public $login_registerApiData = [
        'mobile',
        'captcha',
        'username',
        'password',
        'confirm_password',
        '?' => 'qq', //可传可不传的情况
    ];
    public $comment_postApiData = [
        'topics_id',
        'content',
    ];
    public $favour = 'f';
    public $tread = 't';
    public $topics_favourApiData = [
        'topics_id',
        'favour',
    ];
    public $comment_favourApiData = [
        'comment_id',
        'topics_id',
        'title',
        'comment',
        'to_id',
        'to_user',
        'to_avatar',
    ];
    //帖子标题的长度限制
    public $topicsTitleLen = [
        'min' => 3,
        'max' => 50,
    ];
    public $topicsTitleDefaultColor = '#000000';
    public $topics_postApiData = [
        'title',
        'content',
    ];
    public $topics_detailApiData = [
        'id',
    ];
    public $content_detailApiData = [
        'id',
    ];
    public $vote_detailApiData = [
        'id',
    ];
    public $comment_indexApiData = [
        'id',
    ];
    public $vote_postApiData = [
        'vote_id',
        'pollopts',
    ];
    public $reply_postApiData = [
        'comment_id',
        'content',
    ];
    public $focus = 'y';
    public $cancelFocus = 'n';
    public $user_foucsApiData = [
        'to_id',
        'direction',
    ];
    public $friend_addApiData = [
        'to_id',
    ];
    public $friend_delApiData = [
        'id',
    ];
    public $friend_acceptApiData = [
        'id',
        'status',
    ];
    public $login_repasswdApiData = [
        'old_password',
        'password',
        'confirm_password',
    ];
    public $user_avatarApiData = [
        'avatar',
    ];
    public $captcha_grantApiData = [
        'mobile',
    ];
    public $captcha_resetApiData = [
        'mobile',
    ];
    public $login_resetApiData = [
        'mobile',
        'captcha',
        'password',
        'confirm_password',
    ];
    public $gift_redeemApiData = [
        'id',
    ];
    public $tokenExpireTime = 3600*3;

    public $cahceExpireTime = 3600*24;

    public $visitExpireTime = 3600*12;
    public $imageSize = 1024;
    public $imageMime = [
        'jpeg','jpg','png','gif',
    ];
    public $giftTag = [
        'popular' => '紧俏',
        'new' => '新进',
        'vip' => 'VIP专享',
    ];
    public function __get($name)
    {
        return [];
    }
    public $successStatus = 1; //全局状态码
    public $topicsCacheKey = 'topicsKey';
    public $commentsCacheKey = 'commentsKey';
    public $navCacheKey = 'navKey';
    public $contentCacheKey = 'contentKey';
    public $voteCacheKey = 'voteKey';
    public $contentDetailCacheKay = 'contentDetailKey';
    public $voteDetailCacheKay = 'voteDetailKey';
    public $topicsDetailCacheKay = 'topicsDetailKey';
    public $topicsFavourCacheKey = 'topicsFavourKey';
    public $commentFavourCacheKey = 'commentFavourKey';
    public $giftCacheKey = 'giftCacheKey';
    public $redeemCacheKey = 'redeemCacheKey';
}