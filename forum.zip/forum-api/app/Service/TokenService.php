<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 20:48
 */

namespace App\Service;


use App\Lib\LoginException;
use Illuminate\Support\Facades\Redis;

class TokenService
{
    public function grantToken($user=""){
        $token = md5($user->mobile.time());
        Redis::setex($token,FactoryService::generateService('ConstMap')->tokenExpireTime,$user);
        return $token;
    }
    public function updateUserRedis($token="",$user=''){
        Redis::setex($token,FactoryService::generateService('ConstMap')->tokenExpireTime,$user);
    }
    public function checkToken($request=""){
        $token = $request->header('token');
        if(!isset($token) || empty($token) || !Redis::exists($token)){
            throw new LoginException(['status'=>2101,'msg'=>'请先登录']);
        }
        if(empty($user = Redis::get($token))){
            throw new LoginException(['status'=>2101,'msg'=>'登录已失效']);
        }
        return json_decode($user,true);
    }
    public function check($request=""){
        $token = $request->header('token');
        if(!isset($token) || empty($token)){
            throw new LoginException(['status'=>2200,'msg'=>'未登录']);
        }
        if(empty($user = Redis::get($token))){
            throw new LoginException(['status'=>2200,'msg'=>'未登录']);
        }
        return json_decode($user,true);
    }

    public function destroy($request='')
    {
        $token = $request->header('token');
        if(!isset($token) || empty($token)){
            throw new LoginException(['status'=>2200,'msg'=>'token未传']);
        }
        if(!Redis::exists($token)){
            throw new LoginException(['status'=>2166,'msg'=>'token不存在']);
        }
        Redis::del($token);
        unset($request->user);
    }
}