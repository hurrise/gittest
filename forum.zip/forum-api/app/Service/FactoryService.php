<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/10 0010
 * Time: 15:20
 */

namespace App\Service;


class FactoryService
{
    public static $instance;
    public static function generateClass($className,$params=[]){
        if(empty($params)){
            self::$instance = new $className();
        }else{
            self::$instance = new $className($params);
        }
        return self::$instance;
    }

    /**
     * @param $repoName
     * @param array $params
     * @return mixed
     */
    public static function generateRepository($repoName,$params=[]){
        return self::generateClass('\\App\\Repository\\'.ucfirst($repoName).'Repository',$params);
    }

    /**
     * @param $modelName
     * @param array $params
     * @return mixed
     */
    public static function generateModel($modelName,$params=[]){
        return self::generateClass('\\App\\Model\\'.ucfirst($modelName).'Model',$params);
    }

    /**
     * @param $serviceName
     * @param array $params
     * @return mixed
     */
    public static function generateService($serviceName,$params=[]){
        return self::generateClass('\\App\\Service\\'.ucfirst($serviceName).'Service',$params);
    }
}