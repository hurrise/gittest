<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/19 0019
 * Time: 18:51
 */

namespace App\Lib;


class VoteException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 5000; //自定义状态码
    public $msg = '您已经投过票了'; //统一错误描述信息
}