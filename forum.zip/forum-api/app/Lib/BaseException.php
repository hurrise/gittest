<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 18:23
 */

namespace App\Lib;


use League\Flysystem\Exception;

class BaseException extends Exception
{
    public $code = 200; //http状态码
    public $status = 0000; //自定义状态码
    public $msg = ''; //统一错误描述信息
    function __construct($errorArr=[])
    {
        if(empty($errorArr)){
            return;
        }
        if(array_key_exists('code',$errorArr)){
            $this->code = $errorArr['code'];
        }
        if(array_key_exists('status',$errorArr)){
            $this->status = $errorArr['status'];
        }
        if(array_key_exists('msg',$errorArr)){
            $this->msg = $errorArr['msg'];
        }
    }
}