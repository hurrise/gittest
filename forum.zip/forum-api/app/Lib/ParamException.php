<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 20:08
 */

namespace App\Lib;


class ParamException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 1000; //自定义状态码
    public $msg = '参数异常'; //统一错误描述信息
}