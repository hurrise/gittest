<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 20:39
 */

namespace App\Lib;


class LoginException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 2000; //自定义状态码
    public $msg = '账号或密码错误'; //统一错误描述信息
}