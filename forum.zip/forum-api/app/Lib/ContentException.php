<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 12:38
 */

namespace App\Lib;


class ContentException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 4000; //自定义状态码
    public $msg = '内容为空'; //统一错误描述信息
}