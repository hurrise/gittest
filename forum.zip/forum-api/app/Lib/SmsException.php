<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/1 0001
 * Time: 15:40
 */

namespace App\Lib;


class SmsException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 8000; //自定义状态码
    public $msg = '操作失败'; //统一错误描述信息
}