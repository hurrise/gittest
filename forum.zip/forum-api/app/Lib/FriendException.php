<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/21 0021
 * Time: 18:49
 */

namespace App\Lib;


class FriendException extends BaseException
{
    public $code = 200; //http状态码
    public $status = 7000; //自定义状态码
    public $msg = '已申请或已是好友'; //统一错误描述信息
}