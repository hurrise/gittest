<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 13:22
 */

namespace App\Observer;


use App\Service\FactoryService;

class ContentObserver
{
    public function updated(){
        $this->clearCache();
    }
    public function created(){
        $this->clearCache();
    }
    public function saved(){
        $this->clearCache();
    }
    public function deleted(){
        $this->clearCache();
    }
    public function clearCache(){
        $const = FactoryService::generateService('constMap');
        clearCache(md5($const->contentCacheKey),'*');
        clearCache(md5($const->contentDetailCacheKay),'*');
    }
}