<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 19:46
 */

namespace App\Repository;


use App\Lib\LoginException;
use App\Lib\ParamException;
use App\Lib\SmsException;
use App\Service\FactoryService;
use Illuminate\Support\Facades\Redis;

class LoginRepository extends BaseRepository
{
    public function login($data=""){
        if(empty($user = $this->getOtherModel('user')->where('username',$data['account'])->orWhere('mobile',$data['account'])->first())){
            throw new LoginException();
        }
        if($user->status != $this->const->normalStatus){
            throw new LoginException(['status'=>2001,'msg'=>'用户状态异常,请联系管理员']);
        }
        if($user->password != toEncrypt($data['password'],$this->const->salt)){
            throw new LoginException();
        }
        $user->login_ip = get_real_ip();
        $user->last_login_time = date('Y-m-d H:i:s');
        if($user->save()) {
            return ajaxReturn($this->const->successStatus, '登录成功', ['token' => FactoryService::generateService('Token')->grantToken($user)]);
        }else{
            throw new LoginException(['status'=>2000,'msg'=>'系统异常,登录失败~!']);
        }
    }

    public function register($data=""){
        $userModel = $this->getOtherModel('User');
        if(!Redis::get($data['mobile'])){
            throw new SmsException(['status'=>8002,'msg'=>'请先获取手机验证码']);
        }
        if(Redis::get($data['mobile']) != $data['captcha']){
            Redis::del($data['mobile']);
            throw new SmsException(['status'=>8003,'msg'=>'手机验证码不正确']);
        }
        if(preg_match("/^[A-Za-z0-9_]+$/", $data['username'])){
            throw new LoginException(['status'=>2005,'msg'=>'用户名仅支持汉字']);
        }
        if($userModel->checkFieldRepeat('username',$data['username'])){
            throw new LoginException(['status'=>2003,'msg'=>'用户名已存在']);
        }
        if($data['password'] !== $data['confirm_password']){
            throw new LoginException(['status'=>2004,'msg'=>'密码与确认密码不相等']);
        }
        return $userModel->add($data);
    }



    public function check($request=""){
        $user = $this->getService('Token')->check($request);
        return ajaxReturn($this->const->successStatus,'登录成功',['user'=>$user]);
    }

    public function logout($request='')
    {
        $this->getService('Token')->destroy($request);
        return ajaxReturn($this->const->successStatus,'退出成功');
    }

    public function repasswd($token='',$user=[],$data=[])
    {
        if(!isset($data['password']) || !isset($data['confirm_password'])){
            throw new ParamException(['status'=>1910,'msg'=>'密码与确认密码不能为空']);
        }
        if($data['password'] !== $data['confirm_password']){
            throw new ParamException(['status'=>1911,'msg'=>'密码与确认密码不相等']);
        }
        $password = toEncrypt($data['password'],$this->const->salt);
        if($user['password'] != toEncrypt($data['old_password'],$this->const->salt)){
            throw new ParamException(['status'=>1913,'msg'=>'原密码不正确']);
        }
        $userModel = $this->getOtherModel('user')->find($user['id']);
        $userModel->password = $password;
        if($userModel->save()){
            $this->getService('token')->updateUserRedis($token,$userModel);
            return ajaxReturn($this->const->successStatus,'密码修改成功');
        }
        throw new ParamException(['status'=>1914,'msg'=>'系统异常,操作失败']);
    }

    public function reset($data=[])
    {
        $user = $this->getOtherModel('user')->where('mobile',$data['mobile']);
        if($data['password'] !== $data['confirm_password']){
            throw new ParamException(['status'=>1911,'msg'=>'密码与确认密码不相等']);
        }
        if(!($code = Redis::get($data['mobile']))){
            throw new SmsException(['status'=>8010,'msg'=>'手机验证码已失效']);
        }
        if($code != $data['captcha']){
            throw new SmsException(['status'=>8003,'msg'=>'手机验证码不正确']);
        }
        if (!$user->first()){
            throw new ParamException(['status'=>1916,'msg'=>'不存在绑定此手机的账号']);
        }
        if($user->update(['password'=>toEncrypt($data['password'],$this->const->salt)])){
            return ajaxReturn($this->const->successStatus,'密码重置成功');
        }
        throw new ParamException(['status'=>1914,'msg'=>'系统异常,操作失败']);
    }
}