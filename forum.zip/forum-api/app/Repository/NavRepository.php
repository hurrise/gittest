<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/17 0017
 * Time: 17:53
 */

namespace App\Repository;


use Illuminate\Support\Facades\Redis;

class NavRepository extends BaseRepository
{
    public function index(){
        $data = [
            'name' => null,
            'name_color' => null,
            'api' => null,
            'uname' => null,
        ];
        $finalData = [];
        if(empty($finalData = Redis::get(md5($this->const->navCacheKey)))) {
            $navs = $this->model->where('status', $this->const->normalStatus)->orderByDesc('order')->get();
            foreach ($navs as $k => $v) {
                $data['name'] = color_text($v->name);
                $data['name_color'] = getColorValue($v->name);
                $data['api'] = $v->api;
                $data['uname'] = $v->uname;
                $finalData[] = $data;
            }
            Redis::setex(md5($this->const->navCacheKey),$this->const->cahceExpireTime, collect($finalData)->toJson());
        }else{
            $finalData = json_decode($finalData,true);
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['navs'=>$finalData]);
    }
}