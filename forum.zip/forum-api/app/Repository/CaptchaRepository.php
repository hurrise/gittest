<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/1 0001
 * Time: 15:24
 */

namespace App\Repository;


use App\Lib\LoginException;
use App\Lib\SmsException;
use Illuminate\Support\Facades\Redis;

class CaptchaRepository extends BaseRepository
{
    public function grant($data=""){
        $userModel = $this->getOtherModel('User');
        if(!$this->mathcMobile($data['mobile'])){
            throw new LoginException(['status'=>2006,'msg'=>'手机号格式不正确']);
        }
        if($userModel->checkFieldRepeat('mobile',$data['mobile'])){
            throw new LoginException(['status'=>2002,'msg'=>'该手机号已经注册过了']);
        }
        if(!Redis::get($data['mobile'].'HZ')) {
            Redis::setex($data['mobile'] . 'HZ', 60, 'has');
            return $this->getService('Sms')->send($data['mobile']);
        }else{
            throw new SmsException(['status'=>8001,'msg'=>'请60秒后再次获取']);
        }
    }
    public function reset($data=[]){
        $userModel = $this->getOtherModel('User');
        if(!$this->mathcMobile($data['mobile'])){
            throw new LoginException(['status'=>2006,'msg'=>'手机号格式不正确']);
        }
        if(!$userModel->checkFieldRepeat('mobile',$data['mobile'])){
            throw new LoginException(['status'=>2102,'msg'=>'该手机号未绑定任何账号']);
        }
        if(!Redis::get($data['mobile'].'HZ')) {
            Redis::setex($data['mobile'] . 'HZ', 60, 'has');
            return $this->getService('Sms')->send($data['mobile']);
        }else{
            throw new SmsException(['status'=>8001,'msg'=>'请60秒后再次获取']);
        }
    }
}