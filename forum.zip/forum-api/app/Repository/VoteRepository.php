<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 13:48
 */

namespace App\Repository;


use App\Lib\ContentException;
use App\Lib\ParamException;
use Illuminate\Support\Facades\Redis;

class VoteRepository extends BaseRepository
{
    public function index($pageSize="",$currPage=""){
        $finalData = [];
        $data = [
            'id' => null,
            'title' => null,
            'title_color' => null,
            'created_at' => null,
            'pageview' => null,
        ];
        if(empty($finalData = Redis::get(md5($this->const->voteCacheKey).'_'.$pageSize.'_'.$currPage))) {
            $votes = $this->model->where('status', $this->const->normalStatus)->offset(($currPage - 1) * $pageSize)->limit($pageSize)->orderByDesc('order')->orderByDesc('created_at')->get();
            if (!$votes->isEmpty()) {
                foreach ($votes as $k => $v) {
                    $data['id'] = $v->id;
                    $data['title'] = color_text($v->title);
                    $data['title_color'] = getColorValue($v->title);
                    $data['created_at'] = $v->created_at->toDateTimeString();
                    $data['pageview'] = $v->pageview;
                    $finalData[] = $data;
                }
                Redis::setex(md5($this->const->voteCacheKey) . '_' . $pageSize . '_' . $currPage, $this->const->cahceExpireTime, collect($finalData)->toJson());
            } else {
                $finalData = [];
            }
        }else{
            $finalData = json_decode($finalData,true);
        }
        $total = $this->model->count('id');
        return ajaxReturn($this->const->successStatus,'获取成功',['votes'=>$finalData,'total'=>$total]);
    }
    public function detail($param=""){
        $vote = $this->getDataById($param['id']);
        $now = date('Y-m-d H:i:s');
        if(!empty($vote) && $vote->end_time < $now){
            $data = [
                'id' => null,
                'total' => null,
                'options' => null,
                'title' => null,
                'title_color' => null,
                'start_time' => null,
                'end_time' => null,
                'content' => null,
                'finished' => true,
            ];
            $voteResult = $this->getOtherModel('VoteResult')->where('vote_id',$param['id'])->first();
            $options = json_decode($vote->options,true);
            $voteRes = json_decode($voteResult->result,true);
            foreach ($voteRes as $k=>$v){
                $data['total'] += $v;
            }
            foreach ($options as $k=>$v){
                if(array_key_exists($v,$voteRes)){
                    $tmp = ['item'=>$v,'num'=>$voteRes[$v],'persent'=>(sprintf('%0.2f',$voteRes[$v]/$data['total'])*100)];
                }else{
                    $tmp = ['item'=>$v,'num'=>0,'persent'=>0];
                }
                $data['options'][] = $tmp;
                unset($tmp);
            }
            $data['id'] = $param['id'];
            $data['title'] = color_text($vote->title);
            $data['title_color'] = getColorValue($vote->title);
            $data['start_time'] = $vote->start_time;
            $data['end_time'] = $vote->end_time;
            $data['content'] = $vote->content;
            return ajaxReturn($this->const->successStatus, '获取成功', ['detail' => $data]);
        }else {
            $data = [
                'id' => null,
                'title' => null,
                'title_color' => null,
                'type' => null,
                'options' => null,
                'start_time' => null,
                'end_time' => null,
                'content' => null,
                'finished' => false,
            ];
            if (empty($data = Redis::get(md5($this->const->voteDetailCacheKay) . '_' . $param['id']))) {
                if (!empty($vote)) {
                    if (empty(Redis::get(get_real_ip() . '_' . $param['id']))) {
                        $vote->increment('pageview');
                        Redis::setex(get_real_ip() . '_' . $param['id'], $this->const->visitExpireTime, 'exists');
                    }
                    $data['id'] = $vote->id;
                    $data['title'] = color_text($vote->title);
                    $data['title_color'] = getColorValue($vote->title);
                    $data['type'] = $vote->type;
                    $data['options'] = json_decode($vote->options, true);
                    $data['start_time'] = $vote->start_time;
                    $data['end_time'] = $vote->end_time;
                    $data['content'] = $vote->content;
                    $data['finished'] = false;
                    Redis::setex(md5($this->const->voteDetailCacheKay) . '_' . $param['id'], $this->const->cahceExpireTime, collect($data)->toJson());
                } else {
                    $data = [];
                }
            } else {
                $data = json_decode($data, true);
            }
            return ajaxReturn($this->const->successStatus, '获取成功', ['detail' => $data]);
        }
    }
    public function post($request="",$data=""){
        if(empty($data['vote_id'])){
            throw new ParamException(['status'=>1100,'msg'=>'参数[vote_id]异常']);
        }
        if(empty($data['pollopts'])){
            throw new ContentException(['status'=>4200,'msg'=>'请上传投票数据']);
        }
        $data['user'] = $request->user;
        return $this->model->add($data);
    }
}