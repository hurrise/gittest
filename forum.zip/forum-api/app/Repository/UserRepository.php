<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/19 0019
 * Time: 12:54
 */

namespace App\Repository;


use App\Lib\LoginException;
use App\Lib\ParamException;
use App\Lib\UserException;
use Illuminate\Http\Request;

class UserRepository extends BaseRepository
{
    public function center(Request $request){
        $data = [
            'avatar' => null,
            'username' => null,
            'credit' => null,
            'fans' => null,
            'focus' => null,
        ];
        $user = $this->getDataById($request->user['id']);
        if(!empty($user)){
            $data['id'] = $user->id;
            $data['avatar'] = $user->avatar;
            $data['username'] = $user->username;
            $data['credit'] = $user->credit;
            $data['fans'] = $user->fans;
            $data['focus'] = $user->focus;
            return ajaxReturn($this->const->successStatus,'获取成功',['user'=>$data]);
        }else{
            throw new LoginException(['status'=>2800,'msg'=>'系统异常,获取用户信息失败~!']);
        }
    }

    public function homepage($id=0,$cur_user_id=0)
    {
        return $this->model->homepage($id,$cur_user_id);
    }
    public function focus($request = "",$data = ""){
        if(!in_array($data['direction'],[$this->const->focus,$this->const->cancelFocus])){
            throw new ParamException(['status'=>1980,'msg'=>'focus字段所传的值不在['.$this->const->focus.','.$this->const->cancelFocus.']其中']);
        }
        $data['user'] = $request->user;
        return $this->model->focus($data);
    }

    public function avatar($id=0,$data=[])
    {
        $size = strlen(file_get_contents($data['avatar']))/1024;
        if($size > $this->const->imageSize){
            throw new UserException(['status'=>6901,'msg'=>'图片太大了,上传头像失败']);
        }
        if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $data['avatar'], $result)){
            $type = $result[2];
            if(!in_array($type,$this->const->imageMime)){
                throw new UserException(['status'=>6902,'msg'=>'请上传正确的图片类型']);
            }
            $new_file = "api_avatar/".date('Ymd',time())."/";
            if(!file_exists($new_file)){
                mkdir($new_file,0777,true);
            }
            $new_file = $new_file.md5(time().rand(1000,9999)).".{$type}";
            if (file_put_contents($new_file, base64_decode(str_replace($result[1], '', $data['avatar'])))){
                $path = '/'.$new_file;
                return $this->model->avatar($id,$path);
            }else{
                throw new UserException(['status'=>6900,'msg'=>'上传头像失败']);
            }
        }else{
            throw new UserException(['status'=>6900,'msg'=>'上传头像失败']);
        }
    }
    public function sign($user=[])
    {
        return $this->model->sign($user);
    }
    public function info($id=0)
    {
        return $this->model->info($id);
    }
    public function mission($id=0)
    {
        return $this->model->mission($id);
    }
}