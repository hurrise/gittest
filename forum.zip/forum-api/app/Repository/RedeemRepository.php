<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 13:48
 */

namespace App\Repository;



class RedeemRepository extends BaseRepository
{
    public function index($id=0,$pageSize=0,$currPage=0)
    {
        return $this->model->index($id,$pageSize,$currPage);
    }
}