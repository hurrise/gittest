<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 13:48
 */

namespace App\Repository;



class GiftRepository extends BaseRepository
{
    public function index($pageSize=30,$currPage=1)
    {
        return $this->model->index($pageSize,$currPage);
    }
    public function redeem($data=[],$user=[])
    {
        $gift = $this->model->find($data['id']);
        if($this->getOtherModel('user')->find($user['id'])->credit < $gift->price){
            return ajaxReturn(400,'您的积分不足,请攒足后再来!');
        }
        if($gift->stock<=0){
            return ajaxReturn(400,'库存不足,请等待加货!');
        }
        return $this->model->redeem($data,$user);
    }
}