<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/21 0021
 * Time: 13:39
 */

namespace App\Repository;


use App\Lib\ParamException;
use Illuminate\Http\Request;

class ReplyRepository extends BaseRepository
{
    public function post($request="",$data = ""){
        if(empty($data['content'])){
            throw new ParamException(['status'=>1800,'msg'=>'请填写回复内容']);
        }
        $user_id = $this->getOtherModel('comment')->find($data['comment_id'])->user_id;
        if($user_id == $request->user['id']){
            throw new ParamException(['status'=>1801,'msg'=>'不可回复自己的评论']);
        }
        $data['user'] = $request->user;
        return $this->model->add($data);
    }
    public function atme($id=0,$pageSize=0,$currPage=0)
    {
        return $this->model->atme($id,$pageSize,$currPage);
    }
}