<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18 0018
 * Time: 12:19
 */

namespace App\Repository;


use App\Lib\ContentException;
use Illuminate\Support\Facades\Redis;

class ContentRepository extends BaseRepository
{
    public function index($type="",$pageSize="",$currPage=""){
        $finalData = [];
        $data = [
            'id' => null,
            'title' => null,
            'title_color' => null,
            'created_at' => null,
            'pageview' => null,
        ];
        if(empty($finalData = Redis::get(md5($this->const->contentCacheKey).'_'.$type.'_'.$pageSize.'_'.$currPage))) {
            $contents = $this->model->where('status', $this->const->normalStatus)->where('type', $type)->offset(($currPage - 1) * $pageSize)->limit($pageSize)->orderByDesc('order')->orderByDesc('created_at')->get();
            if (!$contents->isEmpty()) {
                foreach ($contents as $k => $v) {
                    $data['id'] = $v->id;
                    $data['title'] = color_text($v->title);
                    $data['title_color'] = getColorValue($v->title);
                    $data['created_at'] = $v->created_at->toDateTimeString();
                    $data['pageview'] = $v->pageview;
                    $finalData[] = $data;
                }
                Redis::setex(md5($this->const->contentCacheKey).'_'.$type . '_' . $pageSize . '_' . $currPage, $this->const->cahceExpireTime, collect($finalData)->toJson());
            } else {
                $finalData = [];
            }
        }else{
            $finalData = json_decode($finalData,true);
        }
        $total = $this->model->where('type',$type)->count('id');
        return ajaxReturn($this->const->successStatus,'获取成功',['contents'=>$finalData,'total'=>$total]);
    }
    public function detail($param = ""){
        $data = [
            'title' => null,
            'title_color' => null,
            'created_at' => null,
            'content' => null,
            'previous' => [
                'id' => null,
                'title' => null,
                'title_color' => null,
            ],
            'next' => [
                'id' => null,
                'title' => null,
                'title_color' => null,
            ],
        ];
        if(empty($data = Redis::get(md5($this->const->contentDetailCacheKay).'_'.$param['id']))) {
            $detail = $this->getDataById($param['id']);
            if (!empty($detail)) {
                if(empty(Redis::get(get_real_ip() . '_' . $param['id']))) {
                    $detail->increment('pageview');
                    Redis::setex(get_real_ip() . '_' . $param['id'], $this->const->visitExpireTime, 'exists');
                }
                $previous = $this->model->previous($detail->order, $detail->type,$detail->created_at);
                $next = $this->model->next($detail->order, $detail->type,$detail->created_at);
                $data['title'] = color_text($detail->title);
                $data['title_color'] = getColorValue($detail->title);
                $data['created_at'] = $detail->created_at->toDateTimeString();
                $data['content'] = $detail->content;
                if (!empty($previous)) {
                    $data['previous']['id'] = $previous->id;
                    $data['previous']['title'] = color_text($previous->title);
                    $data['previous']['title_color'] = getColorValue($previous->title);
                } else {
                    $data['previous'] = '';
                }
                if (!empty($next)) {
                    $data['next']['id'] = $next->id;
                    $data['next']['title'] = color_text($next->title);
                    $data['next']['title_color'] = getColorValue($next->title);
                } else {
                    $data['next'] = '';
                }
                Redis::setex(md5($this->const->contentDetailCacheKay) . '_' . $param['id'], $this->const->cahceExpireTime, collect($data)->toJson());
            } else {
                $data = [];
            }
        }else{
            $data = json_decode($data,true);
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['detail'=>$data]);
    }
}