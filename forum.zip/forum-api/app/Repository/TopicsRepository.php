<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/17 0017
 * Time: 15:11
 */

namespace App\Repository;


use App\Lib\ContentException;
use App\Lib\ParamException;
use Carbon\Carbon;
use Illuminate\Support\Facades\Redis;

class TopicsRepository extends BaseRepository
{
    public function index($pageSize="",$currPage=""){
        if(empty($finalData = Redis::get(md5($this->const->topicsCacheKey).'_'.$pageSize.'_'.$currPage))) {
            $topics = $this->model->where('status','=',$this->const->normalStatus)->offset(($currPage-1)*$pageSize)->limit($pageSize)->orderByDesc('order')->orderByDesc('updated_at')->get();
            if(!$topics->isEmpty()) {
                foreach ($topics as $k => $v) {
//                    $user = $v->user;
                    $data['id'] = $v->id;
                    $data['special'] = $this->getTopicsSpecial($v->special);
                    $data['title'] = color_text($v->title);
                    $data['title_color'] = getColorValue($v->title);
                    $data['username'] = $v->username;
                    $data['avatar'] = $v->avatar;
                    $data['created_at'] = $v->created_at->toDateTimeString();
                    $data['pageview'] = $v->pageview;
                    $data['comments'] = $v->comments;
                    $finalData[] = $data;
                }
                Redis::setex(md5($this->const->topicsCacheKey).'_'.$pageSize.'_'.$currPage,$this->const->cahceExpireTime, collect($finalData)->toJson());
            }else{
                $finalData = [];
            }
        }else{
            $finalData = json_decode($finalData,true);
        }
        $total = $this->model->count('id');
        return ajaxReturn($this->const->successStatus,'获取成功',['topics'=>$finalData,'total'=>$total]);
    }
    public function my($request,$pageSize=0,$currPage=0){
        $finalData = [];
        $topics = $this->model->where('user_id',$request->user['id'])->where('status',$this->const->normalStatus)->offset(($currPage-1)*$pageSize)->limit($pageSize)->orderByDesc('order')->orderByDesc('created_at')->get();
        $total = $this->model->where('user_id',$request->user['id'])->count();
        if(!$topics->isEmpty()) {
            foreach ($topics as $k => $v) {
                $data = [];
                $data['id'] = $v->id;
                $data['special'] = $this->getTopicsSpecial($v->special);
                $data['title'] = color_text($v->title);
                $data['title_color'] = getColorValue($v->title);
                $data['created_at'] = $v->created_at->toDateTimeString();
                $data['pageview'] = $v->pageview;
                $data['comments'] = $v->comments;
                $finalData[] = $data;
            }
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['topics'=>$finalData,'total'=>$total]);
    }

    public function his($id=0,$pageSize=30,$currPage=1)
    {
        return $this->model->his($id,$pageSize,$currPage);
    }
    private function getTopicsSpecial($spec=""){
        $arr = explode(',',trim($spec,','));
        $specArr = $this->const->topicsTypeApi();
        foreach ($specArr as $k=>$v){
            if(in_array($k,$arr)){
               $tmp[$v] = true;
            }else{
                $tmp[$v] = false;
            }
        }
        return $tmp;
    }
    public function detail($param=""){
        $data = [
            'id' => null,
            'avatar' => null,
            'user_id' => null,
            'username' => null,
            'created_at' => null,
            'special' => null,
            'title' => null,
            'title_color' => null,
            'content' => null,
            'favours' => null,
            'treads' => null,
//            'comments' => [
//                [
//                    'avatar' => null,
//                    'username' => null,
//                    'created_at' => null,
//                    'favours' => null,
//                    'content' => null,
//                ]
//            ],
        ];
        if(empty($data = Redis::get(md5($this->const->topicsDetailCacheKay).'_'.$param['id']))) {
            $topics = $this->getDataById($param['id']);
            if (!empty($topics)) {
                if(empty(Redis::get(get_real_ip() . '_' . $param['id']))) {
                    $topics->increment('pageview');
                    Redis::setex(get_real_ip() . '_' . $param['id'], $this->const->visitExpireTime, 'exists');
                }
                $data['id'] = $topics->id;
                $data['avatar'] = $topics->avatar;
                $data['user_id'] = $topics->user_id;
                $data['username'] = $topics->username;
                $data['created_at'] = $topics->created_at->toDateTimeString();
                $data['special'] = $this->getTopicsSpecial($topics->special);
                $data['title'] = color_text($topics->title);
                $data['title_color'] = getColorValue($topics->title);
                $data['content'] = $topics->content;
                $data['favours'] = $topics->favours;
                $data['treads'] = $topics->treads;
//                $comments = $topics->comment;
//                if (!$comments->isEmpty()) {
//                    foreach ($comments as $k => $v) {
//                        $tmp['avatar'] = $v->avatar;
//                        $tmp['username'] = $v->username;
//                        $tmp['created_at'] = $v->created_at->toDateTimeString();
//                        $tmp['favours'] = $v->favours;
//                        $tmp['content'] = $v->content;
//                        $data['comments'][] = $tmp;
//                    }
//                } else {
//                    $data['comments'] = null;
//                }
                Redis::setex(md5($this->const->topicsDetailCacheKay) . '_' . $param['id'], $this->const->cahceExpireTime, collect($data)->toJson());
            } else {
                $data = [];
            }
        }else{
            $data = json_decode($data,true);
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['detail'=>$data]);
    }

    public function post($request = "",$data = ""){
        $len = mb_strlen($data['title']);
        if( $len < $this->const->topicsTitleLen['min'] && $len > $this->const->topicsTitleLen['max']){
            throw new ContentException(['status'=>4100,'msg'=>'标题长度不在合理的范围内']);
        }
        if(empty($data['content'])){
            throw new ContentException(['status'=>4101,'msg'=>'内容不能为空']);
        }
        $data['user'] = $request->user;
        return $this->model->add($data);
    }
    public function favour($request = "",$data = ""){
        if(!in_array($data['favour'],[$this->const->favour,$this->const->tread])){
            throw new ParamException(['status'=>1100,'msg'=>'您所传的参数不在['.$this->const->favour.','.$this->const->tread.']其中']);
        }
        $data['user'] = $request->user;
        return $this->model->favour($data);
    }
}