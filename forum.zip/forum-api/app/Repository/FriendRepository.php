<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/25
 * Time: 14:16
 */

namespace App\Repository;


use App\Lib\ContentException;
use App\Lib\FriendException;
use App\Lib\ParamException;
use Illuminate\Support\Facades\Redis;

class FriendRepository extends BaseRepository
{
    public function add($data=[])
    {
        return $this->model->add($data);
    }

    public function apply($id=0)
    {
        return $this->model->apply($id);
    }

    public function accept($data=[])
    {
        if(is_null($data['id'])){
            throw new FriendException(['status'=>7560,'msg'=>'必传的字段{id}的值不能为空']);
        }
        if(is_null($data['status'])){
            throw new FriendException(['status'=>7550,'msg'=>'必传的字段{status}的值不能为空']);
        }
        if(!in_array($data['status'],[$this->const->focus,$this->const->cancelFocus])){
            throw new FriendException(['status'=>7520,'msg'=>$data['status'].'不在['.$this->const->focus.','.$this->const->cancelFocus.']其中']);
        }
        return $this->model->accept($data);
    }

    public function index($id=0,$pageSize=0,$currPage=0)
    {
        return $this->model->index($id,$pageSize,$currPage);
    }
    public function del($id=0)
    {
        return $this->model->del($id);
    }
}