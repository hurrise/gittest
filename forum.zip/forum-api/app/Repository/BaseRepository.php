<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 19:46
 */

namespace App\Repository;


use App\Service\FactoryService;

class BaseRepository
{
    protected $model;
    protected $const;
    public  function __construct($modelName=""){$this->model = FactoryService::generateModel($modelName);$this->const = FactoryService::generateService('ConstMap');}
    public function getOtherRepo($repoName=""){return FactoryService::generateRepository($repoName,$repoName);}
    public function getOtherModel($modelName=""){return FactoryService::generateModel($modelName);}
    public function getDataById($id){return $this->model->getDataById($id);}
    public function getService($servName=""){
        return FactoryService::generateService($servName);
    }
    public function mathcMobile($tel=""){
        if (strlen($tel) == "11") {
            $n = preg_match_all("/13[0123456789]{1}\\d{8}|15[0123456789]\\d{8}|18[0123456789]\\d{8}|17[0123456789]\\d{8}/", $tel, $array);
            if(!empty($array[0])){
                return true;
            }
            return false;
        } else {
            return false;
        }
    }
}