<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/19 0019
 * Time: 13:41
 */

namespace App\Repository;


use App\Lib\ContentException;
use App\Lib\ParamException;
use Illuminate\Support\Facades\Redis;

class CommentRepository extends BaseRepository
{
    public function post($request="",$data=""){
        if(empty($data['content'])){
            throw new ContentException(['status'=>4400,'msg'=>'请填写评论内容']);
        }
        $data['user'] = $request->user;
        return $this->model->add($data);
    }
    public function index($pageSize="",$currPage="",$data="")
    {
        return $this->model->index($pageSize,$currPage,$data);
    }
    public function my($request,$pageSize=0,$currPage=0){
        $finalData = [];
        $comment = $this->model->where('user_id',$request->user['id'])->where('status',$this->const->normalStatus)->offset(($currPage-1)*$pageSize)->limit($pageSize)->orderByDesc('created_at')->get();
        $total = $this->model->where('user_id',$request->user['id'])->count();
        if(!$comment->isEmpty()) {
            foreach ($comment as $k => $v) {
                $data = [];
                $data['topics_id'] = $v->topics_id;
                $data['created_at'] = $v->created_at->toDateTimeString();
                $data['title'] = color_text($v->title);
                $data['title_color'] = getColorValue($v->title);
                $data['avatar'] = $v->avatar;
                $data['content'] = $v->content;
                $finalData[] = $data;
            }
        }
        return ajaxReturn($this->const->successStatus,'获取成功',['comment'=>$finalData,'total'=>$total]);
    }
    public function his($id=0,$pageSize=30,$currPage=1){
        if(empty($comments = Redis::get(md5($this->const->commentsCacheKey).'_'.$id.'_'.$pageSize.'_'.$currPage))){
            $comments = $this->model->where('user_id',$id)->where('status',$this->const->normalStatus)
                ->select('content','created_at')->orderByDesc('created_at')->skip(($currPage-1)*$pageSize)
                ->take($pageSize)->get()->toArray();
            Redis::setex(md5($this->const->commentsCacheKey).'_'.$id.'_'.$pageSize.'_'.$currPage,$this->const->cahceExpireTime, collect($comments)->toJson());
        } else {
            $comments = json_decode($comments,true);
        }
        $total = $this->model->where('user_id',$id)->where('status',$this->const->normalStatus)->count();
        return ajaxReturn($this->const->successStatus,'获取他的回复成功',['comments'=>$comments,'total'=>$total]);
    }
    public function favour($request="",$data=""){
        $data['user'] = $request->user;
        return $this->model->favour($data);
    }
    public function favoured($id=0,$pageSize=0,$currPage=0){
        return $this->model->favoured($id,$pageSize,$currPage);
    }
}