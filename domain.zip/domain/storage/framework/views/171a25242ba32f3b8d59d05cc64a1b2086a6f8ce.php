<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title></title>
    <link rel="stylesheet" href="/layui/css/layui.css">
    <?php $__env->startSection('css'); ?>

    <?php echo $__env->yieldSection(); ?>
</head>
<body class="layui-layout-body">
<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldSection(); ?>
<script src="/admin/js/jquery-3.3.1.min.js"></script>
<script src="/layui/layui.js"></script>
<script src="/admin/js/common.js"></script>

<?php $__env->startSection('js'); ?>

<?php echo $__env->yieldSection(); ?>
</body>
</html>