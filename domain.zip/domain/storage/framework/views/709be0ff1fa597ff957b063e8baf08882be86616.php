
<?php $__env->startSection('content'); ?>
    <blockquote class="layui-elem-quote">
        <span class="layui-breadcrumb">
          <a href="">首页</a>
          <a href="">域名管理</a>
          <a href="">域名列表</a>
        </span>
    </blockquote>
    <form class="layui-form" action="">
        <div class="layui-form-item layui-col-md3 layui-col-md-offset2 layui-col-sm3 layui-col-sm-offset2 layui-col-xs3 layui-col-xs-offset2">
            <label class="layui-form-label">域名：</label>
            <div class="layui-input-block">
                <input type="text" name="domain" value="<?php echo e($request->domain?$request->domain:''); ?>" placeholder="请输入域名" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-col-md3 layui-col-sm3 layui-col-xs3">
            <label class="layui-form-label">过期时间：</label>
            <div class="layui-input-block">
                <input type="text" class="layui-input" value="<?php echo e($request->expired_at?$request->expired_at:''); ?>" id="time" name="expired_at" placeholder="请选择过期时间">
            </div>
        </div>
        <div class="layui-col-md1 layui-col-sm1 layui-col-xs1" style="margin-left:5px; ">
            <button class="layui-btn">搜索</button>
        </div>
    </form>
    <div class="layui-col-md11 layui-col-md-offset1 layui-col-sm11 layui-col-sm-offset1 layui-col-xs11 layui-col-xs-offset1">

            <button class="layui-btn" onclick="show('添加域名','<?php echo e(url('admin/domain/add')); ?>')"><i class="layui-icon">&#xe654;</i>添加域名</button>


            <button class="layui-btn" onclick="show('批量添加域名','<?php echo e(url('admin/domain/batch')); ?>')"><i class="layui-icon">&#xe654;</i>批量添加域名</button>


            <button class="layui-btn" id="upload"><i class="layui-icon">&#xe67c;</i>导入表格</button>


            <button class="layui-btn layui-btn-danger" id="delete"><i class="layui-icon">&#xe640;</i>一键删除</button>

    </div>
    <div class="layui-col-md10 layui-col-md-offset1 layui-col-sm10 layui-col-sm-offset1 layui-col-xs10 layui-col-xs-offset1">
        <table class="layui-table">
            <colgroup>
                <col width="300">
                <col width="200">
                <col width="200">
                <col>
            </colgroup>
            <thead>
            <tr>
                <th>域名</th>
                <th>过期时间</th>
                <th>说明</th>
                <th>备注</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if(!empty($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php if($v->diff == 1 || $v->diff == 0): ?><span style="color: red;"><?php echo e($v->domain); ?></span><?php else: ?><span style="color: darkgreen;"><?php echo e($v->domain); ?></span><?php endif; ?></td>
                        <td><?php echo e($v->expired_at?$v->expired_at:'未设置'); ?></td>
                        <td><?php if(!empty($v->expired_at)): ?> 距离过期时间还有<?php echo e($v->diff); ?>天 <?php else: ?> **** <?php endif; ?></td>
                        <td><?php echo e($v->remark); ?></td>
                        <td><a style="cursor: pointer;" onclick="show('编辑域名','<?php echo e(url('admin/domain/edit',['id'=>$v->id])); ?>')"><i class="layui-icon">&#xe642;</i>编辑</a>&nbsp;<a style="cursor: pointer;" onclick="del('<?php echo e(url('admin/domain/del',['id'=>$v->id])); ?>')"><i class="layui-icon">&#xe640;</i>删除</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>

        </table>
        <?php echo e($data->appends($request->all())->links('pagination::myStyle')); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        layui.use(['laydate','layer','laypage','upload'], function(){
            var laydate = layui.laydate;
            var laypage = layui.laypage;
            var upload = layui.upload;
            var layer = layui.layer;
            laydate.render({
                elem: '#time'
            });
            //执行实例
            var uploadInst = upload.render({
                elem: '#upload', //绑定元素
                url: '<?php echo e(url('admin/domain/import')); ?>', //上传接口
                accept:'file',
                exts:'xlsx|xlsm|xltx|xltm|xlsb|xlam|xls',
                done: function(res){
                    //上传完毕回调

                    layer.msg(res.msg);
                    setTimeout(function () {
                        if (res.code == 200) {
                            layer.closeAll();
                            window.parent.location.reload();
                        }
                    }, 1000);
                },
                error: function(){
                    //请求异常回调
                }
            });
            $('#delete').click(function () {
                layer.confirm('是否全部删除?', function(index){
                    //do something
                    $.ajax({
                        type:'GET',
                        dataType:'json',
                        url:'<?php echo e(url('admin/domain/delall')); ?>',
                        success:function (res) {
                            if (res.code == 200) {
                                layer.closeAll();
                                window.parent.location.reload();
                            }
                        }
                    });

                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>