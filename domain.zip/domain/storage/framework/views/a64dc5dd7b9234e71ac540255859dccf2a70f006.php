
<?php $__env->startSection('content'); ?>
    <form class="layui-form-pane layui-form layui-col-md10 layui-col-md-offset1 layui-col-sm10 layui-col-sm-offset1 layui-col-xs10 layui-col-xs-offset1" style="margin-top:5% " action="">
        <div class="layui-form-item layui-form-text">
            <label class="layui-form-label">域名</label>
            <div class="layui-input-block">
                <textarea name="domain" id="domain" placeholder="请输入域名,可以在域名后用|隔开写入域名的过期时间,也可以不写.例如：www.baidu.com|2019-09-01.多个域名请换行"  class="layui-textarea"></textarea>
            </div>
        </div>
        <?php echo e(csrf_field()); ?>

        <div class="layui-form-item">
            <div class="layui-input-block">
                <a class="layui-btn" lay-submit lay-filter="formDemo" id="sub">立即提交</a>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        layui.use(['form','laydate','layer'], function(){
            var form = layui.form;
            var layer = layui.layer;
            var laydate = layui.laydate;
            var flag = true;
            laydate.render({
                elem: '#time'
            });
            if(flag) {
                $("#sub").click(function () {
                    flag = false;
                    var data = {
                        domain: $('#domain').val(),
                        _token:$('input[name="_token"]').val(),
                    }
                    $.ajax({
                        url: '<?php echo e(url('admin/domain/batch')); ?>',
                        type: 'POST',
                        data: data,
                        dataType: 'json',
                        success: function (res) {
                            flag = true;
                            layer.msg(res.msg);
                            setTimeout(function () {
                                if (res.code == 200) {
                                    layer.closeAll();
                                    window.parent.location.reload();
                                }
                            }, 1000);
                        }
                    });
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>