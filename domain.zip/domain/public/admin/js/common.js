/**
 * Created by Administrator on 2019/1/5 0005.
 */
layui.use('layer', function(){
    var layer = layui.layer;
});

function show(title,url,w,h) {
    layer.open({
        type:2,
        title:title,
        content:[url,'no'],
        area: [(w?w:800) + 'px', (h?h:500) + 'px'],
    });
}

function del(url) {
    layer.confirm('是否删除?', {icon: 3, title:'删除后不可恢复'}, function(index){
        $.ajax({
            url:url,
            type:'GET',
            dataType:'json',
            success:function(res){
                layer.msg(res.msg);
                setTimeout(function () {
                    layer.closeAll();
                    window.parent.location.reload();
                }, 1000);
            }
        });
    });
}
