CREATE TABLE `d_domains`(
  `id` int(11) unsigned auto_increment,
  `domain` VARCHAR (255) NOT NULL DEFAULT '',
  `expired_at` VARCHAR (30) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `remark` VARCHAR (255) NOT NULL DEFAULT '',
  `created_at` VARCHAR (30) NOT NULL DEFAULT '',
  `updated_at` VARCHAR (30) NOT NULL DEFAULT '',
  PRIMARY KEY d_id(`id`),
  KEY d_d(`domain`)
)engine=innodb DEFAULT charset=utf8mb4;