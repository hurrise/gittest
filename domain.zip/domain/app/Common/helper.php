<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/5 0005
 * Time: 15:46
 */
function ckm($nowm="",$vm=""){
    if($nowm == $vm){
        return 'layui-nav-itemed';
    }
}
function ckc($nowc="",$vc=""){
    if($nowc == $vc){
        return 'layui-this';
    }
}

function ajaxReturn($code = 200,$msg = "操作成功",$data = []){
    $data = [
        'code' => $code,
        'msg' => $msg,
        'data' => $data,
    ];
    return response()->json($data);
}
function customWriteLog($directory,$msg){
    $path = storage_path('logs/'.$directory.'/.log');
    $handlers[] = ($monolog = Log::getMonolog())->popHandler();
    Log::useDailyFiles($path);
    Log::info($msg);
    $monolog->setHandlers($handlers);
}