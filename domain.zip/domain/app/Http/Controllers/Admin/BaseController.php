<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/5 0005
 * Time: 15:19
 */

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class BaseController extends Controller
{
    public function __construct(Request $request)
    {
        $mca = $request->route()->getName();
        if(is_null($mca)){
            dd('Error_01:请为路由['.$request->getUri().']设置别名');
        }
        $mcaArr = explode('.',$mca);
        View::share('m',$mcaArr[0]);
        View::share('c',$mcaArr[1]);
    }
}