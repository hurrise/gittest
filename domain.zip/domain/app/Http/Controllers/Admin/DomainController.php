<?php

namespace App\Http\Controllers\Admin;

use App\Model\DomainModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DomainController extends BaseController
{
    protected $model;
    public function __construct(Request $request)
    {
        $this->model = new DomainModel();
        parent::__construct($request);
    }

    public function index(Request $request){
        $data = $this->model->index($request);
        foreach ($data as $k=>$v){
            $diff = floor((strtotime($v->expired_at) - time())/86400);
            $data[$k]['diff'] = $diff>0?$diff:0;
        }
        return view('admin.domain.index',compact('data','request'));
    }
    public function add(Request $request){
        if($request->isMethod('post')){
            return $this->model->add($request);
        }
        return view('admin.domain.add');
    }
    public function batch(Request $request){
        if($request->isMethod('post')){
            return $this->model->batch($request);
        }
        return view('admin.domain.batch');
    }

    public function edit(Request $request,$id = ""){
        if($request->isMethod('post')){
            return $this->model->edit($request,$id);
        }
        $data = $this->model->getDataById($id);
        return view('admin.domain.edit',compact('data'));
    }
    public function del($id = ""){
        return $this->model->del($id);
    }
    public function delall(){
        if($this->model->truncate()){
            return ajaxReturn(200,'删除成功');
        }
        return ajaxReturn(400,'删除失败');
    }
    public function import(Request $request){
        return $this->model->import($request);
    }
}
