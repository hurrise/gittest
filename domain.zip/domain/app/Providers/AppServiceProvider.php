<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //此处定义模块
        define('M_YMGL','ymgl'); //域名管理模块
        define('M_INDEX','index'); //域名管理模块
        //此处定义控制器
        define('C_DOMAIN','domain');
        define('C_INDEX','index');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
