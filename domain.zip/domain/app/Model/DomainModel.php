<?php

namespace App\Model;

use App\Imports\DomainsImport;
use Illuminate\Database\Eloquent\Model;
use Maatwebsite\Excel\Facades\Excel;

class DomainModel extends Model
{
    protected $table = 'domains';
    protected $sheet_title = ['域名','过期时间','备注'];
    public function index($request = ""){
        $search = $request->all();
        $where = [];
        if(!empty($search['domain'])){
            $where[] = ['domain','like','%'.$search['domain'].'%'];
        }
        if(!empty($search['expired_at'])){
            $where[] = ['expired_at','=',$search['expired_at']];
        }
        return $this->where($where)->orderBy('expired_at')->paginate(50);
    }
    public function add($request = ""){
        $data = $request->all();
        if($this->where('domain',$data['domain'])->first()){
            return ajaxReturn(400,'域名已存在');
        }
        $this->domain = $data['domain'];
        $this->expired_at = $data['expired_at'];
        $this->remark = $data['remark'];
        if($this->save()){
            return ajaxReturn(200,'添加成功');
        }
        return ajaxReturn(400,'添加失败');
    }
    public function edit($request = "",$id = ""){
        $data = $request->all();
        $model = $this->getDataById($id);
        $model->domain = $data['domain'];
        $model->expired_at = $data['expired_at'];
        $model->remark = $data['remark'];
        if($model->save()){
            return ajaxReturn(200,'编辑成功');
        }
        return ajaxReturn(400,'编辑失败');
    }
    public function del($id = ""){
        if($this->where('id',$id)->delete()){
            return ajaxReturn(200,'删除成功');
        }
        return ajaxReturn(400,'删除失败');
    }
    public function batch($request=""){
        $data = $request->all();
        $domains = explode("\n",str_replace("\r\n","\n",str_replace("\n","\r\n",$data['domain'])));
        $ptn = '/^\d{4}-\d{2}-\d{2}$/';
        foreach ($domains as $k=>$v){
            if(!empty($v)) {
                $tmpData = explode('|', $v);
                if (!empty($tmpData[1])) {
                    preg_match($ptn, $tmpData[1], $match);
                    if (empty($match)) {
                        return ajaxReturn(400, '域名:' . $tmpData[0] . '的过期时间格式不正确');
                    }
                    $tmp['expired_at'] = $tmpData[1];
                }
                $tmp['domain'] = $tmpData[0];
                $domainData[] = $tmp;
            }
        }
        if(!empty($domainData)) {
            if($this->insert($domainData)){
                return ajaxReturn(200,'添加成功');
            }
        }
        return ajaxReturn(400,'添加失败');
    }
    public function getDataById($id = ""){
        return $this->find($id);
    }
    public function import($request = ""){
        $flag = '';
        if ($request->hasFile('file') && $request->file('file')->isValid()) {
            $file = $request->file('file');
            $ext = $file->getClientOriginalExtension();
            $filename = 'domain.'.$ext;
            $path = './upload';
            $file->move($path,$filename);

            Excel::load("public/upload/{$filename}",function ($reader) use (&$flag){
                $data = $reader->all();
                $data = $data->toArray();
                $ptn = '/^\d{4}-\d{2}-\d{2}$/';
                foreach ($data[0] as $k=>$v){
                    if(!array_key_exists($this->sheet_title[0],$v) || !array_key_exists($this->sheet_title[1],$v) || !array_key_exists($this->sheet_title[2],$v)){
                        $flag = 400;
                        return;
                    }
                    if(empty($this->where('domain','=',$v[$this->sheet_title[0]])->first())) {
                        if(!empty($v[$this->sheet_title[0]])) {
                            $tmp['domain'] = $v[$this->sheet_title[0]];
                        }else{
                            $tmp['domain'] = '';
                        }
                        if(!empty($v[$this->sheet_title[1]])) {
                            $time = explode(' ', $v[$this->sheet_title[1]])[0];
                            preg_match($ptn, $time, $match);
                            if (empty($match)) {
                                $flag = 402;
                                return;
                            }
                            $tmp['expired_at'] = $time;
                        }else{
                            $tmp['expired_at'] = '';
                        }
                        if(!empty($v[$this->sheet_title[2]])) {
                            $tmp['remark'] = $v[$this->sheet_title[2]];
                        }else{
                            $tmp['remark'] = '';
                        }
                        if(empty($tmp['domain']) && empty($tmp['expired_at']) && empty($tmp['remark'])){
                            $tmp = [];
                        }
                        $domainData[] = $tmp;
                    }
                }
                if(!empty($domainData)) {
                    if($this->insert($domainData)){
                        $flag = 200;
                        return;
                    }
                }
                $flag = 401;
            });

            if($flag == 200){
                return ajaxReturn(200,'导入成功');
            }else if($flag == 400){
                return ajaxReturn(400,'导入表格的表头格式不正确');
            }else if($flag == 401){
                return ajaxReturn(400,'导入失败,导入的数据为空或者数据全部重复');
            }else if($flag == 402){
                return ajaxReturn(400,'导入失败,导入的数据中过期时间有的不正确');
            }
        }
    }
}
