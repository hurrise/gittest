@extends('admin.layout')
@section('content')
    <blockquote class="layui-elem-quote">
        <span class="layui-breadcrumb">
          <a href="">首页</a>
          <a href="">域名管理</a>
          <a href="">域名列表</a>
        </span>
    </blockquote>
    <form class="layui-form" action="">
        <div class="layui-form-item layui-col-md3 layui-col-md-offset2 layui-col-sm3 layui-col-sm-offset2 layui-col-xs3 layui-col-xs-offset2">
            <label class="layui-form-label">域名：</label>
            <div class="layui-input-block">
                <input type="text" name="domain" value="{{$request->domain?$request->domain:''}}" placeholder="请输入域名" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-col-md3 layui-col-sm3 layui-col-xs3">
            <label class="layui-form-label">过期时间：</label>
            <div class="layui-input-block">
                <input type="text" class="layui-input" value="{{$request->expired_at?$request->expired_at:''}}" id="time" name="expired_at" placeholder="请选择过期时间">
            </div>
        </div>
        <div class="layui-col-md1 layui-col-sm1 layui-col-xs1" style="margin-left:5px; ">
            <button class="layui-btn">搜索</button>
        </div>
    </form>
    <div class="layui-col-md11 layui-col-md-offset1 layui-col-sm11 layui-col-sm-offset1 layui-col-xs11 layui-col-xs-offset1">

            <button class="layui-btn" onclick="show('添加域名','{{url('admin/domain/add')}}')"><i class="layui-icon">&#xe654;</i>添加域名</button>


            <button class="layui-btn" onclick="show('批量添加域名','{{url('admin/domain/batch')}}')"><i class="layui-icon">&#xe654;</i>批量添加域名</button>


            <button class="layui-btn" id="upload"><i class="layui-icon">&#xe67c;</i>导入表格</button>


            <button class="layui-btn layui-btn-danger" id="delete"><i class="layui-icon">&#xe640;</i>一键删除</button>

    </div>
    <div class="layui-col-md10 layui-col-md-offset1 layui-col-sm10 layui-col-sm-offset1 layui-col-xs10 layui-col-xs-offset1">
        <table class="layui-table">
            <colgroup>
                <col width="300">
                <col width="200">
                <col width="200">
                <col>
            </colgroup>
            <thead>
            <tr>
                <th>域名</th>
                <th>过期时间</th>
                <th>说明</th>
                <th>备注</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            @if(!empty($data))
                @foreach($data as $k=>$v)
                    <tr>
                        <td>@if($v->diff == 1 || $v->diff == 0)<span style="color: red;">{{$v->domain}}</span>@else<span style="color: darkgreen;">{{$v->domain}}</span>@endif</td>
                        <td>{{$v->expired_at?$v->expired_at:'未设置'}}</td>
                        <td>@if(!empty($v->expired_at)) 距离过期时间还有{{$v->diff}}天 @else **** @endif</td>
                        <td>{{$v->remark}}</td>
                        <td><a style="cursor: pointer;" onclick="show('编辑域名','{{url('admin/domain/edit',['id'=>$v->id])}}')"><i class="layui-icon">&#xe642;</i>编辑</a>&nbsp;<a style="cursor: pointer;" onclick="del('{{url('admin/domain/del',['id'=>$v->id])}}')"><i class="layui-icon">&#xe640;</i>删除</a></td>
                    </tr>
                @endforeach
            @endif
            </tbody>

        </table>
        {{$data->appends($request->all())->links('pagination::myStyle')}}
    </div>
@endsection
@section('js')
    <script>
        layui.use(['laydate','layer','laypage','upload'], function(){
            var laydate = layui.laydate;
            var laypage = layui.laypage;
            var upload = layui.upload;
            var layer = layui.layer;
            laydate.render({
                elem: '#time'
            });
            //执行实例
            var uploadInst = upload.render({
                elem: '#upload', //绑定元素
                url: '{{url('admin/domain/import')}}', //上传接口
                accept:'file',
                exts:'xlsx|xlsm|xltx|xltm|xlsb|xlam|xls',
                done: function(res){
                    //上传完毕回调

                    layer.msg(res.msg);
                    setTimeout(function () {
                        if (res.code == 200) {
                            layer.closeAll();
                            window.parent.location.reload();
                        }
                    }, 1000);
                },
                error: function(){
                    //请求异常回调
                }
            });
            $('#delete').click(function () {
                layer.confirm('是否全部删除?', function(index){
                    //do something
                    $.ajax({
                        type:'GET',
                        dataType:'json',
                        url:'{{url('admin/domain/delall')}}',
                        success:function (res) {
                            if (res.code == 200) {
                                layer.closeAll();
                                window.parent.location.reload();
                            }
                        }
                    });
                });
            });
        });
    </script>
@endsection