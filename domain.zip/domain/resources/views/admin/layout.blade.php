<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>域名管理 - 后台</title>
    <link rel="stylesheet" href="/layui/css/layui.css">
    <link rel="stylesheet" href="/admin/css/common.css">
    @section('css')

    @show
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
    <div class="layui-header">
        <div class="layui-logo">域名管理系统</div>
        <ul class="layui-nav layui-layout-left">
            <li class="layui-nav-item"><a href="{{url('admin/index/index')}}">控制台</a></li>
        </ul>
    </div>

    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <ul class="layui-nav layui-nav-tree"  lay-filter="test">
                <li class="layui-nav-item {{ckm($m,M_YMGL)}}">
                    <a class="" href="javascript:;">域名管理</a>
                    <dl class="layui-nav-child">
                        <dd><a class="{{ckc($c,C_DOMAIN)}}" href="{{url('admin/domain/index')}}">域名列表</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>

    <div class="layui-body">
        @section('content')

        @show
    </div>

    <div class="layui-footer">
        © 无限游戏 - v1.0
    </div>
</div>
<script src="/admin/js/jquery-3.3.1.min.js"></script>
<script src="/layui/layui.js"></script>
<script src="/admin/js/common.js"></script>

<script>
    layui.use('element', function(){
        var element = layui.element;
        element.on();
    });
</script>
@section('js')

@show
</body>
</html>