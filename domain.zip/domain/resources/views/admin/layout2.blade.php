<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title></title>
    <link rel="stylesheet" href="/layui/css/layui.css">
    @section('css')

    @show
</head>
<body class="layui-layout-body">
@section('content')

@show
<script src="/admin/js/jquery-3.3.1.min.js"></script>
<script src="/layui/layui.js"></script>
<script src="/admin/js/common.js"></script>

@section('js')

@show
</body>
</html>