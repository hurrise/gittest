<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/',function (){
    return redirect(url('admin/index/index'));
});
Route::get('excel/export','ExcelController@export');
Route::get('excel/import','ExcelController@import');
Route::group(['namespace'=>'Admin','prefix'=>'admin/'],function (){
    Route::get('index/index',['uses'=>'IndexController@index','as'=>M_INDEX.'.'.C_INDEX.'.index']);
    Route::get('domain/index',['uses'=>'DomainController@index','as'=>M_YMGL.'.'.C_DOMAIN.'.index']);
//    Route::get('domain/index',App\Processor\Admin\Domain\IndexHandler::class);
    Route::any('domain/add',['uses'=>'DomainController@add','as'=>M_YMGL.'.'.C_DOMAIN.'.add']);
    Route::any('domain/batch',['uses'=>'DomainController@batch','as'=>M_YMGL.'.'.C_DOMAIN.'.batch']);
    Route::any('domain/edit/{id}',['uses'=>'DomainController@edit','as'=>M_YMGL.'.'.C_DOMAIN.'.edit']);
    Route::get('domain/del/{id}',['uses'=>'DomainController@del','as'=>M_YMGL.'.'.C_DOMAIN.'.del']);
    Route::any('domain/import',['uses'=>'DomainController@import','as'=>M_YMGL.'.'.C_DOMAIN.'.import']);
    Route::get('domain/delall',['uses'=>'DomainController@delall','as'=>M_YMGL.'.'.C_DOMAIN.'.delall']);
});
